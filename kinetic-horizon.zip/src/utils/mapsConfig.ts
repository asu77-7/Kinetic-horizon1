declare const __GMP_FALLBACK_KEY__: string | undefined;

export function getGoogleMapsApiKey(): string {
  const fromVite = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  if (fromVite && typeof fromVite === 'string') return fromVite;

  if (typeof __GMP_FALLBACK_KEY__ !== 'undefined' && __GMP_FALLBACK_KEY__) {
    return __GMP_FALLBACK_KEY__;
  }

  const fromGlobal = (globalThis as Record<string, unknown>).GOOGLE_MAPS_API_KEY;
  if (typeof fromGlobal === 'string' && fromGlobal) return fromGlobal;

  return '';
}

export function triggerQuotaExceededNotice(): void {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
}

export interface LiveAirQualityResult {
  aqi: number;
  category: string;
  dominantPollutant: string;
  healthRecommendation: string;
  pm25UgM3?: number;
}

/**
 * Fetches live ambient air quality from Google Maps Platform Air Quality API
 * for the active origin location, with Tier 2 quota checks.
 */
export async function fetchGoogleAirQuality(
  lat: number,
  lng: number,
  apiKey: string
): Promise<LiveAirQualityResult | null> {
  if (!apiKey) return null;

  const url = `https://airquality.googleapis.com/v1/currentConditions:lookup?key=${encodeURIComponent(
    apiKey
  )}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Maps-Solution-ID': 'gmp_mcp_codeassist_v1_aistudio',
    },
    body: JSON.stringify({
      universalAqi: true,
      location: { latitude: lat, longitude: lng },
      extraComputations: ['POLLUTANT_CONCENTRATION', 'HEALTH_RECOMMENDATIONS'],
      languageCode: 'en',
    }),
  });

  if (response.status === 429) {
    triggerQuotaExceededNotice();
    return null;
  }

  const data = await response.json().catch(() => null);

  if (!response.ok || data?.error) {
    if (data?.error?.status === 'RESOURCE_EXHAUSTED') {
      triggerQuotaExceededNotice();
    }
    throw new Error(
      data?.error?.message || `Air Quality API returned HTTP ${response.status}`
    );
  }

  const primaryIndex = data?.indexes?.[0];
  if (!primaryIndex) return null;

  const pm25Entry = Array.isArray(data?.pollutants)
    ? data.pollutants.find((p: { code?: string }) => p.code === 'pm25')
    : undefined;

  return {
    aqi: Number(primaryIndex.aqi ?? 0),
    category: String(primaryIndex.category ?? 'Measured'),
    dominantPollutant: String(primaryIndex.dominantPollutant ?? 'pm25').toUpperCase(),
    healthRecommendation: String(
      data?.healthRecommendations?.generalPopulation ??
        'Keep cabin HEPA filtration enabled during high-particulate urban segments.'
    ),
    pm25UgM3:
      typeof pm25Entry?.concentration?.value === 'number'
        ? pm25Entry.concentration.value
        : undefined,
  };
}
