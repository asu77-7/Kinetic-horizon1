import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register global Google Maps Platform auth & quota detection (Case A Tier 1)
(window as unknown as { gm_authFailure?: () => void }).gm_authFailure = () => {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
};

const origConsoleError = console.error;
console.error = (...args: unknown[]) => {
  const joined = args.map((a) => String(a ?? '')).join(' ');
  if (
    /OverQuotaMapError|QuotaExceeded|ApiNotActivatedMapError|ExpiredKeyMapError/i.test(
      joined
    )
  ) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
  origConsoleError.apply(console, args);
};

createRoot(document.getElementById('root')!).render(<App />);
