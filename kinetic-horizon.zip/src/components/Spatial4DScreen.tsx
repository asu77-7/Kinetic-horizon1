import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Play,
  Pause,
  RotateCcw,
  Layers,
  Wind,
  Radar,
  ArrowUpRight,
  Bluetooth,
  BluetoothConnected,
  Car,
  Sparkles,
} from 'lucide-react';
import { DRIVE_MODE_SPECS } from '../data/vehicleData';
import {
  CameraPreset,
  KineticVehicleScene,
} from '../three/KineticVehicleScene';
import {
  AeroWingMode,
  AirQualityReport,
  BluetoothLinkState,
  ClimateState,
  DriveMode,
  ScreenId,
  SuspensionHeight,
  VehicleProfile,
} from '../types/vehicle';
import { AirQualityBluetoothPanel } from './AirQualityBluetoothPanel';

interface Spatial4DScreenProps {
  vehicle: VehicleProfile;
  driveMode: DriveMode;
  speedKmh: number;
  powerKw: number;
  suspension: SuspensionHeight;
  aeroWing: AeroWingMode;
  frunkOpen: boolean;
  trunkOpen: boolean;
  climate: ClimateState;
  airReport: AirQualityReport;
  bluetooth: BluetoothLinkState;
  onUpdateClimate: (patch: Partial<ClimateState>) => void;
  onUpdateAirReport: (report: AirQualityReport) => void;
  onUpdateBluetooth: (bt: BluetoothLinkState) => void;
  onChangeVehicle: () => void;
  onNavigateScreen: (screen: ScreenId) => void;
  onChangeDriveMode: (mode: DriveMode) => void;
}

const CAMERA_LABELS: { id: CameraPreset; label: string }[] = [
  { id: 'hero', label: '3/4 Hero' },
  { id: 'side', label: 'Aero Side' },
  { id: 'top', label: 'Top Radar' },
  { id: 'drivetrain', label: 'Drivetrain' },
];

export const Spatial4DScreen: React.FC<Spatial4DScreenProps> = ({
  vehicle,
  driveMode,
  speedKmh,
  powerKw,
  suspension,
  aeroWing,
  frunkOpen,
  trunkOpen,
  climate,
  airReport,
  bluetooth,
  onUpdateClimate,
  onUpdateAirReport,
  onUpdateBluetooth,
  onChangeVehicle,
  onNavigateScreen,
  onChangeDriveMode,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<KineticVehicleScene | null>(null);

  const [contextLost, setContextLost] = useState(false);
  const [dockCollapsed, setDockCollapsed] = useState(false);

  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('hero');
  const [explodeFactor, setExplodeFactor] = useState<number>(0);
  const [xrayMode, setXrayMode] = useState<boolean>(false);
  const [showAeroFlow, setShowAeroFlow] = useState<boolean>(true);
  const [showCabinAirflow, setShowCabinAirflow] = useState<boolean>(true);
  const [showLidar4D, setShowLidar4D] = useState<boolean>(true);
  const [timeOffsetSec, setTimeOffsetSec] = useState<number>(0);
  const [isTimePlaying, setIsTimePlaying] = useState<boolean>(false);

  const accentHex = DRIVE_MODE_SPECS[driveMode].accentHex;

  // Mount Three.js scene once
  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const scene = new KineticVehicleScene(
      el,
      {
        vehicleBodyType: vehicle.bodyType,
        vehicleColorHex: vehicle.colorHex,
        driveMode,
        accentHex,
        speedKmh,
        powerKw,
        suspension,
        aeroWing,
        frunkOpen,
        trunkOpen,
        explodeFactor,
        xrayMode,
        showAeroFlow,
        showCabinAirflow,
        airflowLevel: climate.fanLevel,
        showLidar4D,
        timeOffsetSec,
        isTimePlaying,
        cameraPreset,
      },
      () => setContextLost(true)
    );
    sceneRef.current = scene;

    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Push live state updates into Three.js without recreating canvas
  useEffect(() => {
    sceneRef.current?.updateParams({
      vehicleBodyType: vehicle.bodyType,
      vehicleColorHex: vehicle.colorHex,
      driveMode,
      accentHex,
      speedKmh,
      powerKw,
      suspension,
      aeroWing,
      frunkOpen,
      trunkOpen,
      explodeFactor,
      xrayMode,
      showAeroFlow,
      showCabinAirflow,
      airflowLevel: climate.fanLevel,
      showLidar4D,
      timeOffsetSec,
      isTimePlaying,
      cameraPreset,
    });
  }, [
    vehicle.bodyType,
    vehicle.colorHex,
    driveMode,
    accentHex,
    speedKmh,
    powerKw,
    suspension,
    aeroWing,
    frunkOpen,
    trunkOpen,
    explodeFactor,
    xrayMode,
    showAeroFlow,
    showCabinAirflow,
    climate.fanLevel,
    showLidar4D,
    timeOffsetSec,
    isTimePlaying,
    cameraPreset,
  ]);

  // 4D temporal playback advance
  useEffect(() => {
    if (!isTimePlaying) return;
    const id = window.setInterval(() => {
      setTimeOffsetSec((prev) => {
        const next = prev + 0.2;
        return next > 10 ? -10 : Number(next.toFixed(1));
      });
    }, 80);
    return () => window.clearInterval(id);
  }, [isTimePlaying]);

  // Keyboard shortcut 'H' to toggle bottom dock
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.key.toLowerCase() === 'h' &&
        !(e.target instanceof HTMLInputElement) &&
        !(e.target instanceof HTMLTextAreaElement)
      ) {
        setDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const effectiveSpeed =
    Math.abs(timeOffsetSec) > 0.05
      ? Math.max(0, Math.round(speedKmh + Math.sin(timeOffsetSec * 0.45) * 48))
      : Math.round(speedKmh);

  const featureCatalog = [
    {
      title: `4D ${vehicle.bodyType.toUpperCase()} Digital Twin`,
      subtitle: `${vehicle.name} · ${vehicle.powertrain}`,
      description:
        'Dynamically sculpts your selected car geometry (Sedan, SUV, Coupe, or Hatchback) with custom paint finish, 160 exterior aero streamlines, and a T-10s to T+10s 4D temporal scrubber.',
      actionLabel: 'Switch Car Model',
      onAction: onChangeVehicle,
    },
    {
      title: 'Cabin Air Quality & 4D Airflow Check',
      subtitle: 'Ambient AQI + HEPA Circulation',
      description:
        'Measures outdoor air quality via Google Maps Air Quality API alongside interior PM2.5, CO₂, and laminar CFM airflow streamlines passing through the 4D cabin shell.',
      actionLabel: showCabinAirflow ? 'Hide 4D Cabin Flow' : 'Show 4D Cabin Flow',
      onAction: () => setShowCabinAirflow((v) => !v),
    },
    {
      title: 'Bluetooth Vehicle Pairing',
      subtitle: 'Web Bluetooth & OBD-BT Bridge',
      description:
        'Pairs directly with your car’s Bluetooth audio/OBD-II interface so speed, battery/fuel range, and cabin ventilation telemetry stay synchronized while driving.',
      actionLabel:
        bluetooth.status === 'connected' ? 'Bluetooth Paired ✓' : 'Open Vehicle Studio',
      onAction: () => onNavigateScreen('vehicle'),
    },
    {
      title: '800V Drivetrain X-Ray & Exploded View',
      subtitle: 'Chassis & Underbody Inspection',
      description:
        'Lifts the outer body shell or switches the hull to optical X-Ray transparency, exposing the underfloor pack, cooling rails, and torque-vectoring drive units.',
      actionLabel: xrayMode ? 'Restore Solid Shell' : 'Inspect Drivetrain X-Ray',
      onAction: () => {
        const next = !xrayMode;
        setXrayMode(next);
        setExplodeFactor(next ? 0.55 : 0);
        setCameraPreset(next ? 'drivetrain' : 'hero');
      },
    },
    {
      title: 'Google Maps Route & Busyness Advisor',
      subtitle: 'Live Traffic & Drive Helpfulness',
      description:
        'Evaluates primary and alternative routes across Pakistan with Google Maps Routes API and live traffic layers, checking road busyness, rest terminals, and drive suitability.',
      actionLabel: 'Open Google Maps Routes',
      onAction: () => onNavigateScreen('navigation'),
    },
    {
      title: 'Drive-Mode Photon & Chassis Shift',
      subtitle: 'Range · Comfort · Sport · Track',
      description:
        'Switching drive modes re-calibrates suspension clearance, rear wing angle of attack, front/rear torque split, and the cockpit photonic color temperature.',
      actionLabel: driveMode === 'track' ? 'Return to Comfort' : 'Switch to Track Mode',
      onAction: () => onChangeDriveMode(driveMode === 'track' ? 'comfort' : 'track'),
    },
  ];

  return (
    <div className="flex flex-col gap-7">
      {/* FULL-VIEWPORT UNOBSTRUCTED 3D / 4D STAGE */}
      <section
        aria-label="3D and 4D Spatial Digital Twin"
        className="relative w-full h-[540px] lg:h-[600px] rounded-[1.5rem] overflow-hidden border border-white/[0.08] bg-[#0B0E14]"
      >
        {/* Dedicated WebGL Mount Container */}
        <div
          ref={mountRef}
          className="w-full h-full cursor-grab active:cursor-grabbing"
        />

        {contextLost && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0B0E14] p-6 text-center">
            <p className="font-display text-lg font-medium text-[#E1E2EB]">
              3D Graphics Context Suspended
            </p>
            <p className="text-sm text-[#849495] mt-1 max-w-md">
              Hardware WebGL context was interrupted. Switch to the Vehicle Studio view or reload to resume real-time 3D rendering.
            </p>
          </div>
        )}

        {/* Top-Left Telemetry Badge (solid dark container, no backdrop-blur over WebGL) */}
        <div className="pointer-events-none absolute top-5 left-5 flex flex-col gap-1 bg-[#10131A]/95 border border-white/[0.1] rounded-2xl px-4 py-3">
          <div className="flex items-center gap-2 kh-label-caps text-[#849495]">
            <Car className="w-3.5 h-3.5 text-[#00F2FE]" />
            <span>
              {vehicle.name} · {vehicle.bodyType.toUpperCase()} 4D Twin
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-3 font-mono tabular-nums text-xs text-[#E1E2EB]">
            <span>{effectiveSpeed} km/h</span>
            <span aria-hidden="true" className="text-white/25">
              ·
            </span>
            <span style={{ color: accentHex }}>
              {DRIVE_MODE_SPECS[driveMode].label} Mode
            </span>
            <span aria-hidden="true" className="text-white/25">
              ·
            </span>
            <span className="inline-flex items-center gap-1 text-[#10E7A9]">
              {bluetooth.status === 'connected' ? (
                <>
                  <BluetoothConnected className="w-3.5 h-3.5" />
                  <span>BT Paired</span>
                </>
              ) : (
                <>
                  <Bluetooth className="w-3.5 h-3.5 text-[#849495]" />
                  <span className="text-[#849495]">BT Ready</span>
                </>
              )}
            </span>
            <span aria-hidden="true" className="text-white/25">
              ·
            </span>
            <span className="text-[#849495]">
              {timeOffsetSec === 0
                ? 'T = Live'
                : `T ${timeOffsetSec > 0 ? `+${timeOffsetSec.toFixed(1)}` : timeOffsetSec.toFixed(1)}s`}
            </span>
          </div>
        </div>

        {/* Top-Right Switch Car Action & Hint */}
        <div className="absolute top-5 right-5 flex items-center gap-2.5">
          <button
            type="button"
            onClick={onChangeVehicle}
            className="inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full bg-[#10131A]/95 border border-white/[0.16] text-xs font-medium text-[#E1E2EB] hover:border-[#00F2FE] transition-colors cursor-pointer"
          >
            <Car className="w-3.5 h-3.5 text-[#00F2FE]" />
            <span>Change Car</span>
          </button>
          <div className="pointer-events-none hidden md:block bg-[#10131A]/90 border border-white/[0.08] rounded-full px-3.5 py-1.5 text-[11px] font-mono text-[#849495]">
            Drag to orbit · Scroll to zoom · H toggles dock
          </div>
        </div>

        {/* UNIFIED COLLAPSIBLE BOTTOM CONTROL DOCK */}
        <div
          className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[min(960px,94%)] flex flex-col items-center transition-transform duration-200 ease-[cubic-bezier(0.16,1,0.3,1)]"
          style={{
            transform: dockCollapsed
              ? 'translate(-50%, calc(100% - 38px))'
              : 'translate(-50%, 0)',
          }}
        >
          {/* Collapse / Expand Tab */}
          <button
            type="button"
            onClick={() => setDockCollapsed((p) => !p)}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-t-xl bg-[#10131A]/95 border border-b-0 border-white/[0.12] text-[11px] font-mono uppercase tracking-wider text-[#B9CACB] hover:text-white cursor-pointer"
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" />
                <span>Show 4D Controls</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" />
                <span>Hide Controls</span>
              </>
            )}
          </button>

          {/* Compact Dock Surface (solid/rgba without backdrop-filter per Three.js WebGL perf rule) */}
          <div className="w-full rounded-2xl bg-[#10131A]/95 border border-white/[0.12] p-4 flex flex-col gap-3.5 shadow-2xl">
            {/* Row 1: Camera Views + 4D Layer Switches */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                {CAMERA_LABELS.map((cam) => {
                  const active = cameraPreset === cam.id;
                  return (
                    <button
                      key={cam.id}
                      type="button"
                      onClick={() => setCameraPreset(cam.id)}
                      className={`min-h-[36px] px-3.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? 'text-[#0B0E14] font-semibold'
                          : 'bg-[#191C22] border border-white/[0.1] text-[#B9CACB] hover:text-white'
                      }`}
                      style={
                        active ? { backgroundColor: accentHex } : undefined
                      }
                    >
                      {cam.label}
                    </button>
                  );
                })}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowCabinAirflow((v) => !v)}
                  className={`inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full text-xs font-medium border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    showCabinAirflow
                      ? 'border-[#10E7A9]/60 bg-[#10E7A9]/15 text-[#DFFFED]'
                      : 'border-white/[0.1] bg-[#191C22] text-[#849495]'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Cabin Airflow</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowAeroFlow((v) => !v)}
                  className={`inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full text-xs font-medium border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    showAeroFlow
                      ? 'border-[#00F2FE]/60 bg-[#00F2FE]/15 text-[#E0FDFF]'
                      : 'border-white/[0.1] bg-[#191C22] text-[#849495]'
                  }`}
                >
                  <Wind className="w-3.5 h-3.5" />
                  <span>Aero Flow</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowLidar4D((v) => !v)}
                  className={`inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full text-xs font-medium border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    showLidar4D
                      ? 'border-[#4FACFE]/60 bg-[#4FACFE]/15 text-[#D8EDFF]'
                      : 'border-white/[0.1] bg-[#191C22] text-[#849495]'
                  }`}
                >
                  <Radar className="w-3.5 h-3.5" />
                  <span>4D LiDAR</span>
                </button>

                <button
                  type="button"
                  onClick={() => setXrayMode((v) => !v)}
                  className={`inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full text-xs font-medium border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    xrayMode
                      ? 'border-[#4FACFE]/70 bg-[#4FACFE]/20 text-[#E1E2EB]'
                      : 'border-white/[0.1] bg-[#191C22] text-[#849495]'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>X-Ray Shell</span>
                </button>
              </div>
            </div>

            {/* Row 2: Exploded Chassis Slider + 4D Temporal Scrubber */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-white/[0.08]">
              <div className="flex items-center gap-3">
                <span className="kh-label-caps text-[#849495] whitespace-nowrap shrink-0">
                  Explode
                </span>
                <input
                  type="range"
                  aria-label="Exploded drivetrain separation"
                  min={0}
                  max={1}
                  step={0.02}
                  value={explodeFactor}
                  onChange={(e) => setExplodeFactor(parseFloat(e.target.value))}
                  className="w-full accent-[#00F2FE] cursor-pointer"
                />
                <span className="font-mono tabular-nums text-xs text-[#E1E2EB] w-10 text-right">
                  {Math.round(explodeFactor * 100)}%
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  aria-label={isTimePlaying ? 'Pause 4D timeline' : 'Play 4D timeline'}
                  onClick={() => setIsTimePlaying((p) => !p)}
                  className="w-8 h-8 rounded-full bg-[#191C22] border border-white/[0.12] flex items-center justify-center text-[#E1E2EB] hover:border-white/40 shrink-0 cursor-pointer"
                >
                  {isTimePlaying ? (
                    <Pause className="w-3.5 h-3.5" />
                  ) : (
                    <Play className="w-3.5 h-3.5" />
                  )}
                </button>

                <span className="kh-label-caps text-[#849495] whitespace-nowrap shrink-0">
                  4D Time
                </span>

                <input
                  type="range"
                  aria-label="4D temporal telemetry scrubber"
                  min={-10}
                  max={10}
                  step={0.2}
                  value={timeOffsetSec}
                  onChange={(e) => {
                    setIsTimePlaying(false);
                    setTimeOffsetSec(parseFloat(e.target.value));
                  }}
                  className="w-full accent-[#10E7A9] cursor-pointer"
                />

                <span className="font-mono tabular-nums text-xs text-[#10E7A9] w-14 text-right shrink-0">
                  {timeOffsetSec === 0
                    ? 'LIVE'
                    : `${timeOffsetSec > 0 ? '+' : ''}${timeOffsetSec.toFixed(1)}s`}
                </span>

                {timeOffsetSec !== 0 && (
                  <button
                    type="button"
                    aria-label="Reset to live timeline"
                    onClick={() => {
                      setIsTimePlaying(false);
                      setTimeOffsetSec(0);
                    }}
                    className="w-8 h-8 rounded-full bg-[#191C22] border border-white/[0.12] flex items-center justify-center text-[#849495] hover:text-white shrink-0 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STEP 2: AIR QUALITY, 4D CABIN AIRFLOW CHECK & BLUETOOTH CAR LINK */}
      <AirQualityBluetoothPanel
        vehicle={vehicle}
        airReport={airReport}
        onUpdateAirReport={onUpdateAirReport}
        bluetooth={bluetooth}
        onUpdateBluetooth={onUpdateBluetooth}
        fanLevel={climate.fanLevel}
        onChangeFanLevel={(fanLevel) => onUpdateClimate({ fanLevel })}
        hepaFilter={climate.hepaFilter}
        onToggleHepa={(hepaFilter) => onUpdateClimate({ hepaFilter })}
        showCabinAirflow={showCabinAirflow}
        onToggleCabinAirflow={setShowCabinAirflow}
        onProceedToRoutes={() => onNavigateScreen('navigation')}
      />

      {/* MULTI-FEATURE SYSTEM DESCRIPTIONS & INTERACTIVE LAUNCHERS */}
      <section aria-label="Multi-Feature Capabilities Guide" className="pt-2">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
          <div>
            <span className="kh-label-caps text-[#849495]">
              System Capabilities Overview
            </span>
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-[#E1E2EB] mt-1 text-balance">
              Multi-Feature Cockpit & 4D Spatial Architecture
            </h2>
          </div>
          <p className="text-sm text-[#B9CACB] max-w-xl">
            Every subsystem connects your selected vehicle&apos;s 4D twin, cabin air quality and airflow diagnostics, Bluetooth link, and live Google Maps traffic routing into one cohesive interface.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {featureCatalog.map((feat) => (
            <article
              key={feat.title}
              className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6 flex flex-col justify-between gap-5"
            >
              <div>
                <div className="kh-label-caps text-[#4FACFE]">{feat.subtitle}</div>
                <h3 className="font-display text-lg font-semibold text-[#E1E2EB] mt-1.5">
                  {feat.title}
                </h3>
                <p className="mt-2.5 text-[14px] leading-relaxed text-[#B9CACB]">
                  {feat.description}
                </p>
              </div>

              <div className="pt-4 border-t border-white/[0.06]">
                <button
                  type="button"
                  onClick={feat.onAction}
                  className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-[#191C22] border border-white/[0.14] text-xs font-semibold text-[#E1E2EB] hover:border-[#00F2FE]/60 hover:text-[#E0FDFF] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>{feat.actionLabel}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};
