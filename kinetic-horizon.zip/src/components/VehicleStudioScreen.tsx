import React from 'react';
import { Shield, Lock, Unlock, Sparkles } from 'lucide-react';
import { HARDWARE_DIAGNOSTICS } from '../data/vehicleData';
import {
  AeroWingMode,
  BluetoothLinkState,
  SuspensionHeight,
  VehicleProfile,
} from '../types/vehicle';
import { HapticToggle } from './HapticToggle';
import { KineticSlider } from './KineticSlider';

interface VehicleStudioScreenProps {
  vehicle: VehicleProfile;
  bluetooth: BluetoothLinkState;
  locked: boolean;
  onToggleLock: () => void;
  sentryActive: boolean;
  onToggleSentry: (val: boolean) => void;
  frunkOpen: boolean;
  onToggleFrunk: () => void;
  trunkOpen: boolean;
  onToggleTrunk: () => void;
  chargePortOpen: boolean;
  onToggleChargePort: () => void;
  suspension: SuspensionHeight;
  onChangeSuspension: (s: SuspensionHeight) => void;
  aeroWing: AeroWingMode;
  onChangeAeroWing: (a: AeroWingMode) => void;
  ambientIntensity: number;
  onChangeAmbientIntensity: (v: number) => void;
  onOpenSpatial4D: () => void;
}

export const VehicleStudioScreen: React.FC<VehicleStudioScreenProps> = ({
  vehicle,
  bluetooth,
  locked,
  onToggleLock,
  sentryActive,
  onToggleSentry,
  frunkOpen,
  onToggleFrunk,
  trunkOpen,
  onToggleTrunk,
  chargePortOpen,
  onToggleChargePort,
  suspension,
  onChangeSuspension,
  aeroWing,
  onChangeAeroWing,
  ambientIntensity,
  onChangeAmbientIntensity,
  onOpenSpatial4D,
}) => {
  const rideOffsetY = suspension === 'low' ? 6 : suspension === 'raised' ? -7 : 0;
  const wingTilt = aeroWing === 'downforce' ? -14 : aeroWing === 'auto' ? -6 : 0;
  const rideHeightMm = suspension === 'low' ? 126 : suspension === 'raised' ? 168 : 148;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* LEFT / TOP: VEHICLE SILHOUETTE & ACCESS CONTROLS (8 columns) */}
      <div className="lg:col-span-8 flex flex-col gap-6">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
            <div>
              <span className="kh-label-caps text-[#849495]">
                Chassis & Aerodynamics ·{' '}
                {bluetooth.status === 'connected' ? 'Bluetooth Paired' : 'Bluetooth Standby'}
              </span>
              <h2 className="font-display text-2xl font-semibold text-[#E1E2EB] mt-1">
                {vehicle.name} · {vehicle.powertrain}
              </h2>
              <p className="text-xs text-[#849495] mt-1">
                {vehicle.summary}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="font-mono tabular-nums text-xs text-[#B9CACB]">
                Cd {vehicle.dragCd} · {rideHeightMm} mm
              </span>
              <button
                type="button"
                onClick={onOpenSpatial4D}
                className="min-h-[38px] px-4 rounded-full bg-[#00F2FE] text-[#0B0E14] text-xs font-semibold hover:opacity-90 transition-opacity whitespace-nowrap shrink-0 cursor-pointer"
              >
                Open 4D Twin
              </button>
            </div>
          </div>

          {/* Architectural Side-Profile EV GT Vector Blueprint */}
          <div className="relative rounded-2xl bg-[#0B0E14] border border-white/[0.08] p-6 overflow-hidden">
            {/* Ambient photon glow bar beneath chassis */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-x-16 bottom-8 h-10 rounded-full blur-2xl transition-opacity duration-200"
              style={{
                backgroundColor: 'var(--kh-accent)',
                opacity: (ambientIntensity / 100) * 0.28,
              }}
            />

            <svg
              viewBox="0 0 760 260"
              className="w-full h-56 md:h-64 select-none"
              role="img"
              aria-label="Kinetic Horizon GT side elevation schematic"
            >
              {/* Ground Datum Line */}
              <line
                x1="40"
                y1="212"
                x2="720"
                y2="212"
                stroke="rgba(255,255,255,0.14)"
                strokeWidth="1"
              />
              <line
                x1="80"
                y1="224"
                x2="680"
                y2="224"
                stroke="rgba(255,255,255,0.05)"
                strokeDasharray="4 8"
              />

              {/* Vehicle Body Group reacting to Ride Height */}
              <g
                transform={`translate(0, ${rideOffsetY})`}
                className="transition-transform duration-300"
              >
                {/* Frunk Hood Line (Lifts when open) */}
                <path
                  d="M 102 148 Q 145 118 228 112"
                  fill="none"
                  stroke={frunkOpen ? '#00F2FE' : 'rgba(255,255,255,0.22)'}
                  strokeWidth={frunkOpen ? '2.5' : '1.5'}
                  transform={frunkOpen ? 'rotate(-16 228 112)' : undefined}
                />

                {/* Active Rear Aero Wing */}
                <g transform={`translate(612, 114) rotate(${wingTilt})`}>
                  <path
                    d="M 0 0 L 42 -6 L 46 -2 L 4 5 Z"
                    fill="#191C22"
                    stroke="var(--kh-accent)"
                    strokeWidth="1.5"
                  />
                </g>

                {/* Trunk Decklid (Lifts when open) */}
                <path
                  d="M 526 98 Q 596 112 642 134"
                  fill="none"
                  stroke={trunkOpen ? '#00F2FE' : 'rgba(255,255,255,0.22)'}
                  strokeWidth={trunkOpen ? '2.5' : '1.5'}
                  transform={trunkOpen ? 'rotate(22 526 98)' : undefined}
                />

                {/* Primary Sculpted Coupe Body */}
                <path
                  d="M 96 168 C 92 146 115 130 165 120 L 235 110 C 292 78 368 68 448 76 C 510 82 572 104 644 128 C 660 135 664 152 658 172 L 598 176 C 594 142 544 142 540 176 L 238 176 C 234 142 184 142 180 176 L 106 174 Z"
                  fill="#151A24"
                  stroke="rgba(255,255,255,0.34)"
                  strokeWidth="1.6"
                />

                {/* Panoramic Glass Canopy */}
                <path
                  d="M 244 110 C 298 84 366 76 442 82 C 490 86 534 102 566 118 L 244 118 Z"
                  fill="#0B0E14"
                  stroke="var(--kh-accent)"
                  strokeOpacity="0.65"
                  strokeWidth="1.2"
                />

                {/* Cabin B-Pillar & Door Seam */}
                <line x1="392" y1="81" x2="386" y2="174" stroke="rgba(255,255,255,0.14)" strokeWidth="1" />
                <line x1="258" y1="120" x2="254" y2="174" stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
                <line x1="518" y1="120" x2="512" y2="174" stroke="rgba(255,255,255,0.12)" strokeWidth="1" />

                {/* Ambient Photon Beltline */}
                <line
                  x1="262"
                  y1="130"
                  x2="512"
                  y2="130"
                  stroke="var(--kh-accent)"
                  strokeWidth="1.5"
                  strokeOpacity={Math.max(0.15, ambientIntensity / 100)}
                />

                {/* Headlight & Taillight Blades */}
                <line x1="102" y1="146" x2="128" y2="142" stroke="#E0FDFF" strokeWidth="3" strokeLinecap="round" />
                <line x1="640" y1="140" x2="658" y2="143" stroke="#FF6B5A" strokeWidth="3" strokeLinecap="round" />

                {/* Charge Port Indicator */}
                <circle
                  cx="556"
                  cy="132"
                  r="5"
                  fill={chargePortOpen ? '#00F2FE' : '#1D2026'}
                  stroke={chargePortOpen ? '#E0FDFF' : 'rgba(255,255,255,0.3)'}
                  strokeWidth="1.5"
                />

                {/* Front & Rear Turbine Aero Wheels */}
                {[209, 569].map((cx) => (
                  <g key={cx} transform={`translate(${cx}, 178)`}>
                    <circle r="33" fill="#0B0E14" stroke="rgba(255,255,255,0.38)" strokeWidth="2" />
                    <circle r="22" fill="#131722" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
                    <circle r="6" fill="var(--kh-accent)" fillOpacity="0.85" />
                  </g>
                ))}
              </g>
            </svg>

            {/* Quick Access Hardware Triggers */}
            <div className="mt-4 pt-4 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={onToggleLock}
                  className={`inline-flex items-center gap-2 min-h-[44px] px-4 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                    locked
                      ? 'bg-[#191C22] border border-white/[0.16] text-[#E1E2EB]'
                      : 'bg-[#00F2FE] text-[#0B0E14]'
                  }`}
                >
                  {locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  <span>{locked ? 'Doors Locked' : 'Doors Unlocked'}</span>
                </button>

                <button
                  type="button"
                  onClick={onToggleFrunk}
                  className={`min-h-[44px] px-4 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                    frunkOpen
                      ? 'bg-[#00F2FE] text-[#0B0E14] font-semibold'
                      : 'bg-[#191C22] border border-white/[0.14] text-[#E1E2EB] hover:border-white/50'
                  }`}
                >
                  {frunkOpen ? 'Close Frunk' : 'Open Frunk'}
                </button>

                <button
                  type="button"
                  onClick={onToggleTrunk}
                  className={`min-h-[44px] px-4 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                    trunkOpen
                      ? 'bg-[#00F2FE] text-[#0B0E14] font-semibold'
                      : 'bg-[#191C22] border border-white/[0.14] text-[#E1E2EB] hover:border-white/50'
                  }`}
                >
                  {trunkOpen ? 'Close Trunk' : 'Open Trunk'}
                </button>

                <button
                  type="button"
                  onClick={onToggleChargePort}
                  className={`min-h-[44px] px-4 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                    chargePortOpen
                      ? 'bg-[#10E7A9] text-[#0B0E14] font-semibold'
                      : 'bg-[#191C22] border border-white/[0.14] text-[#E1E2EB] hover:border-white/50'
                  }`}
                >
                  {chargePortOpen ? 'Charge Port Open' : 'Open Charge Port'}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Hardware Subsystem Diagnostics */}
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="kh-label-caps text-[#849495]">Telemetry Bus Integrity</span>
              <h3 className="font-display text-xl font-medium text-[#E1E2EB] mt-0.5">
                Core Hardware Diagnostics
              </h3>
            </div>
            <span className="font-mono text-xs text-[#10E7A9]">All Nodes Nominal</span>
          </div>

          <div className="divide-y divide-white/[0.06]">
            {HARDWARE_DIAGNOSTICS.map((node) => (
              <div
                key={node.id}
                className="py-3.5 flex flex-wrap items-center justify-between gap-4"
              >
                <div>
                  <div className="text-sm font-medium text-[#E1E2EB]">{node.subsystem}</div>
                  <div className="text-xs text-[#849495]">{node.spec}</div>
                </div>
                <div className="flex items-center gap-6 font-mono tabular-nums text-xs">
                  <span className="text-[#B9CACB]">{node.tempC}°C</span>
                  <span className="text-[#E1E2EB] w-28 text-right">{node.voltageOrLoad}</span>
                  <span className="text-[#10E7A9] w-20 text-right">● {node.status}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* RIGHT: SUSPENSION, AERO, AMBIENT & SECURITY (4 columns) */}
      <div className="lg:col-span-4 flex flex-col gap-6">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <span className="kh-label-caps text-[#849495]">Air Suspension & Aero</span>
          <h3 className="font-display text-xl font-medium text-[#E1E2EB] mt-1 mb-4">
            Chassis Geometry
          </h3>

          <div className="mb-5">
            <div className="kh-label-caps text-[#849495] mb-2">Ride Height</div>
            <div className="grid grid-cols-3 gap-2 p-1 rounded-full bg-[#0B0E14] border border-white/[0.08]">
              {(['low', 'standard', 'raised'] as SuspensionHeight[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => onChangeSuspension(s)}
                  className={`min-h-[40px] rounded-full text-xs font-medium capitalize transition-all cursor-pointer ${
                    suspension === s
                      ? 'text-[#0B0E14] font-semibold'
                      : 'text-[#849495] hover:text-[#E1E2EB]'
                  }`}
                  style={
                    suspension === s ? { backgroundColor: 'var(--kh-accent)' } : undefined
                  }
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-5">
            <div className="kh-label-caps text-[#849495] mb-2">Active Rear Wing</div>
            <div className="grid grid-cols-3 gap-2 p-1 rounded-full bg-[#0B0E14] border border-white/[0.08]">
              {(['eco', 'auto', 'downforce'] as AeroWingMode[]).map((a) => (
                <button
                  key={a}
                  type="button"
                  onClick={() => onChangeAeroWing(a)}
                  className={`min-h-[40px] rounded-full text-xs font-medium capitalize transition-all cursor-pointer ${
                    aeroWing === a
                      ? 'text-[#0B0E14] font-semibold'
                      : 'text-[#849495] hover:text-[#E1E2EB]'
                  }`}
                  style={
                    aeroWing === a ? { backgroundColor: 'var(--kh-accent)' } : undefined
                  }
                >
                  {a}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-white/[0.06]">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-[#00F2FE]" />
              <span className="kh-label-caps text-[#849495]">Cabin Photon Strip</span>
            </div>
            <KineticSlider
              label="Ambient Illumination"
              valueDisplay={`${ambientIntensity}%`}
              value={ambientIntensity}
              min={0}
              max={100}
              step={5}
              onChange={onChangeAmbientIntensity}
            />
          </div>
        </section>

        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="flex items-center gap-2.5 mb-3">
            <Shield className="w-4 h-4 text-[#00F2FE]" />
            <span className="kh-label-caps text-[#849495]">Perimeter Security</span>
          </div>
          <HapticToggle
            label="Sentry 360° Recording"
            description="LiDAR + 4-camera perimeter watch"
            checked={sentryActive}
            onChange={onToggleSentry}
            accent="cyan"
          />
        </section>
      </div>
    </div>
  );
};
