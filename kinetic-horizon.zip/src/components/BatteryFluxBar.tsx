import React from 'react';
import { Zap } from 'lucide-react';

interface BatteryFluxBarProps {
  batteryPct: number;
  rangeKm: number;
  isCharging: boolean;
  chargingRateKw: number;
  batteryTempC: number;
  onSimulateCharging: () => void;
  onSimulateLowBattery: () => void;
  onResetNominal: () => void;
}

export const BatteryFluxBar: React.FC<BatteryFluxBarProps> = ({
  batteryPct,
  rangeKm,
  isCharging,
  chargingRateKw,
  batteryTempC,
  onSimulateCharging,
  onSimulateLowBattery,
  onResetNominal,
}) => {
  const isCritical = !isCharging && batteryPct < 10;
  const isMidLow = !isCharging && batteryPct >= 10 && batteryPct <= 20;

  const barColor = isCharging
    ? '#00F2FE'
    : isCritical
      ? '#F59E0B'
      : isMidLow
        ? '#4FACFE'
        : '#10E7A9';

  const cardBorderClass = isCritical
    ? 'border-[#F59E0B]/60'
    : isCharging
      ? 'border-[#00F2FE]/45'
      : 'border-white/[0.08]';

  const segments = 20;
  const filledSegments = Math.round((batteryPct / 100) * segments);

  return (
    <section
      aria-label="Battery State and Energy Flux"
      className={`rounded-[1.5rem] bg-[#131722] border ${cardBorderClass} p-6 transition-colors duration-200`}
      style={
        isCritical
          ? { boxShadow: '0 0 24px rgba(245, 158, 11, 0.16)' }
          : isCharging
            ? { boxShadow: '0 0 24px rgba(0, 242, 254, 0.14)' }
            : undefined
      }
    >
      <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
        <div>
          <div className="flex items-center gap-3">
            <span className="kh-label-caps text-[#849495]">HV Battery Pack · 108 kWh</span>
            {isCharging && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border border-[#00F2FE]/40 text-[#00F2FE] kh-label-caps">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00F2FE] kh-pulse-slow" />
                Charging · {chargingRateKw} kW
              </span>
            )}
            {isCritical && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border border-[#F59E0B]/50 text-[#F59E0B] kh-label-caps">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] kh-pulse-slow" />
                Low Reserve
              </span>
            )}
          </div>
          <div className="mt-2 flex items-baseline gap-4">
            <span
              className="font-mono tabular-nums text-4xl font-semibold tracking-tight"
              style={{ color: barColor }}
            >
              {batteryPct.toFixed(0)}%
            </span>
            <span className="font-mono tabular-nums text-xl font-medium text-[#E1E2EB]">
              {rangeKm} <span className="text-xs text-[#849495] uppercase tracking-wider">km WLTP</span>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-6 text-right">
          <div>
            <div className="kh-label-caps text-[#849495]">Cell Temp</div>
            <div className="font-mono tabular-nums text-sm font-medium text-[#E1E2EB] mt-0.5">
              {batteryTempC.toFixed(1)} °C
            </div>
          </div>
          <div>
            <div className="kh-label-caps text-[#849495]">Bus Voltage</div>
            <div className="font-mono tabular-nums text-sm font-medium text-[#E1E2EB] mt-0.5">
              {isCharging ? '834 V' : '812 V'}
            </div>
          </div>
        </div>
      </div>

      {/* Segmented Luminous Battery & Flux Bar */}
      <div
        role="progressbar"
        aria-valuenow={Math.round(batteryPct)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Battery charge level"
        className="grid grid-cols-20 gap-1.5 p-2 rounded-full bg-[#0B0E14] border border-white/[0.08]"
      >
        {Array.from({ length: segments }).map((_, idx) => {
          const filled = idx < filledSegments;
          const isLeading = filled && idx === filledSegments - 1;
          return (
            <div
              key={idx}
              className={`h-3.5 rounded-full transition-all duration-200 ${
                isCritical && filled ? 'kh-pulse-slow' : ''
              }`}
              style={{
                backgroundColor: filled ? barColor : '#1D2026',
                boxShadow: filled && isLeading ? `0 0 12px ${barColor}` : 'none',
                opacity: filled ? 1 : 0.65,
              }}
            />
          );
        })}
      </div>

      {/* State Controls for Interactive Testing */}
      <div className="mt-5 pt-4 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-3">
        <span className="text-xs text-[#849495]">
          {isCritical
            ? 'Reserve below 10% · Route planner prioritizes nearest 350 kW HPC charger'
            : isCharging
              ? 'Active 800V DC fast charge · Thermal loop balanced at 29°C'
              : 'Pack healthy · Regenerative ceiling 120 kW available'}
        </span>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onSimulateCharging}
            className={`inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full text-xs font-medium transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
              isCharging
                ? 'bg-[#00F2FE] text-[#0B0E14] font-semibold'
                : 'bg-[#191C22] border border-white/[0.12] text-[#E1E2EB] hover:border-[#00F2FE]/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{isCharging ? 'Unplug DC' : 'Fast Charge'}</span>
          </button>

          <button
            type="button"
            onClick={onSimulateLowBattery}
            className={`min-h-[36px] px-3.5 rounded-full text-xs font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
              isCritical
                ? 'bg-[#F59E0B] text-[#0B0E14] font-semibold'
                : 'bg-[#191C22] border border-white/[0.12] text-[#B9CACB] hover:border-[#F59E0B]/60 hover:text-[#F59E0B]'
            }`}
          >
            Test 8% Reserve
          </button>

          {(isCritical || isCharging || batteryPct !== 82) && (
            <button
              type="button"
              onClick={onResetNominal}
              className="min-h-[36px] px-3.5 rounded-full text-xs font-medium bg-transparent border border-white/[0.12] text-[#849495] hover:text-[#E1E2EB] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Reset 82%
            </button>
          )}
        </div>
      </div>
    </section>
  );
};
