import React from 'react';
import { DRIVE_MODE_SPECS } from '../data/vehicleData';
import { DriveMode } from '../types/vehicle';

interface DriveModeDockProps {
  mode: DriveMode;
  onChange: (mode: DriveMode) => void;
}

const MODES: DriveMode[] = ['range', 'comfort', 'sport', 'track'];

export const DriveModeDock: React.FC<DriveModeDockProps> = ({ mode, onChange }) => {
  return (
    <div
      role="radiogroup"
      aria-label="Drive Mode"
      className="inline-flex items-center p-1.5 rounded-full bg-[#131722] border border-white/[0.08] gap-1"
    >
      {MODES.map((m) => {
        const spec = DRIVE_MODE_SPECS[m];
        const active = mode === m;
        return (
          <button
            key={m}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(m)}
            className={`min-h-[40px] px-4 md:px-5 rounded-full text-[13px] font-medium tracking-wide transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
              active
                ? 'font-semibold'
                : 'text-[#849495] hover:text-[#E1E2EB]'
            }`}
            style={
              active
                ? {
                    backgroundColor: spec.accentHex,
                    color: '#0B0E14',
                    boxShadow: `0 0 18px ${spec.accentHex}55`,
                  }
                : undefined
            }
          >
            {spec.label}
          </button>
        );
      })}
    </div>
  );
};
