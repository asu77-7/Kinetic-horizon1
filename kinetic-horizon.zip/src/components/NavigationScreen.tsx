import React, { useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  AdvancedMarker,
  Map,
  Pin,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  Navigation,
  Zap,
  Plus,
  Check,
  MapPin,
  Mountain,
  Clock,
  Coffee,
  BedDouble,
  TrafficCone,
  CheckCircle2,
  AlertTriangle,
  Car,
  BluetoothConnected,
  Wind,
  Route as RouteIcon,
} from 'lucide-react';
import { ROUTE_OPTIONS } from '../data/vehicleData';
import {
  AirQualityReport,
  BluetoothLinkState,
  VehicleProfile,
} from '../types/vehicle';
import {
  getGoogleMapsApiKey,
  triggerQuotaExceededNotice,
} from '../utils/mapsConfig';

interface NavigationScreenProps {
  vehicle: VehicleProfile;
  batteryPct: number;
  airReport: AirQualityReport;
  bluetooth: BluetoothLinkState;
  selectedRouteId: string;
  onSelectRoute: (id: string) => void;
  preconditioning: boolean;
  onTogglePreconditioning: (val: boolean) => void;
}

interface ComputedRouteSummary {
  index: number;
  description: string;
  distanceKm: number;
  durationMin: number;
  staticDurationMin: number;
  delayMin: number;
  busynessLabel: 'Clear / Not Busy' | 'Moderate Traffic' | 'Busy / Heavy Congestion';
  busynessColor: string;
  helpfulVerdict: string;
  isRecommendedToDrive: boolean;
  warnings: string[];
  routeLabels: string[];
  slowSegmentsCount: number;
  jamSegmentsCount: number;
}

function formatDuration(totalMinutes: number): string {
  const hrs = Math.floor(totalMinutes / 60);
  const mins = Math.round(totalMinutes % 60);
  if (hrs === 0) return `${mins}m`;
  if (mins === 0) return `${hrs}h`;
  return `${hrs}h ${mins}m`;
}

const GoogleTrafficOverlay: React.FC<{ enabled: boolean }> = ({ enabled }) => {
  const map = useMap();
  const mapsLib = useMapsLibrary('maps');
  const layerRef = useRef<google.maps.TrafficLayer | null>(null);

  useEffect(() => {
    if (!map || !mapsLib) return;

    if (!layerRef.current) {
      layerRef.current = new mapsLib.TrafficLayer();
    }

    layerRef.current.setMap(enabled ? map : null);

    return () => {
      layerRef.current?.setMap(null);
    };
  }, [map, mapsLib, enabled]);

  return null;
};

interface GoogleRoutesControllerProps {
  origin: google.maps.LatLngLiteral;
  destination: google.maps.LatLngLiteral;
  selectedGoogleRouteIdx: number;
  onRoutesComputed: (summaries: ComputedRouteSummary[], errorMsg: string | null) => void;
}

const GoogleRoutesController: React.FC<GoogleRoutesControllerProps> = ({
  origin,
  destination,
  selectedGoogleRouteIdx,
  onRoutesComputed,
}) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);
  const computedRoutesRef = useRef<google.maps.routes.Route[]>([]);

  // Clear & draw polylines whenever selection changes without re-fetching
  const renderPolylines = (
    routes: google.maps.routes.Route[],
    activeIdx: number,
    targetMap: google.maps.Map
  ) => {
    polylinesRef.current.forEach((pl) => pl.setMap(null));
    polylinesRef.current = [];

    // Draw inactive alternatives first underneath
    routes.forEach((rt, idx) => {
      if (idx === activeIdx) return;
      const altLines = rt.createPolylines({
        polylineOptions: {
          strokeColor: '#4FACFE',
          strokeOpacity: 0.38,
          strokeWeight: 4,
          zIndex: 1,
        },
      });
      altLines.forEach((pl) => {
        pl.setMap(targetMap);
        polylinesRef.current.push(pl);
      });
    });

    // Draw selected route on top with traffic speed coloring if available
    const activeRoute = routes[activeIdx] ?? routes[0];
    if (activeRoute) {
      const activeLines = activeRoute.createPolylines({
        polylineOptions: {
          strokeColor: '#00F2FE',
          strokeOpacity: 0.92,
          strokeWeight: 6,
          zIndex: 10,
        },
      });
      activeLines.forEach((pl) => {
        pl.setMap(targetMap);
        polylinesRef.current.push(pl);
      });

      if (activeRoute.viewport) {
        targetMap.fitBounds(activeRoute.viewport, 48);
      }
    }
  };

  useEffect(() => {
    if (!map || !routesLib) return;

    let cancelled = false;

    const runCompute = async () => {
      try {
        const request: google.maps.routes.ComputeRoutesRequest = {
          origin,
          destination,
          travelMode: 'DRIVING' as google.maps.TravelMode,
          routingPreference: 'TRAFFIC_AWARE_OPTIMAL',
          computeAlternativeRoutes: true,
          extraComputations: ['TRAFFIC_ON_POLYLINE'],
          fields: [
            'description',
            'distanceMeters',
            'durationMillis',
            'staticDurationMillis',
            'path',
            'speedPaths',
            'viewport',
            'routeLabels',
            'warnings',
          ],
          language: 'en',
          region: 'PK',
        };

        const response = await routesLib.Route.computeRoutes(request);
        if (cancelled) return;

        const routes = response.routes ?? [];
        computedRoutesRef.current = routes;

        if (routes.length === 0) {
          onRoutesComputed([], 'Google Maps returned no driving routes for this corridor.');
          return;
        }

        const summaries: ComputedRouteSummary[] = routes.map((rt, idx) => {
          const distanceKm = Math.round((rt.distanceMeters ?? 0) / 1000);
          const durationMin = Math.max(1, Math.round((rt.durationMillis ?? 0) / 60000));
          const staticDurationMin = Math.max(
            1,
            Math.round((rt.staticDurationMillis ?? rt.durationMillis ?? 0) / 60000)
          );
          const delayMin = Math.max(0, durationMin - staticDurationMin);
          const speedPaths = rt.speedPaths ?? [];
          const slowSegmentsCount = speedPaths.filter((s) => s.speed === 'SLOW').length;
          const jamSegmentsCount = speedPaths.filter((s) => s.speed === 'TRAFFIC_JAM').length;

          const delayRatio = staticDurationMin > 0 ? delayMin / staticDurationMin : 0;

          let busynessLabel: ComputedRouteSummary['busynessLabel'] = 'Clear / Not Busy';
          let busynessColor = '#10E7A9';
          let isRecommendedToDrive = true;
          let helpfulVerdict =
            'Roads are clear and moving smoothly. Helpful to drive right now with predictable travel time.';

          if (jamSegmentsCount >= 3 || delayMin >= 25 || delayRatio >= 0.16) {
            busynessLabel = 'Busy / Heavy Congestion';
            busynessColor = '#F59E0B';
            isRecommendedToDrive = false;
            helpfulVerdict = `Heavy congestion detected (+${delayMin} min traffic delay across ${jamSegmentsCount} slow/jammed sections). Consider switching to an alternate corridor or scheduling a rest stop.`;
          } else if (
            slowSegmentsCount >= 2 ||
            jamSegmentsCount >= 1 ||
            delayMin >= 10 ||
            delayRatio >= 0.07
          ) {
            busynessLabel = 'Moderate Traffic';
            busynessColor = '#4FACFE';
            isRecommendedToDrive = true;
            helpfulVerdict = `Mostly manageable flow with ${delayMin} min minor slowdown in urban approaches. Helpful to drive—allow one buffer rest stop.`;
          }

          return {
            index: idx,
            description:
              rt.description?.trim() ||
              (idx === 0 ? 'Primary Motorway / Fastest Corridor' : `Alternative Route ${idx + 1}`),
            distanceKm,
            durationMin,
            staticDurationMin,
            delayMin,
            busynessLabel,
            busynessColor,
            helpfulVerdict,
            isRecommendedToDrive,
            warnings: rt.warnings ?? [],
            routeLabels: (rt.routeLabels ?? []).map(String),
            slowSegmentsCount,
            jamSegmentsCount,
          };
        });

        renderPolylines(routes, 0, map);
        onRoutesComputed(summaries, null);
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : 'Unable to fetch live Google Maps routes.';
        if (/OVER_QUERY_LIMIT|RESOURCE_EXHAUSTED|Quota|429/i.test(msg)) {
          triggerQuotaExceededNotice();
        }
        onRoutesComputed([], msg);
      }
    };

    runCompute();

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((pl) => pl.setMap(null));
      polylinesRef.current = [];
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, routesLib, origin.lat, origin.lng, destination.lat, destination.lng]);

  // Re-highlight polylines when user selects an alternative Google route
  useEffect(() => {
    if (!map || computedRoutesRef.current.length === 0) return;
    renderPolylines(computedRoutesRef.current, selectedGoogleRouteIdx, map);
  }, [map, selectedGoogleRouteIdx]);

  return null;
};

export const NavigationScreen: React.FC<NavigationScreenProps> = ({
  vehicle,
  batteryPct,
  airReport,
  bluetooth,
  selectedRouteId,
  onSelectRoute,
  preconditioning,
  onTogglePreconditioning,
}) => {
  const apiKey = getGoogleMapsApiKey();

  const [selectedPlanByRoute, setSelectedPlanByRoute] = useState<
    Record<string, string>
  >({});
  const [selectedTerminalIds, setSelectedTerminalIds] = useState<string[]>([
    'term-bhera',
    'term-samundri',
    'term-mre-isb',
    'term-burhan',
    'term-khi-sukkur',
  ]);
  const [addedChargerIds, setAddedChargerIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showTrafficLayer, setShowTrafficLayer] = useState<boolean>(true);
  const [googleSummaries, setGoogleSummaries] = useState<ComputedRouteSummary[]>([]);
  const [selectedGoogleIdx, setSelectedGoogleIdx] = useState<number>(0);
  const [routesError, setRoutesError] = useState<string | null>(null);

  const route =
    ROUTE_OPTIONS.find((r) => r.id === selectedRouteId) ?? ROUTE_OPTIONS[0];

  const activePlanId = selectedPlanByRoute[route.id] ?? route.plans[0].id;
  const activePlan =
    route.plans.find((p) => p.id === activePlanId) ?? route.plans[0];

  const activeGoogleRoute =
    googleSummaries[selectedGoogleIdx] ?? googleSummaries[0] ?? null;

  const activeTerminals = route.terminals.filter((t) =>
    selectedTerminalIds.includes(t.id)
  );
  const activeChargers = route.chargers.filter((c) =>
    addedChargerIds.includes(c.id)
  );

  // Use live Google Maps duration & distance when available, falling back cleanly to corridor spec
  const effectiveDistanceKm = activeGoogleRoute
    ? activeGoogleRoute.distanceKm
    : activePlan.distanceKm;
  const driveMin = activeGoogleRoute
    ? activeGoogleRoute.durationMin
    : activePlan.driveDurationMin;

  const terminalRestMin = activeTerminals.reduce(
    (sum, t) => sum + t.restDurationMin,
    0
  );
  const chargerTimeMin = activeChargers.reduce(
    (sum, c) => sum + c.chargeDurationMin + c.detourMin,
    0
  );
  const totalRestAndStopMin =
    terminalRestMin > 0 || chargerTimeMin > 0
      ? terminalRestMin + chargerTimeMin
      : activePlan.recommendedRestMin;

  const totalTripMin = driveMin + totalRestAndStopMin;

  // Vehicle range calculation using selected vehicle's full range + batteryPct
  const currentVehicleRangeKm = Math.round((batteryPct / 100) * vehicle.rangeKmFull);
  const terminalChargeSoc = activeTerminals.reduce(
    (sum, t) => sum + t.addedSocPct,
    0
  );
  const chargerAddedSoc = activeChargers.reduce(
    (sum, c) => sum + c.addedSocPct,
    0
  );
  const rangeNeededPct = Math.round(
    (effectiveDistanceKm / Math.max(150, vehicle.rangeKmFull)) * 100
  );
  const arrivalSoc = Math.min(
    99,
    Math.max(4, Math.round(batteryPct - rangeNeededPct + terminalChargeSoc + chargerAddedSoc))
  );

  const needsChargeStop =
    currentVehicleRangeKm < effectiveDistanceKm &&
    terminalChargeSoc + chargerAddedSoc < rangeNeededPct - batteryPct + 15;

  const toggleTerminal = (id: string) => {
    setSelectedTerminalIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleCharger = (id: string) => {
    setAddedChargerIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredRoutes = ROUTE_OPTIONS.filter(
    (r) =>
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.plans.some((p) => p.highway.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleRoutesComputed = (
    summaries: ComputedRouteSummary[],
    errorMsg: string | null
  ) => {
    setGoogleSummaries(summaries);
    setSelectedGoogleIdx(0);
    setRoutesError(errorMsg);
  };

  // Build SVG elevation path
  const maxElev = Math.max(...route.elevationProfile, 750);
  const minElev = Math.min(...route.elevationProfile, 50);
  const elevPoints = route.elevationProfile
    .map((val, idx) => {
      const x = (idx / (route.elevationProfile.length - 1)) * 380 + 10;
      const y = 78 - ((val - minElev) / (maxElev - minElev || 1)) * 58;
      return `${x},${y}`;
    })
    .join(' ');

  // Overall Drive Helpfulness Evaluation
  const roadIsClear = activeGoogleRoute ? activeGoogleRoute.isRecommendedToDrive : true;
  const helpfulStatusTitle = !roadIsClear
    ? 'Caution: Road Busy — Consider Alternate Route or Rest Timing'
    : needsChargeStop
      ? 'Helpful Route — Add One Rest / Charge Terminal Along Way'
      : 'Helpful & Recommended Route to Drive';

  const helpfulColor = !roadIsClear || needsChargeStop ? '#F59E0B' : '#10E7A9';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* LEFT: CORRIDOR LIST & LIVE VEHICLE LINK SUMMARY (4 columns) */}
      <div className="lg:col-span-4 flex flex-col gap-5">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="kh-label-caps text-[#849495]">
            Google Maps Pakistan Network
          </div>
          <h2 className="font-display text-2xl font-semibold text-[#E1E2EB] mt-1 mb-1">
            Lahore Route Planner
          </h2>
          <p className="text-xs text-[#849495] mb-4">
            Choose a destination city from Lahore to evaluate all Google Maps routes, road busyness, and rest terminals.
          </p>

          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search city (Islamabad, Multan, Karachi...)"
            aria-label="Search Pakistani city route"
            className="w-full min-h-[48px] px-4 rounded-xl bg-[#0B0E14] border border-white/[0.12] text-sm text-[#E1E2EB] placeholder-[#849495] focus:outline-none focus:border-[#00F2FE] transition-colors"
          />

          <div className="mt-4 flex flex-col gap-3">
            {filteredRoutes.length === 0 ? (
              <div className="p-4 rounded-2xl bg-[#0B0E14] border border-white/[0.06] text-xs text-[#849495]">
                No routes match &quot;{searchQuery}&quot;. Try Islamabad, Multan, Murree, Peshawar, or Karachi.
              </div>
            ) : (
              filteredRoutes.map((r) => {
                const selected = r.id === route.id;
                const defaultPlan = r.plans[0];
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setGoogleSummaries([]);
                      setRoutesError(null);
                      onSelectRoute(r.id);
                    }}
                    className={`w-full text-left p-4 rounded-2xl border transition-all duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
                      selected
                        ? 'bg-[#191C22] border-[#00F2FE]/60'
                        : 'bg-[#0B0E14] border-white/[0.08] hover:border-white/[0.2]'
                    }`}
                    style={
                      selected
                        ? { boxShadow: '0 0 18px rgba(0, 242, 254, 0.14)' }
                        : undefined
                    }
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-display text-[15px] font-semibold text-[#E1E2EB] truncate">
                        {r.name}
                      </span>
                      <span className="font-mono tabular-nums text-xs text-[#4FACFE] shrink-0">
                        {defaultPlan.distanceKm} km
                      </span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-[#849495] font-mono tabular-nums">
                      <span>{formatDuration(defaultPlan.driveDurationMin)} est.</span>
                      <span aria-hidden="true">·</span>
                      <span>{r.plans.length} plans</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#10E7A9]">{r.terminals.length} terminals</span>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </section>

        {/* Active Vehicle, Bluetooth & Air Status Card */}
        <section className="rounded-[1.5rem] kh-glass p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-2xl bg-[#00F2FE]/15 border border-[#00F2FE]/40 flex items-center justify-center text-[#00F2FE] shrink-0">
              <Car className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="kh-label-caps text-[#00F2FE]">Vehicle & Bluetooth Readiness</div>
              <div className="font-display text-base font-semibold text-[#E1E2EB] truncate">
                {vehicle.name}
              </div>
            </div>
          </div>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="flex items-center justify-between text-[#B9CACB]">
              <span className="inline-flex items-center gap-1.5">
                <BluetoothConnected className="w-3.5 h-3.5 text-[#4FACFE]" />
                Car Bluetooth
              </span>
              <span
                className={
                  bluetooth.status === 'connected' ? 'text-[#10E7A9]' : 'text-[#F59E0B]'
                }
              >
                {bluetooth.status === 'connected' ? 'Paired & Synced' : 'Not Paired Yet'}
              </span>
            </div>

            <div className="flex items-center justify-between text-[#B9CACB]">
              <span className="inline-flex items-center gap-1.5">
                <Wind className="w-3.5 h-3.5 text-[#10E7A9]" />
                Cabin Air Quality
              </span>
              <span className="text-[#E1E2EB]">
                {airReport.status === 'complete'
                  ? `PM2.5 ${airReport.cabinPm25} µg/m³`
                  : 'Run Check in 4D Tab'}
              </span>
            </div>

            <div className="flex items-center justify-between text-[#B9CACB]">
              <span>Available Range</span>
              <span className="text-[#00F2FE] tabular-nums">
                {currentVehicleRangeKm} km ({batteryPct.toFixed(0)}%)
              </span>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/[0.08] flex items-center justify-between">
            <span className="text-xs text-[#849495]">
              Battery / Cabin Pre-Conditioning
            </span>
            <button
              type="button"
              onClick={() => onTogglePreconditioning(!preconditioning)}
              className={`min-h-[36px] px-3.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                preconditioning
                  ? 'bg-[#00F2FE] text-[#0B0E14] font-semibold'
                  : 'bg-[#191C22] border border-white/[0.14] text-[#E1E2EB] hover:border-white/50'
              }`}
            >
              {preconditioning ? 'Pre-Heating Active' : 'Pre-Condition'}
            </button>
          </div>
        </section>

        {/* Departure Guidance HUD */}
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="flex items-center gap-3 mb-2">
            <Navigation className="w-4 h-4 text-[#4FACFE]" />
            <span className="kh-label-caps text-[#4FACFE]">Lahore Departure</span>
          </div>
          <p className="text-sm text-[#E1E2EB] leading-snug">{route.nextManeuver}</p>
          <div className="mt-4 pt-3 border-t border-white/[0.08] grid grid-cols-2 gap-3 text-xs font-mono tabular-nums">
            <div>
              <div className="kh-label-caps text-[#849495]">Depart</div>
              <div className="text-[#E1E2EB] mt-0.5">{activePlan.departureTime}</div>
            </div>
            <div>
              <div className="kh-label-caps text-[#849495]">Target Arrival</div>
              <div className="text-[#10E7A9] mt-0.5">{activePlan.arrivalSummary}</div>
            </div>
          </div>
        </section>
      </div>

      {/* RIGHT: GOOGLE MAPS VIEWPORT, TRAFFIC BUSYNESS, HELPFUL VERDICT & ROUTE DESCRIPTIONS (8 columns) */}
      <div className="lg:col-span-8 flex flex-col gap-6">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          {/* Header Metrics */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-white/[0.08]">
            <div>
              <div className="kh-label-caps text-[#849495]">
                Google Maps Route & Traffic Check
              </div>
              <h3 className="font-display text-xl font-semibold text-[#E1E2EB] mt-0.5">
                {route.origin} → {route.destination}
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-5">
              <button
                type="button"
                role="switch"
                aria-checked={showTrafficLayer}
                onClick={() => setShowTrafficLayer((prev) => !prev)}
                className={`inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full border text-xs font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  showTrafficLayer
                    ? 'bg-[#10E7A9] text-[#0B0E14] border-transparent'
                    : 'bg-[#0B0E14] border-white/[0.16] text-[#E1E2EB]'
                }`}
              >
                <TrafficCone className="w-4 h-4" />
                <span>Live Traffic Layer</span>
              </button>

              <div>
                <div className="kh-label-caps text-[#849495]">Drive Time</div>
                <div className="font-mono tabular-nums text-lg font-semibold text-[#E1E2EB]">
                  {formatDuration(driveMin)}
                </div>
              </div>
              <div>
                <div className="kh-label-caps text-[#849495]">Rest / Stay</div>
                <div className="font-mono tabular-nums text-lg font-semibold text-[#4FACFE]">
                  {formatDuration(totalRestAndStopMin)}
                </div>
              </div>
              <div>
                <div className="kh-label-caps text-[#849495]">Total Time</div>
                <div className="font-mono tabular-nums text-lg font-semibold text-[#00F2FE]">
                  {formatDuration(totalTripMin)}
                </div>
              </div>
              <div>
                <div className="kh-label-caps text-[#849495]">Arrival Reserve</div>
                <div
                  className="font-mono tabular-nums text-lg font-semibold"
                  style={{ color: arrivalSoc < 15 ? '#F59E0B' : '#10E7A9' }}
                >
                  {arrivalSoc}%
                </div>
              </div>
            </div>
          </div>

          {/* HELPFULNESS TO DRIVE & ROAD BUSYNESS EVALUATION BANNER */}
          <div
            className="mt-5 rounded-2xl bg-[#0B0E14] border p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            style={{ borderColor: `${helpfulColor}66` }}
          >
            <div className="flex items-start gap-3">
              {roadIsClear && !needsChargeStop ? (
                <CheckCircle2
                  className="w-5 h-5 shrink-0 mt-0.5"
                  style={{ color: helpfulColor }}
                />
              ) : (
                <AlertTriangle
                  className="w-5 h-5 shrink-0 mt-0.5"
                  style={{ color: helpfulColor }}
                />
              )}
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className="font-display text-sm font-semibold"
                    style={{ color: helpfulColor }}
                  >
                    {helpfulStatusTitle}
                  </span>
                  {activeGoogleRoute && (
                    <span className="font-mono text-[11px] px-2.5 py-0.5 rounded-full bg-white/[0.06] text-[#E1E2EB]">
                      Road Status: {activeGoogleRoute.busynessLabel}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#B9CACB] mt-1 leading-relaxed">
                  {activeGoogleRoute
                    ? `${activeGoogleRoute.helpfulVerdict} Route selected: ${activeGoogleRoute.description} (${activeGoogleRoute.distanceKm} km, ${activeGoogleRoute.delayMin} min live traffic delay).`
                    : route.corridorDescription}
                </p>
              </div>
            </div>
          </div>

          {/* GOOGLE MAPS PLATFORM INTERACTIVE MAP */}
          <div className="mt-5 rounded-2xl overflow-hidden border border-white/[0.1] bg-[#0B0E14]">
            {apiKey ? (
              <APIProvider
                apiKey={apiKey}
                libraries={['routes', 'maps', 'marker']}
                language="en"
                region="PK"
              >
                <Map
                  mapId="DEMO_MAP_ID"
                  colorScheme="DARK"
                  defaultCenter={route.originCoords}
                  defaultZoom={7}
                  gestureHandling="greedy"
                  internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                  className="w-full h-[420px] lg:h-[460px]"
                >
                  <GoogleTrafficOverlay enabled={showTrafficLayer} />
                  <GoogleRoutesController
                    origin={route.originCoords}
                    destination={route.destinationCoords}
                    selectedGoogleRouteIdx={selectedGoogleIdx}
                    onRoutesComputed={handleRoutesComputed}
                  />

                  {/* Origin Marker */}
                  <AdvancedMarker
                    position={route.originCoords}
                    title={`Origin: ${route.origin}`}
                  >
                    <Pin
                      background="#00F2FE"
                      borderColor="#0B0E14"
                      glyphColor="#0B0E14"
                    />
                  </AdvancedMarker>

                  {/* Destination Marker */}
                  <AdvancedMarker
                    position={route.destinationCoords}
                    title={`Destination: ${route.destination}`}
                  >
                    <Pin
                      background="#10E7A9"
                      borderColor="#0B0E14"
                      glyphColor="#0B0E14"
                    />
                  </AdvancedMarker>

                  {/* Rest Terminal Markers */}
                  {route.terminals.map((term) => {
                    const included = selectedTerminalIds.includes(term.id);
                    return (
                      <AdvancedMarker
                        key={term.id}
                        position={term.coords}
                        title={`${term.name} (${term.highwayMarker})`}
                        onClick={() => toggleTerminal(term.id)}
                      >
                        <Pin
                          background={included ? '#4FACFE' : '#1F2937'}
                          borderColor="#FFFFFF"
                          glyphColor="#FFFFFF"
                          scale={0.85}
                        />
                      </AdvancedMarker>
                    );
                  })}
                </Map>
              </APIProvider>
            ) : (
              <div className="h-[320px] flex flex-col items-center justify-center p-6 text-center">
                <AlertTriangle className="w-7 h-7 text-[#F59E0B] mb-2" />
                <div className="font-display text-base font-semibold text-[#E1E2EB]">
                  Google Maps API Key Required
                </div>
                <p className="text-xs text-[#849495] max-w-md mt-1">
                  Configure VITE_GOOGLE_MAPS_API_KEY in your environment to load the interactive Google Maps traffic and route view.
                </p>
              </div>
            )}

            {/* Elevation Profile Strip */}
            <div className="p-4 border-t border-white/[0.08] bg-[#10131A]/95 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2.5 shrink-0">
                <Mountain className="w-4 h-4 text-[#10E7A9]" />
                <div>
                  <div className="kh-label-caps text-[#849495]">
                    Elevation & Efficiency Profile
                  </div>
                  <div className="font-mono tabular-nums text-xs text-[#E1E2EB]">
                    +{activePlan.elevationGainM} m climb · {activePlan.regenRecoveryKwh} kWh recovery ·{' '}
                    {effectiveDistanceKm} km total
                  </div>
                </div>
              </div>

              <svg viewBox="0 0 400 90" className="w-full sm:w-56 h-14 shrink-0">
                <polyline
                  points={elevPoints}
                  fill="none"
                  stroke="#4FACFE"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
          </div>

          {routesError && (
            <div className="mt-4 rounded-xl bg-[#F59E0B]/10 border border-[#F59E0B]/35 p-3.5 text-xs text-[#F59E0B]">
              Live Google Maps Routes notice: {routesError} Showing verified corridor plans and terminal timelines below.
            </div>
          )}

          {/* LIVE GOOGLE MAPS ROUTES & ROAD BUSYNESS COMPARISON */}
          <div className="mt-6">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <RouteIcon className="w-4 h-4 text-[#00F2FE]" />
                <span className="kh-label-caps text-[#849495]">
                  Google Maps Route Options & Road Busyness Comparison
                </span>
              </div>
              <span className="font-mono text-xs text-[#849495]">
                Click a route to inspect on Google Maps
              </span>
            </div>

            {googleSummaries.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {googleSummaries.map((gr) => {
                  const isActive = gr.index === selectedGoogleIdx;
                  return (
                    <button
                      key={`${gr.index}-${gr.description}`}
                      type="button"
                      onClick={() => setSelectedGoogleIdx(gr.index)}
                      className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#191C22] border-[#00F2FE]/70'
                          : 'bg-[#0B0E14] border-white/[0.08] hover:border-white/[0.22]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-display text-sm font-semibold text-[#E1E2EB]">
                          Route {gr.index + 1}: {gr.description}
                        </span>
                        <span
                          className="font-mono text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white/[0.06] shrink-0"
                          style={{ color: gr.busynessColor }}
                        >
                          {gr.busynessLabel}
                        </span>
                      </div>

                      <div className="mt-2 flex flex-wrap items-center gap-3 font-mono tabular-nums text-xs text-[#4FACFE]">
                        <span>{gr.distanceKm} km</span>
                        <span>·</span>
                        <span>{formatDuration(gr.durationMin)} live traffic</span>
                        <span>·</span>
                        <span className="text-[#849495]">
                          +{gr.delayMin} min delay vs free-flow
                        </span>
                      </div>

                      <p className="mt-2 text-xs text-[#B9CACB] leading-relaxed">
                        {gr.helpfulVerdict}
                      </p>

                      {gr.warnings.length > 0 && (
                        <div className="mt-2 text-[11px] text-[#F59E0B]">
                          Notice: {gr.warnings[0]}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-2xl bg-[#0B0E14] border border-white/[0.08] p-4 text-xs text-[#B9CACB]">
                {route.corridorDescription}
              </div>
            )}
          </div>

          {/* FULL DESCRIPTION OF ALL CORRIDOR PLANS & TIMELINES */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="kh-label-caps text-[#849495]">
                All Corridor Route Descriptions & Schedules ({route.plans.length} Plans)
              </span>
              <span className="font-mono text-xs text-[#849495]">
                Motorways vs National Highways
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {route.plans.map((plan) => {
                const selected = plan.id === activePlan.id;
                return (
                  <button
                    key={plan.id}
                    type="button"
                    onClick={() =>
                      setSelectedPlanByRoute((prev) => ({
                        ...prev,
                        [route.id]: plan.id,
                      }))
                    }
                    className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
                      selected
                        ? 'bg-[#191C22] border-[#00F2FE]/65'
                        : 'bg-[#0B0E14] border-white/[0.08] hover:border-white/[0.2]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-display text-sm font-semibold text-[#E1E2EB]">
                        {plan.label}
                      </span>
                      <span className="font-mono tabular-nums text-xs text-[#00F2FE]">
                        {formatDuration(plan.driveDurationMin + plan.recommendedRestMin)}
                      </span>
                    </div>
                    <div className="mt-1 font-mono text-[11px] text-[#4FACFE]">
                      {plan.highway} · {plan.distanceKm} km
                    </div>
                    <p className="mt-2 text-xs text-[#B9CACB] leading-relaxed">
                      {plan.summary}
                    </p>
                    <div className="mt-3 pt-2.5 border-t border-white/[0.06] flex items-center justify-between font-mono tabular-nums text-[11px] text-[#849495]">
                      <span>Drive {formatDuration(plan.driveDurationMin)}</span>
                      <span>Rest {formatDuration(plan.recommendedRestMin)}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* REST TERMINALS & OVERNIGHT STAY POINTS */}
          <div className="mt-6">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <Coffee className="w-4 h-4 text-[#10E7A9]" />
                <span className="kh-label-caps text-[#849495]">
                  Rest Terminals & Stay Points Along Route
                </span>
              </div>
              <span className="font-mono text-xs text-[#849495]">
                Tap markers or Add Stop to adjust total travel timeline
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {route.terminals.map((term) => {
                const included = selectedTerminalIds.includes(term.id);
                const isOvernight = term.restDurationMin >= 180;
                return (
                  <div
                    key={term.id}
                    className={`rounded-2xl p-4 border transition-colors ${
                      included
                        ? 'bg-[#191C22] border-[#10E7A9]/55'
                        : 'bg-[#0B0E14] border-white/[0.08]'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2.5">
                          {isOvernight ? (
                            <BedDouble className="w-4 h-4 text-[#00F2FE] shrink-0" />
                          ) : (
                            <Coffee className="w-4 h-4 text-[#10E7A9] shrink-0" />
                          )}
                          <span className="font-display text-[15px] font-semibold text-[#E1E2EB]">
                            {term.name}
                          </span>
                          <span className="font-mono text-xs text-[#4FACFE]">
                            {term.highwayMarker}
                          </span>
                          <span className="font-mono text-xs text-[#849495]">
                            · {term.category}
                          </span>
                        </div>

                        <p className="mt-1.5 text-xs text-[#B9CACB] leading-relaxed">
                          {term.stayNote}
                        </p>

                        <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs text-[#849495] font-mono tabular-nums">
                          <span className="inline-flex items-center gap-1 text-[#E1E2EB]">
                            <Clock className="w-3.5 h-3.5 text-[#10E7A9]" />
                            Rest {formatDuration(term.restDurationMin)}
                          </span>
                          {term.hasFastChargerKw && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-[#00F2FE]">
                                {term.hasFastChargerKw} kW EV (+{term.addedSocPct}% SoC)
                              </span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>{term.facilities.join(' · ')}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => toggleTerminal(term.id)}
                        className={`inline-flex items-center gap-1.5 min-h-[42px] px-4 rounded-full text-xs font-semibold transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                          included
                            ? 'bg-[#10E7A9] text-[#0B0E14]'
                            : 'bg-[#191C22] border border-white/[0.14] text-[#E1E2EB] hover:border-white/60'
                        }`}
                      >
                        {included ? (
                          <Check className="w-3.5 h-3.5" />
                        ) : (
                          <Plus className="w-3.5 h-3.5" />
                        )}
                        <span>{included ? 'Stop Included' : 'Add Rest Stop'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Dedicated High-Power Charging Hubs */}
          <div className="mt-6 pt-6 border-t border-white/[0.06]">
            <div className="flex items-center justify-between mb-3">
              <span className="kh-label-caps text-[#849495]">
                Express EV Charging Hubs
              </span>
              <span className="font-mono text-xs text-[#849495]">
                Optional rapid DC top-ups
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {route.chargers.map((ch) => {
                const added = addedChargerIds.includes(ch.id);
                return (
                  <div
                    key={ch.id}
                    className={`rounded-2xl p-4 border transition-colors ${
                      added
                        ? 'bg-[#191C22] border-[#00F2FE]/55'
                        : 'bg-[#0B0E14] border-white/[0.08]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-[#00F2FE] shrink-0" />
                          <span className="font-display text-sm font-semibold text-[#E1E2EB] truncate">
                            {ch.name}
                          </span>
                        </div>
                        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-[#849495] font-mono tabular-nums">
                          <span>Km {ch.corridorKm}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#00F2FE]">{ch.maxKw} kW</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#10E7A9]">
                            {ch.availableStalls}/{ch.totalStalls} stalls free
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{ch.pricePerKwh}/kWh</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => toggleCharger(ch.id)}
                        className={`inline-flex items-center gap-1.5 min-h-[40px] px-4 rounded-full text-xs font-semibold transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                          added
                            ? 'bg-[#00F2FE] text-[#0B0E14]'
                            : 'bg-[#191C22] border border-white/[0.14] text-[#E1E2EB] hover:border-white/60'
                        }`}
                      >
                        {added ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                        <span>{added ? 'Added' : 'Add Charge'}</span>
                      </button>
                    </div>

                    <div className="mt-3 pt-3 border-t border-white/[0.06] flex items-center justify-between text-xs font-mono tabular-nums text-[#B9CACB]">
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-[#849495]" />+{ch.detourMin} min detour
                      </span>
                      <span>
                        {ch.chargeDurationMin} min stop (+{ch.addedSocPct}% SoC)
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
