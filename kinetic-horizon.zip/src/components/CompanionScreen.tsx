import React from 'react';
import { Lock, Unlock, Zap, Wind, Shield, KeyRound } from 'lucide-react';
import {
  BluetoothLinkState,
  ClimateState,
  VehicleProfile,
} from '../types/vehicle';
import { HapticToggle } from './HapticToggle';

interface CompanionScreenProps {
  vehicle: VehicleProfile;
  bluetooth: BluetoothLinkState;
  batteryPct: number;
  rangeKm: number;
  isCharging: boolean;
  locked: boolean;
  onToggleLock: () => void;
  frunkOpen: boolean;
  onToggleFrunk: () => void;
  trunkOpen: boolean;
  onToggleTrunk: () => void;
  chargePortOpen: boolean;
  onToggleChargePort: () => void;
  sentryActive: boolean;
  onToggleSentry: (val: boolean) => void;
  climate: ClimateState;
  onUpdateClimate: (patch: Partial<ClimateState>) => void;
}

export const CompanionScreen: React.FC<CompanionScreenProps> = ({
  vehicle,
  bluetooth,
  batteryPct,
  rangeKm,
  isCharging,
  locked,
  onToggleLock,
  frunkOpen,
  onToggleFrunk,
  trunkOpen,
  onToggleTrunk,
  chargePortOpen,
  onToggleChargePort,
  sentryActive,
  onToggleSentry,
  climate,
  onUpdateClimate,
}) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* LEFT: COMPANION SPEC & LIVE SYNC CONTEXT (6 columns) */}
      <div className="lg:col-span-6 flex flex-col gap-6">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-7">
          <span className="kh-label-caps text-[#4FACFE]">Mobile Pairing Viewport · 4-Column Layout</span>
          <h2 className="font-display text-3xl font-semibold text-[#E1E2EB] mt-2 text-balance">
            Remote Vehicle Companion
          </h2>
          <p className="mt-3 text-[15px] text-[#B9CACB] leading-relaxed">
            Connected to <span className="text-[#E1E2EB] font-medium">{vehicle.name}</span>. Mirrors every live cockpit state in real time—from cabin thermal pre-conditioning and HEPA air checks to Bluetooth vehicle pairing.
          </p>

          <div className="mt-6 grid grid-cols-2 gap-4 pt-6 border-t border-white/[0.08]">
            <div>
              <div className="kh-label-caps text-[#849495]">Bluetooth Link</div>
              <div className="mt-1 flex items-center gap-2 text-sm font-medium text-[#10E7A9]">
                <KeyRound className="w-4 h-4" />
                <span>
                  {bluetooth.status === 'connected'
                    ? `${bluetooth.deviceName}`
                    : 'Ready to Pair in 4D Tab'}
                </span>
              </div>
            </div>
            <div>
              <div className="kh-label-caps text-[#849495]">Telemetry Link</div>
              <div className="mt-1 font-mono tabular-nums text-sm font-medium text-[#E1E2EB]">
                Synced · {vehicle.powertrain}
              </div>
            </div>
          </div>
        </section>

        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <span className="kh-label-caps text-[#849495]">Quick Remote Toggles</span>
          <div className="mt-4 flex flex-col gap-3">
            <HapticToggle
              label="Pre-Condition Cabin"
              description={`Target ${climate.driverTempC.toFixed(1)}°C before departure`}
              checked={climate.preConditionCabin}
              onChange={(v) => onUpdateClimate({ preConditionCabin: v })}
              accent="cyan"
            />
            <HapticToggle
              label="Sentry Perimeter Watch"
              description="Push alerts on proximity intrusion"
              checked={sentryActive}
              onChange={onToggleSentry}
              accent="green"
            />
          </div>
        </section>
      </div>

      {/* RIGHT: 4-COLUMN MOBILE DEVICE PREVIEW (6 columns) */}
      <div className="lg:col-span-6 flex justify-center">
        <div className="w-full max-w-[390px] rounded-[2.5rem] bg-[#0B0E14] border border-white/[0.16] p-4 shadow-[0_0_50px_rgba(0,242,254,0.08)]">
          {/* Device Notch & Status Strip */}
          <div className="flex items-center justify-between px-3 py-2 text-xs font-mono text-[#849495]">
            <span>09:42</span>
            <div className="w-20 h-4 rounded-full bg-[#161B26] border border-white/[0.08]" />
            <span>{bluetooth.status === 'connected' ? 'BT · UWB' : '5G · UWB'}</span>
          </div>

          {/* 4-column mobile stack (margin-mobile: 16px -> p-4) */}
          <div className="mt-2 flex flex-col gap-3.5">
            {/* Vehicle Header Tile */}
            <div className="rounded-2xl bg-[#131722] border border-white/[0.08] p-4">
              <div className="flex items-center justify-between">
                <div className="min-w-0 pr-2">
                  <div className="kh-label-caps text-[#849495]">
                    {vehicle.bodyType.toUpperCase()} · {vehicle.powertrain}
                  </div>
                  <div className="font-display text-lg font-semibold text-[#E1E2EB] mt-0.5 truncate">
                    {vehicle.name}
                  </div>
                </div>
                <span
                  className={`font-mono text-xs font-medium shrink-0 ${
                    locked ? 'text-[#849495]' : 'text-[#00F2FE]'
                  }`}
                >
                  {locked ? 'Locked' : 'Unlocked'}
                </span>
              </div>

              {/* Compact SVG Coupe Top/Side Icon + SoC */}
              <div className="mt-4 flex items-end justify-between">
                <div>
                  <div className="font-mono tabular-nums text-3xl font-semibold text-[#10E7A9]">
                    {batteryPct.toFixed(0)}%
                  </div>
                  <div className="font-mono tabular-nums text-xs text-[#B9CACB] mt-0.5">
                    {rangeKm} km · {isCharging ? 'Charging' : 'Parked'}
                  </div>
                </div>

                <div className="text-right">
                  <div className="kh-label-caps text-[#849495]">Cabin</div>
                  <div className="font-mono tabular-nums text-sm font-medium text-[#E1E2EB] mt-0.5">
                    {climate.driverTempC.toFixed(1)}°C
                  </div>
                </div>
              </div>

              <div className="mt-3 h-2 rounded-full bg-[#0B0E14] overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-200"
                  style={{
                    width: `${batteryPct}%`,
                    backgroundColor: isCharging
                      ? '#00F2FE'
                      : batteryPct < 10
                        ? '#F59E0B'
                        : '#10E7A9',
                  }}
                />
              </div>
            </div>

            {/* 4-Column Quick Action Touch Bar (48px+ targets) */}
            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                onClick={onToggleLock}
                aria-label={locked ? 'Unlock vehicle' : 'Lock vehicle'}
                className={`min-h-[56px] rounded-2xl border flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                  !locked
                    ? 'bg-[#00F2FE] text-[#0B0E14] border-transparent'
                    : 'bg-[#131722] border-white/[0.08] text-[#E1E2EB]'
                }`}
              >
                {locked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                <span className="text-[10px] font-mono uppercase">
                  {locked ? 'Lock' : 'Open'}
                </span>
              </button>

              <button
                type="button"
                onClick={() =>
                  onUpdateClimate({ preConditionCabin: !climate.preConditionCabin })
                }
                aria-label="Toggle cabin climate"
                className={`min-h-[56px] rounded-2xl border flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                  climate.preConditionCabin
                    ? 'bg-[#00F2FE]/20 border-[#00F2FE]/60 text-[#E0FDFF]'
                    : 'bg-[#131722] border-white/[0.08] text-[#E1E2EB]'
                }`}
              >
                <Wind className="w-4 h-4" />
                <span className="text-[10px] font-mono uppercase">Climate</span>
              </button>

              <button
                type="button"
                onClick={onToggleChargePort}
                aria-label="Toggle charge port"
                className={`min-h-[56px] rounded-2xl border flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                  chargePortOpen
                    ? 'bg-[#10E7A9]/20 border-[#10E7A9]/60 text-[#10E7A9]'
                    : 'bg-[#131722] border-white/[0.08] text-[#E1E2EB]'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span className="text-[10px] font-mono uppercase">Port</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleSentry(!sentryActive)}
                aria-label="Toggle sentry"
                className={`min-h-[56px] rounded-2xl border flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                  sentryActive
                    ? 'bg-[#4FACFE]/20 border-[#4FACFE]/60 text-[#9BCBFF]'
                    : 'bg-[#131722] border-white/[0.08] text-[#E1E2EB]'
                }`}
              >
                <Shield className="w-4 h-4" />
                <span className="text-[10px] font-mono uppercase">Sentry</span>
              </button>
            </div>

            {/* Frunk & Trunk Access List */}
            <div className="rounded-2xl bg-[#131722] border border-white/[0.08] divide-y divide-white/[0.06]">
              <button
                type="button"
                onClick={onToggleFrunk}
                className="w-full min-h-[52px] px-4 flex items-center justify-between text-left cursor-pointer"
              >
                <span className="text-sm font-medium text-[#E1E2EB]">Front Trunk (Frunk)</span>
                <span
                  className={`font-mono text-xs ${
                    frunkOpen ? 'text-[#00F2FE]' : 'text-[#849495]'
                  }`}
                >
                  {frunkOpen ? 'Open' : 'Closed'}
                </span>
              </button>
              <button
                type="button"
                onClick={onToggleTrunk}
                className="w-full min-h-[52px] px-4 flex items-center justify-between text-left cursor-pointer"
              >
                <span className="text-sm font-medium text-[#E1E2EB]">Rear Hatch</span>
                <span
                  className={`font-mono text-xs ${
                    trunkOpen ? 'text-[#00F2FE]' : 'text-[#849495]'
                  }`}
                >
                  {trunkOpen ? 'Open' : 'Closed'}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
