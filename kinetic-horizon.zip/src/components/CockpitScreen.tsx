import React from 'react';
import { Minus, Plus, Navigation, Wind, Gauge, ArrowUpRight } from 'lucide-react';
import { DRIVE_MODE_SPECS, ROUTE_OPTIONS } from '../data/vehicleData';
import {
  AirQualityReport,
  BluetoothLinkState,
  ClimateState,
  DriveMode,
  Gear,
  ScreenId,
  TireTelemetry,
  VehicleProfile,
} from '../types/vehicle';
import { BatteryFluxBar } from './BatteryFluxBar';
import { HapticToggle } from './HapticToggle';
import { KineticSlider } from './KineticSlider';

interface CockpitScreenProps {
  vehicle: VehicleProfile;
  bluetooth: BluetoothLinkState;
  airReport: AirQualityReport;
  driveMode: DriveMode;
  gear: Gear;
  onChangeGear: (gear: Gear) => void;
  speedKmh: number;
  powerKw: number;
  cruiseEnabled: boolean;
  cruiseTargetKmh: number;
  onToggleCruise: () => void;
  onAdjustCruise: (delta: number) => void;
  onThrottlePulse: () => void;
  onRegenBrakePulse: () => void;
  batteryPct: number;
  rangeKm: number;
  isCharging: boolean;
  chargingRateKw: number;
  batteryTempC: number;
  onSimulateCharging: () => void;
  onSimulateLowBattery: () => void;
  onResetNominal: () => void;
  climate: ClimateState;
  onUpdateClimate: (patch: Partial<ClimateState>) => void;
  tires: TireTelemetry[];
  selectedRouteId: string;
  onOpenNavigation: () => void;
  onNavigateScreen: (screen: ScreenId) => void;
}

const GEARS: Gear[] = ['P', 'R', 'N', 'D'];

export const CockpitScreen: React.FC<CockpitScreenProps> = ({
  vehicle,
  bluetooth,
  airReport,
  driveMode,
  gear,
  onChangeGear,
  speedKmh,
  powerKw,
  cruiseEnabled,
  cruiseTargetKmh,
  onToggleCruise,
  onAdjustCruise,
  onThrottlePulse,
  onRegenBrakePulse,
  batteryPct,
  rangeKm,
  isCharging,
  chargingRateKw,
  batteryTempC,
  onSimulateCharging,
  onSimulateLowBattery,
  onResetNominal,
  climate,
  onUpdateClimate,
  tires,
  selectedRouteId,
  onOpenNavigation,
  onNavigateScreen,
}) => {
  const modeSpec = DRIVE_MODE_SPECS[driveMode];
  const activeRoute =
    ROUTE_OPTIONS.find((r) => r.id === selectedRouteId) ?? ROUTE_OPTIONS[0];
  const primaryPlan = activeRoute.plans[0];
  const isRegen = powerKw < 0;
  const maxDraw = modeSpec.maxPowerKw;
  const maxRegen = 120;

  // Power bar percentage relative to center zero
  const drawRatio = powerKw >= 0 ? Math.min(1, powerKw / maxDraw) : 0;
  const regenRatio = powerKw < 0 ? Math.min(1, Math.abs(powerKw) / maxRegen) : 0;

  return (
    <div className="flex flex-col gap-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* LEFT INSTRUMENT CLUSTER (5 columns) */}
      <div className="lg:col-span-5 flex flex-col gap-6">
        <section
          aria-label="Primary Instrument Cluster"
          className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6 md:p-7 flex flex-col justify-between"
        >
          {/* Gear Strip & Active Pilot Flag */}
          <div className="flex items-center justify-between gap-4 pb-5 border-b border-white/[0.06]">
            <div
              role="radiogroup"
              aria-label="Transmission Gear"
              className="inline-flex items-center gap-1 p-1 rounded-full bg-[#0B0E14] border border-white/[0.08]"
            >
              {GEARS.map((g) => {
                const active = gear === g;
                return (
                  <button
                    key={g}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => onChangeGear(g)}
                    className={`w-10 h-10 rounded-full font-mono text-sm font-semibold transition-all duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
                      active
                        ? 'text-[#0B0E14]'
                        : 'text-[#849495] hover:text-[#E1E2EB]'
                    }`}
                    style={
                      active
                        ? {
                            backgroundColor: 'var(--kh-accent)',
                            boxShadow: '0 0 14px rgba(var(--kh-accent-rgb), 0.4)',
                          }
                        : undefined
                    }
                  >
                    {g}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={onToggleCruise}
              className={`inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full border text-xs font-mono tracking-wider uppercase transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
                cruiseEnabled
                  ? 'border-[#00F2FE]/60 bg-[#00F2FE]/10 text-[#E0FDFF]'
                  : 'border-white/[0.12] bg-transparent text-[#849495] hover:text-[#E1E2EB]'
              }`}
            >
              {cruiseEnabled && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#00F2FE] kh-pulse-slow" />
              )}
              <span>{cruiseEnabled ? `Pilot · ${cruiseTargetKmh} km/h` : 'Highway Pilot'}</span>
            </button>
          </div>

          {/* Hero Velocity Readout */}
          <div className="py-7 flex items-end justify-between gap-4">
            <div>
              <div className="kh-label-caps text-[#849495] mb-1">Velocity</div>
              <div className="flex items-baseline gap-3">
                <span className="font-display tabular-nums text-[64px] md:text-[72px] font-bold leading-none tracking-[-0.04em] text-[#E1E2EB]">
                  {Math.round(speedKmh)}
                </span>
                <span className="font-mono text-sm font-medium uppercase tracking-widest text-[#849495]">
                  km/h
                </span>
              </div>
            </div>

            <div className="text-right">
              <div className="kh-label-caps text-[#849495] mb-1">
                {isRegen ? 'Regen Capture' : 'Instant Output'}
              </div>
              <div
                className="font-mono tabular-nums text-2xl font-semibold"
                style={{
                  color: isRegen ? '#10E7A9' : 'var(--kh-accent)',
                }}
              >
                {powerKw > 0 ? `+${Math.round(powerKw)}` : Math.round(powerKw)}{' '}
                <span className="text-xs font-medium text-[#849495]">kW</span>
              </div>
            </div>
          </div>

          {/* Center-Zero Power / Regen Flux Meter */}
          <div className="mb-6">
            <div className="flex justify-between kh-label-caps text-[#849495] mb-2">
              <span className="text-[#10E7A9]">-120 kW Regen</span>
              <span>0</span>
              <span style={{ color: 'var(--kh-accent)' }}>+{maxDraw} kW Peak</span>
            </div>
            <div className="relative h-3 rounded-full bg-[#0B0E14] border border-white/[0.08] overflow-hidden flex">
              {/* Left Half: Regen */}
              <div className="w-1/2 h-full flex justify-end border-r border-white/20">
                <div
                  className="h-full rounded-l-full transition-all duration-150"
                  style={{
                    width: `${regenRatio * 100}%`,
                    backgroundColor: '#10E7A9',
                    boxShadow: regenRatio > 0.05 ? '0 0 12px rgba(16, 231, 169, 0.5)' : 'none',
                  }}
                />
              </div>
              {/* Right Half: Power Draw */}
              <div className="w-1/2 h-full flex justify-start">
                <div
                  className="h-full rounded-r-full transition-all duration-150"
                  style={{
                    width: `${drawRatio * 100}%`,
                    backgroundColor: 'var(--kh-accent)',
                    boxShadow: drawRatio > 0.05 ? '0 0 12px rgba(var(--kh-accent-rgb), 0.5)' : 'none',
                  }}
                />
              </div>
            </div>
          </div>

          {/* ADAS Spatial Horizon Projection SVG */}
          <div className="relative rounded-2xl bg-[#0B0E14] border border-white/[0.08] p-4 overflow-hidden">
            <div className="flex items-center justify-between mb-2">
              <span className="kh-label-caps text-[#849495]">Horizon Sensor Fusion · 120 Hz</span>
              <span className="font-mono tabular-nums text-xs text-[#B9CACB]">
                {gear === 'P' ? 'Parked · Standstill' : 'Lead Clear · 48 m'}
              </span>
            </div>

            <svg
              viewBox="0 0 400 175"
              className="w-full h-40 select-none"
              role="img"
              aria-label="ADAS lane and vehicle projection"
            >
              <defs>
                <linearGradient id="laneGlow" x1="0" y1="1" x2="0" y2="0">
                  <stop offset="0%" stopColor="var(--kh-accent)" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="var(--kh-accent)" stopOpacity="0.05" />
                </linearGradient>
                <linearGradient id="leadFade" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4FACFE" stopOpacity="0.28" />
                  <stop offset="100%" stopColor="#4FACFE" stopOpacity="0" />
                </linearGradient>
              </defs>

              {/* Horizon grid lines */}
              <line x1="20" y1="36" x2="380" y2="36" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
              <line x1="40" y1="70" x2="360" y2="70" stroke="rgba(255,255,255,0.04)" strokeDasharray="4 6" />

              {/* Adjacent lanes */}
              <line x1="150" y1="36" x2="45" y2="170" stroke="rgba(255,255,255,0.12)" strokeWidth="1.5" />
              <line x1="250" y1="36" x2="355" y2="170" stroke="rgba(255,255,255,0.12)" strokeWidth="1.5" />

              {/* Active ego corridor */}
              <polygon
                points="178,36 222,36 292,170 108,170"
                fill="url(#leadFade)"
                opacity={cruiseEnabled ? 0.85 : 0.35}
              />
              <line
                x1="178"
                y1="36"
                x2="108"
                y2="170"
                stroke="url(#laneGlow)"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <line
                x1="222"
                y1="36"
                x2="292"
                y2="170"
                stroke="url(#laneGlow)"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Lead vehicle silhouette far ahead */}
              <g transform="translate(186, 48)">
                <rect
                  x="0"
                  y="0"
                  width="28"
                  height="11"
                  rx="3"
                  fill="#191C22"
                  stroke="#4FACFE"
                  strokeWidth="1.2"
                />
                <line x1="4" y1="9" x2="9" y2="9" stroke="#FFB4AB" strokeWidth="1.5" />
                <line x1="19" y1="9" x2="24" y2="9" stroke="#FFB4AB" strokeWidth="1.5" />
              </g>

              {/* Ego GT Coupe Wireframe */}
              <g transform="translate(162, 118)">
                <path
                  d="M12,38 L6,18 C7,8 16,2 38,2 C60,2 69,8 70,18 L64,38 Z"
                  fill="#131722"
                  stroke="var(--kh-accent)"
                  strokeWidth="1.6"
                />
                <path
                  d="M16,16 C22,9 54,9 60,16 L56,28 L20,28 Z"
                  fill="#0B0E14"
                  stroke="rgba(255,255,255,0.22)"
                  strokeWidth="1"
                />
                {/* Headlight beam arc */}
                <line x1="14" y1="3" x2="24" y2="3" stroke="#E0FDFF" strokeWidth="2" strokeLinecap="round" />
                <line x1="52" y1="3" x2="62" y2="3" stroke="#E0FDFF" strokeWidth="2" strokeLinecap="round" />
              </g>
            </svg>

            {/* Interactive Drive Simulation Controls */}
            <div className="mt-3 pt-3 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onThrottlePulse}
                  className="min-h-[40px] px-4 rounded-full text-xs font-semibold text-[#0B0E14] transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE]"
                  style={{
                    backgroundColor: 'var(--kh-accent)',
                    boxShadow: '0 0 14px rgba(var(--kh-accent-rgb), 0.3)',
                  }}
                >
                  Accelerate +
                </button>
                <button
                  type="button"
                  onClick={onRegenBrakePulse}
                  className="min-h-[40px] px-4 rounded-full text-xs font-semibold bg-[#10E7A9]/15 border border-[#10E7A9]/45 text-[#10E7A9] hover:bg-[#10E7A9]/25 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#10E7A9]"
                >
                  Regen Brake
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  aria-label="Decrease cruise target speed"
                  onClick={() => onAdjustCruise(-5)}
                  className="w-10 h-10 rounded-full bg-[#191C22] border border-white/[0.12] text-[#E1E2EB] hover:border-white/40 flex items-center justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE]"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  aria-label="Increase cruise target speed"
                  onClick={() => onAdjustCruise(5)}
                  className="w-10 h-10 rounded-full bg-[#191C22] border border-white/[0.12] text-[#E1E2EB] hover:border-white/40 flex items-center justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE]"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Active Drive Mode Physics Summary */}
          <div className="mt-5 grid grid-cols-3 gap-3 pt-4 border-t border-white/[0.06]">
            <div>
              <div className="kh-label-caps text-[#849495]">Torque Split</div>
              <div className="font-mono tabular-nums text-xs font-medium text-[#E1E2EB] mt-1">
                {modeSpec.torqueSplit}
              </div>
            </div>
            <div>
              <div className="kh-label-caps text-[#849495]">Suspension</div>
              <div className="font-mono text-xs font-medium text-[#E1E2EB] mt-1 truncate">
                {modeSpec.suspension}
              </div>
            </div>
            <div>
              <div className="kh-label-caps text-[#849495]">Pedal Map</div>
              <div className="font-mono text-xs font-medium text-[#E1E2EB] mt-1 truncate">
                {modeSpec.throttleResponse}
              </div>
            </div>
          </div>
        </section>

        {/* Next Turn Navigation Mini-HUD */}
        <section
          aria-label="Active Route Guidance"
          className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-5 flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-12 h-12 rounded-2xl bg-[#191C22] border border-white/[0.1] flex items-center justify-center shrink-0 text-[#4FACFE]">
              <Navigation className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="kh-label-caps text-[#4FACFE]">
                {activeRoute.nextManeuverDistM} m · {primaryPlan.highway}
              </div>
              <div className="text-sm font-medium text-[#E1E2EB] truncate mt-0.5">
                {activeRoute.name}
              </div>
              <div className="text-xs text-[#849495] font-mono tabular-nums mt-0.5">
                {primaryPlan.distanceKm} km · {Math.floor(primaryPlan.driveDurationMin / 60)}h{' '}
                {primaryPlan.driveDurationMin % 60}m · {activeRoute.terminals.length} rest terminals
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenNavigation}
            className="min-h-[44px] px-4 rounded-full border border-white/[0.16] text-xs font-medium text-[#E1E2EB] hover:border-white/70 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Route Map
          </button>
        </section>
      </div>

      {/* RIGHT CONSOLE STACK (7 columns) */}
      <div className="lg:col-span-7 flex flex-col gap-6">
        <BatteryFluxBar
          batteryPct={batteryPct}
          rangeKm={rangeKm}
          isCharging={isCharging}
          chargingRateKw={chargingRateKw}
          batteryTempC={batteryTempC}
          onSimulateCharging={onSimulateCharging}
          onSimulateLowBattery={onSimulateLowBattery}
          onResetNominal={onResetNominal}
        />

        {/* Dual-Zone Climate & Cabin Purifier */}
        <section
          aria-label="Cabin Climate Control"
          className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6"
        >
          <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
            <div>
              <span className="kh-label-caps text-[#849495]">Dual-Zone Cabin Climate</span>
              <h2 className="font-display text-xl font-medium text-[#E1E2EB] mt-1">
                Thermal & Air Quality
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <Wind className="w-4 h-4 text-[#849495]" />
              <span className="kh-label-caps text-[#849495]">Fan</span>
              <div className="inline-flex items-center gap-1 p-1 rounded-full bg-[#0B0E14] border border-white/[0.08]">
                {[1, 2, 3, 4, 5].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => onUpdateClimate({ fanLevel: lvl })}
                    className={`w-8 h-8 rounded-full font-mono tabular-nums text-xs font-semibold transition-colors cursor-pointer ${
                      climate.fanLevel === lvl
                        ? 'text-[#0B0E14]'
                        : 'text-[#849495] hover:text-[#E1E2EB]'
                    }`}
                    style={
                      climate.fanLevel === lvl
                        ? { backgroundColor: 'var(--kh-accent)' }
                        : undefined
                    }
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <KineticSlider
              label="Driver Zone"
              valueDisplay={`${climate.driverTempC.toFixed(1)} °C`}
              value={climate.driverTempC}
              min={16}
              max={28}
              step={0.5}
              onChange={(val) => onUpdateClimate({ driverTempC: val })}
            />
            <KineticSlider
              label="Passenger Zone"
              valueDisplay={`${climate.passengerTempC.toFixed(1)} °C`}
              value={climate.passengerTempC}
              min={16}
              max={28}
              step={0.5}
              onChange={(val) => onUpdateClimate({ passengerTempC: val })}
            />
          </div>

          {/* Seat Thermal & Haptic Toggles */}
          <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between gap-4 px-4 py-3 rounded-2xl bg-[#161B26]/80 border border-white/[0.08]">
              <div>
                <div className="text-[14px] font-medium text-[#E1E2EB]">Driver Seat Heat</div>
                <div className="text-xs text-[#849495]">
                  {climate.seatHeatDriver === 0 ? 'Off' : `Level ${climate.seatHeatDriver}`}
                </div>
              </div>
              <div className="flex items-center gap-1">
                {[0, 1, 2, 3].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => onUpdateClimate({ seatHeatDriver: lvl })}
                    className={`w-9 h-9 rounded-full font-mono text-xs font-semibold transition-colors cursor-pointer ${
                      climate.seatHeatDriver === lvl
                        ? 'bg-[#FF7849] text-[#0B0E14]'
                        : 'bg-[#0B0E14] text-[#849495] hover:text-[#E1E2EB]'
                    }`}
                  >
                    {lvl === 0 ? 'Off' : lvl}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between gap-4 px-4 py-3 rounded-2xl bg-[#161B26]/80 border border-white/[0.08]">
              <div>
                <div className="text-[14px] font-medium text-[#E1E2EB]">Passenger Seat Heat</div>
                <div className="text-xs text-[#849495]">
                  {climate.seatHeatPassenger === 0 ? 'Off' : `Level ${climate.seatHeatPassenger}`}
                </div>
              </div>
              <div className="flex items-center gap-1">
                {[0, 1, 2, 3].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => onUpdateClimate({ seatHeatPassenger: lvl })}
                    className={`w-9 h-9 rounded-full font-mono text-xs font-semibold transition-colors cursor-pointer ${
                      climate.seatHeatPassenger === lvl
                        ? 'bg-[#FF7849] text-[#0B0E14]'
                        : 'bg-[#0B0E14] text-[#849495] hover:text-[#E1E2EB]'
                    }`}
                  >
                    {lvl === 0 ? 'Off' : lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
            <HapticToggle
              label="HEPA Purify"
              description="PM2.5 · 4 µg/m³"
              checked={climate.hepaFilter}
              onChange={(v) => onUpdateClimate({ hepaFilter: v })}
              accent="green"
            />
            <HapticToggle
              label="Auto Defrost"
              description="Optical sensor"
              checked={climate.autoDefrost}
              onChange={(v) => onUpdateClimate({ autoDefrost: v })}
              accent="cyan"
            />
            <HapticToggle
              label="Pre-Condition"
              description="Cabin + Pack"
              checked={climate.preConditionCabin}
              onChange={(v) => onUpdateClimate({ preConditionCabin: v })}
            />
          </div>
        </section>

        {/* Chassis & 4-Wheel Tire Telemetry */}
        <section
          aria-label="Chassis and Tire Telemetry"
          className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <Gauge className="w-4 h-4 text-[#849495]" />
              <span className="kh-label-caps text-[#849495]">4-Corner Tire & Chassis Telemetry</span>
            </div>
            <span className="font-mono text-xs text-[#10E7A9]">All Pressures Nominal</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {tires.map((tire) => (
              <div
                key={tire.id}
                className="rounded-2xl bg-[#0B0E14] border border-white/[0.07] p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="kh-label-caps text-[#849495]">{tire.id}</span>
                  <span className="font-mono tabular-nums text-xs text-[#849495]">
                    {tire.tempC}°C
                  </span>
                </div>
                <div className="font-mono tabular-nums text-xl font-semibold text-[#E1E2EB]">
                  {tire.bar.toFixed(1)} <span className="text-xs text-[#849495]">bar</span>
                </div>
                <div className="font-mono tabular-nums text-xs text-[#B9CACB] mt-0.5">
                  {tire.psi} PSI
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
      </div>

      {/* MULTI-FEATURE SYSTEM DESCRIPTIONS */}
      <section aria-label="Platform Capabilities Overview" className="pt-4 border-t border-white/[0.06]">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
          <div>
            <span className="kh-label-caps text-[#849495]">Multi-Feature Platform Guide</span>
            <h2 className="font-display text-2xl font-semibold text-[#E1E2EB] mt-1">
              Integrated Cockpit, 4D Spatial & Energy Subsystems
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigateScreen('spatial')}
            className="inline-flex items-center gap-2 min-h-[42px] px-5 rounded-full bg-[#00F2FE] text-[#0B0E14] text-xs font-semibold hover:opacity-90 transition-opacity whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>Launch 3D / 4D Spatial Twin</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              title: `${vehicle.bodyType.toUpperCase()} 4D Model & Air Check`,
              summary: `${vehicle.name} interactive 4D twin with ambient AQI check, cabin HEPA PM2.5 (${airReport.status === 'complete' ? `${airReport.cabinPm25} µg/m³` : 'ready'}), 4D airflow streams, and ${bluetooth.status === 'connected' ? 'active Bluetooth sync.' : 'Bluetooth pairing.'}`,
              screen: 'spatial' as ScreenId,
              cta: 'Open 4D & Air Lab',
            },
            {
              title: 'Google Maps Route & Traffic Check',
              summary:
                'Live Google Maps corridors from Lahore across Pakistan, showing all route descriptions, road busyness checks, rest terminals, and drive helpfulness guidance.',
              screen: 'navigation' as ScreenId,
              cta: 'Open Google Maps',
            },
            {
              title: '800V Energy & Charging',
              summary:
                'Interactive 320 kW charging envelope curve, daily vs. trip target charge limits, three-stage regenerative braking tuning, and a filterable trip efficiency ledger.',
              screen: 'energy' as ScreenId,
              cta: 'Open Energy Lab',
            },
            {
              title: 'Vehicle Studio & Mobile Sync',
              summary:
                'Air suspension ride height, active rear wing angle, cabin ambient photon strip, hardware bus diagnostics, and a 4-column Bluetooth companion.',
              screen: 'companion' as ScreenId,
              cta: 'Open Companion',
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-5 flex flex-col justify-between gap-4"
            >
              <div>
                <h3 className="font-display text-base font-semibold text-[#E1E2EB]">
                  {item.title}
                </h3>
                <p className="mt-2 text-[13px] leading-relaxed text-[#B9CACB]">
                  {item.summary}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateScreen(item.screen)}
                className="self-start inline-flex items-center gap-1.5 min-h-[36px] px-3.5 rounded-full bg-[#191C22] border border-white/[0.12] text-xs font-medium text-[#E1E2EB] hover:border-[#00F2FE]/60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>{item.cta}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
