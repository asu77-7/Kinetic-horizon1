import React, { useState } from 'react';
import { CHARGING_CURVE_POINTS, TRIP_HISTORY } from '../data/vehicleData';
import { RegenLevel } from '../types/vehicle';
import { HapticToggle } from './HapticToggle';
import { KineticSlider } from './KineticSlider';

interface EnergyScreenProps {
  batteryPct: number;
  chargeLimitPct: number;
  onChangeChargeLimit: (val: number) => void;
  regenLevel: RegenLevel;
  onChangeRegenLevel: (lvl: RegenLevel) => void;
  preconditioning: boolean;
  onTogglePreconditioning: (val: boolean) => void;
  scheduledDeparture: boolean;
  onToggleScheduledDeparture: (val: boolean) => void;
}

const REGEN_LEVELS: { id: RegenLevel; label: string; desc: string }[] = [
  { id: 'low', label: 'Low', desc: 'Coast priority' },
  { id: 'standard', label: 'Standard', desc: 'Balanced 65 kW' },
  { id: 'one-pedal', label: 'One-Pedal', desc: 'Max 120 kW hold' },
];

export const EnergyScreen: React.FC<EnergyScreenProps> = ({
  batteryPct,
  chargeLimitPct,
  onChangeChargeLimit,
  regenLevel,
  onChangeRegenLevel,
  preconditioning,
  onTogglePreconditioning,
  scheduledDeparture,
  onToggleScheduledDeparture,
}) => {
  const [hoverIdx, setHoverIdx] = useState<number>(3);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'highway' | 'alpine' | 'urban'>('all');
  const [tripQuery, setTripQuery] = useState('');

  const activePoint = CHARGING_CURVE_POINTS[hoverIdx] ?? CHARGING_CURVE_POINTS[3];

  // SVG coordinates for charging curve
  const width = 620;
  const height = 220;
  const padX = 42;
  const padY = 24;
  const plotW = width - padX * 2;
  const plotH = height - padY * 2;

  const coords = CHARGING_CURVE_POINTS.map((pt) => {
    const x = padX + (pt.soc / 100) * plotW;
    const y = padY + plotH - (pt.kw / 350) * plotH;
    return { ...pt, x, y };
  });

  const curveLine = coords.map((c) => `${c.x},${c.y}`).join(' ');
  const areaPath = `M ${coords[0].x},${padY + plotH} L ${coords
    .map((c) => `${c.x},${c.y}`)
    .join(' L ')} L ${coords[coords.length - 1].x},${padY + plotH} Z`;

  const filteredTrips = TRIP_HISTORY.filter((t) => {
    const matchesCat = categoryFilter === 'all' || t.category === categoryFilter;
    const matchesQuery = t.route.toLowerCase().includes(tripQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* LEFT: CHARGING ARCHITECTURE & LIMITS (7 columns) */}
      <div className="lg:col-span-7 flex flex-col gap-6">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
            <div>
              <span className="kh-label-caps text-[#849495]">800V DC Charging Curve</span>
              <h2 className="font-display text-2xl font-semibold text-[#E1E2EB] mt-1">
                Peak Thermal Envelope · 320 kW
              </h2>
            </div>

            <div className="flex items-center gap-5 text-right">
              <div>
                <div className="kh-label-caps text-[#849495]">Probe SoC</div>
                <div className="font-mono tabular-nums text-lg font-semibold text-[#E1E2EB]">
                  {activePoint.soc}%
                </div>
              </div>
              <div>
                <div className="kh-label-caps text-[#849495]">Rate</div>
                <div className="font-mono tabular-nums text-lg font-semibold text-[#00F2FE]">
                  {activePoint.kw} kW
                </div>
              </div>
              <div>
                <div className="kh-label-caps text-[#849495]">Elapsed</div>
                <div className="font-mono tabular-nums text-lg font-semibold text-[#10E7A9]">
                  {activePoint.min} min
                </div>
              </div>
            </div>
          </div>

          {/* Interactive SVG Charge Curve */}
          <div className="rounded-2xl bg-[#0B0E14] border border-white/[0.08] p-4">
            <svg
              viewBox={`0 0 ${width} ${height}`}
              className="w-full h-56 select-none"
              role="img"
              aria-label="800V DC fast charging power curve"
            >
              <defs>
                <linearGradient id="chargeFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00F2FE" stopOpacity="0.28" />
                  <stop offset="100%" stopColor="#00F2FE" stopOpacity="0.01" />
                </linearGradient>
              </defs>

              {/* Horizontal Gridlines */}
              {[100, 200, 300].map((kw) => {
                const y = padY + plotH - (kw / 350) * plotH;
                return (
                  <g key={kw}>
                    <line
                      x1={padX}
                      y1={y}
                      x2={width - padX}
                      y2={y}
                      stroke="rgba(255,255,255,0.06)"
                      strokeDasharray="4 5"
                    />
                    <text
                      x={6}
                      y={y + 4}
                      fill="#849495"
                      fontSize="10"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      {kw}
                    </text>
                  </g>
                );
              })}

              {/* Area and Line */}
              <path d={areaPath} fill="url(#chargeFill)" />
              <polyline
                points={curveLine}
                fill="none"
                stroke="#00F2FE"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Current Vehicle SoC Marker */}
              <line
                x1={padX + (batteryPct / 100) * plotW}
                y1={padY}
                x2={padX + (batteryPct / 100) * plotW}
                y2={padY + plotH}
                stroke="#10E7A9"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />

              {/* Interactive Probe Points */}
              {coords.map((c, idx) => {
                const isActive = idx === hoverIdx;
                return (
                  <g
                    key={c.soc}
                    onMouseEnter={() => setHoverIdx(idx)}
                    onClick={() => setHoverIdx(idx)}
                    className="cursor-pointer"
                  >
                    <circle cx={c.x} cy={c.y} r="14" fill="transparent" />
                    <circle
                      cx={c.x}
                      cy={c.y}
                      r={isActive ? 5.5 : 3}
                      fill={isActive ? '#E0FDFF' : '#0B0E14'}
                      stroke="#00F2FE"
                      strokeWidth="2"
                    />
                    <text
                      x={c.x}
                      y={height - 4}
                      textAnchor="middle"
                      fill={isActive ? '#E1E2EB' : '#849495'}
                      fontSize="10"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      {c.soc}%
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Charge Limit Slider & Presets */}
          <div className="mt-5 pt-5 border-t border-white/[0.06]">
            <KineticSlider
              label="Target Charge Limit"
              valueDisplay={`${chargeLimitPct}% · ${Math.round(chargeLimitPct * 5.46)} km`}
              value={chargeLimitPct}
              min={50}
              max={100}
              step={5}
              onChange={onChangeChargeLimit}
              accentColor="#10E7A9"
            />
            <div className="mt-2 flex items-center justify-between gap-3">
              <span className="text-xs text-[#849495]">
                80% Daily preserves cathode longevity · 100% for Alpine corridors
              </span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onChangeChargeLimit(80)}
                  className={`min-h-[36px] px-3.5 rounded-full text-xs font-medium cursor-pointer ${
                    chargeLimitPct === 80
                      ? 'bg-[#10E7A9] text-[#0B0E14] font-semibold'
                      : 'bg-[#191C22] border border-white/[0.12] text-[#E1E2EB]'
                  }`}
                >
                  Daily 80%
                </button>
                <button
                  type="button"
                  onClick={() => onChangeChargeLimit(100)}
                  className={`min-h-[36px] px-3.5 rounded-full text-xs font-medium cursor-pointer ${
                    chargeLimitPct === 100
                      ? 'bg-[#00F2FE] text-[#0B0E14] font-semibold'
                      : 'bg-[#191C22] border border-white/[0.12] text-[#E1E2EB]'
                  }`}
                >
                  Trip 100%
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Trip Efficiency Ledger */}
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div>
              <span className="kh-label-caps text-[#849495]">Efficiency Ledger</span>
              <h3 className="font-display text-xl font-medium text-[#E1E2EB] mt-0.5">
                Recent Trip Consumption
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {(['all', 'highway', 'alpine', 'urban'] as const).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter(cat)}
                  className={`min-h-[34px] px-3.5 rounded-full text-xs font-medium capitalize transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    categoryFilter === cat
                      ? 'bg-[#E1E2EB] text-[#0B0E14] font-semibold'
                      : 'bg-[#0B0E14] border border-white/[0.1] text-[#849495] hover:text-[#E1E2EB]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <input
            type="text"
            value={tripQuery}
            onChange={(e) => setTripQuery(e.target.value)}
            placeholder="Filter trip corridor..."
            aria-label="Filter trip corridor"
            className="w-full min-h-[44px] px-4 mb-4 rounded-xl bg-[#0B0E14] border border-white/[0.1] text-sm text-[#E1E2EB] placeholder-[#849495] focus:outline-none focus:border-[#00F2FE]"
          />

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/[0.08] kh-label-caps text-[#849495]">
                  <th className="py-2.5 pr-4">Route</th>
                  <th className="py-2.5 px-3 text-right">Distance</th>
                  <th className="py-2.5 px-3 text-right">Avg Speed</th>
                  <th className="py-2.5 px-3 text-right">Draw</th>
                  <th className="py-2.5 pl-3 text-right">Regen</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.05] text-sm">
                {filteredTrips.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-xs text-[#849495]">
                      No trips match the active filter.
                    </td>
                  </tr>
                ) : (
                  filteredTrips.map((t) => (
                    <tr key={t.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 pr-4">
                        <div className="font-medium text-[#E1E2EB]">{t.route}</div>
                        <div className="text-xs text-[#849495]">{t.date}</div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-[#B9CACB]">
                        {t.distanceKm.toFixed(1)} km
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-[#B9CACB]">
                        {t.avgSpeedKmh} km/h
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-[#E1E2EB]">
                        {t.consumptionKwh100.toFixed(1)} kWh/100
                      </td>
                      <td className="py-3 pl-3 text-right font-mono tabular-nums text-[#10E7A9]">
                        +{t.regenKwh.toFixed(1)} kWh
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>

      {/* RIGHT: REGEN TUNING & CONSUMPTION MIX (5 columns) */}
      <div className="lg:col-span-5 flex flex-col gap-6">
        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <span className="kh-label-caps text-[#849495]">Kinetic Recovery</span>
          <h3 className="font-display text-xl font-medium text-[#E1E2EB] mt-1 mb-4">
            Regenerative Braking Strength
          </h3>

          <div className="flex flex-col gap-2.5">
            {REGEN_LEVELS.map((lvl) => {
              const active = regenLevel === lvl.id;
              return (
                <button
                  key={lvl.id}
                  type="button"
                  onClick={() => onChangeRegenLevel(lvl.id)}
                  className={`min-h-[54px] px-4 py-3 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                    active
                      ? 'bg-[#191C22] border-[#10E7A9]/60'
                      : 'bg-[#0B0E14] border-white/[0.08] hover:border-white/[0.18]'
                  }`}
                  style={
                    active
                      ? { boxShadow: '0 0 18px rgba(16, 231, 169, 0.14)' }
                      : undefined
                  }
                >
                  <span className="text-sm font-semibold text-[#E1E2EB]">{lvl.label}</span>
                  <span
                    className={`font-mono text-xs ${
                      active ? 'text-[#10E7A9]' : 'text-[#849495]'
                    }`}
                  >
                    {lvl.desc}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-5 flex flex-col gap-3">
            <HapticToggle
              label="Thermal Pre-Conditioning"
              description="Warm pack to 28°C before HPC arrival"
              checked={preconditioning}
              onChange={onTogglePreconditioning}
              accent="cyan"
            />
            <HapticToggle
              label="Scheduled Departure · 07:30"
              description="Off-peak grid tariff optimization"
              checked={scheduledDeparture}
              onChange={onToggleScheduledDeparture}
              accent="green"
            />
          </div>
        </section>

        <section className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6">
          <span className="kh-label-caps text-[#849495]">Energy Allocation · Last 100 km</span>
          <h3 className="font-display text-xl font-medium text-[#E1E2EB] mt-1 mb-5">
            Subsystem Draw Breakdown
          </h3>

          <div className="flex flex-col gap-4">
            {[
              { label: 'Dual-Motor Propulsion', pct: 78, kwh: '13.8 kWh', color: '#00F2FE' },
              { label: 'Cabin Climate & HEPA', pct: 11, kwh: '1.9 kWh', color: '#4FACFE' },
              { label: 'Battery Thermal Loop', pct: 7, kwh: '1.2 kWh', color: '#10E7A9' },
              { label: 'ADAS Sensors & Cockpit', pct: 4, kwh: '0.7 kWh', color: '#849495' },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-[#E1E2EB] font-medium">{item.label}</span>
                  <span className="font-mono tabular-nums text-[#B9CACB]">
                    {item.kwh} · {item.pct}%
                  </span>
                </div>
                <div className="h-2.5 rounded-full bg-[#0B0E14] border border-white/[0.06] overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${item.pct}%`, backgroundColor: item.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
