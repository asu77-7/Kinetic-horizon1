import React, { useState } from 'react';
import { Car, ArrowRight, Check, Sparkles } from 'lucide-react';
import { VEHICLE_PRESETS } from '../data/vehicleData';
import { PowertrainType, VehicleBodyType, VehicleProfile } from '../types/vehicle';

interface CarSelectorOnboardingProps {
  currentVehicle: VehicleProfile;
  onConfirmVehicle: (vehicle: VehicleProfile) => void;
}

const BODY_TYPES: { id: VehicleBodyType; label: string; desc: string }[] = [
  { id: 'sedan', label: 'Sedan', desc: '4-door aerodynamic saloon' },
  { id: 'suv', label: 'SUV / Crossover', desc: 'Raised clearance & cargo roof' },
  { id: 'coupe', label: 'GT Coupe', desc: 'Low fastback & active wing' },
  { id: 'hatchback', label: 'Hatchback', desc: 'Compact urban footprint' },
];

const POWERTRAINS: PowertrainType[] = ['EV', 'Hybrid', 'Petrol'];

const PAINT_SWATCHES = [
  { label: 'Obsidian Slate', hex: '#1B212E' },
  { label: 'Midnight Navy', hex: '#162942' },
  { label: 'Emerald Graphite', hex: '#16302B' },
  { label: 'Titanium Silver', hex: '#4B5563' },
  { label: 'Crimson Track', hex: '#581C24' },
];

export const CarSelectorOnboarding: React.FC<CarSelectorOnboardingProps> = ({
  currentVehicle,
  onConfirmVehicle,
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>(currentVehicle.id);
  const [customName, setCustomName] = useState<string>(currentVehicle.name);
  const [bodyType, setBodyType] = useState<VehicleBodyType>(currentVehicle.bodyType);
  const [powertrain, setPowertrain] = useState<PowertrainType>(currentVehicle.powertrain);
  const [colorHex, setColorHex] = useState<string>(currentVehicle.colorHex);
  const [rangeKmFull, setRangeKmFull] = useState<number>(currentVehicle.rangeKmFull);

  const handleSelectPreset = (preset: VehicleProfile) => {
    setSelectedPresetId(preset.id);
    setCustomName(preset.name);
    setBodyType(preset.bodyType);
    setPowertrain(preset.powertrain);
    setColorHex(preset.colorHex);
    setRangeKmFull(preset.rangeKmFull);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = customName.trim() || 'My Connected Car';
    const basePreset =
      VEHICLE_PRESETS.find((p) => p.bodyType === bodyType) ?? VEHICLE_PRESETS[0];

    onConfirmVehicle({
      ...basePreset,
      id: selectedPresetId === 'custom' ? `custom-${Date.now()}` : selectedPresetId,
      name: trimmedName,
      brand: powertrain === 'EV' ? 'Electric Vehicle' : `${powertrain} Vehicle`,
      bodyType,
      powertrain,
      colorHex,
      rangeKmFull,
      batteryOrTankLabel:
        powertrain === 'EV'
          ? 'High-Voltage EV Pack'
          : powertrain === 'Hybrid'
            ? 'Hybrid Pack + Fuel Tank'
            : 'Fuel Tank + 12V OBD-II',
    });
  };

  return (
    <div className="max-w-5xl mx-auto py-4 md:py-8">
      <div className="rounded-[1.5rem] bg-[#131722] border border-white/[0.08] p-6 md:p-9">
        <div className="flex flex-wrap items-start justify-between gap-4 pb-6 border-b border-white/[0.08]">
          <div>
            <span className="kh-label-caps text-[#00F2FE]">
              Step 1 of 3 · Vehicle Identity & 4D Digital Twin
            </span>
            <h1 className="font-display text-3xl md:text-4xl font-bold text-[#E1E2EB] mt-2 text-balance">
              Which car are you driving today?
            </h1>
            <p className="mt-2 text-sm md:text-[15px] text-[#B9CACB] max-w-2xl leading-relaxed">
              Select a vehicle profile or enter your own car model below. We will generate its interactive 4D model, run cabin air quality and airflow diagnostics, connect via Bluetooth, and evaluate live Google Maps routes and road traffic for your drive.
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-[#00F2FE]/10 border border-[#00F2FE]/35 flex items-center justify-center text-[#00F2FE] shrink-0">
            <Car className="w-6 h-6" />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-7">
          {/* Quick Presets */}
          <div>
            <div className="kh-label-caps text-[#849495] mb-3">
              Choose a Vehicle Class or Customize Below
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {VEHICLE_PRESETS.map((preset) => {
                const active = selectedPresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`text-left p-4 rounded-2xl border transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
                      active
                        ? 'bg-[#191C22] border-[#00F2FE]/70'
                        : 'bg-[#0B0E14] border-white/[0.08] hover:border-white/[0.22]'
                    }`}
                    style={
                      active
                        ? { boxShadow: '0 0 20px rgba(0, 242, 254, 0.14)' }
                        : undefined
                    }
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="kh-label-caps text-[#4FACFE]">
                        {preset.bodyType}
                      </span>
                      {active && <Check className="w-4 h-4 text-[#00F2FE]" />}
                    </div>
                    <div className="font-display text-base font-semibold text-[#E1E2EB] mt-1.5">
                      {preset.name}
                    </div>
                    <div className="mt-2 font-mono tabular-nums text-xs text-[#849495]">
                      {preset.powertrain} · {preset.rangeKmFull} km range · Cd {preset.dragCd}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Model & Body Config */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 pt-4 border-t border-white/[0.06]">
            <div className="md:col-span-6">
              <label
                htmlFor="car-model-input"
                className="block kh-label-caps text-[#849495] mb-2"
              >
                Your Car Make & Model
              </label>
              <input
                id="car-model-input"
                type="text"
                value={customName}
                onChange={(e) => {
                  setSelectedPresetId('custom');
                  setCustomName(e.target.value);
                }}
                placeholder="e.g., Honda Civic RS, Toyota Corolla, BYD Atto 3..."
                className="w-full min-h-[48px] px-4 rounded-xl bg-[#0B0E14] border border-white/[0.14] text-sm text-[#E1E2EB] placeholder-[#849495] focus:outline-none focus:border-[#00F2FE]"
              />
            </div>

            <div className="md:col-span-3">
              <span className="block kh-label-caps text-[#849495] mb-2">
                Powertrain
              </span>
              <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-[#0B0E14] border border-white/[0.12]">
                {POWERTRAINS.map((pt) => (
                  <button
                    key={pt}
                    type="button"
                    onClick={() => setPowertrain(pt)}
                    className={`min-h-[40px] rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      powertrain === pt
                        ? 'bg-[#00F2FE] text-[#0B0E14] font-semibold'
                        : 'text-[#849495] hover:text-[#E1E2EB]'
                    }`}
                  >
                    {pt}
                  </button>
                ))}
              </div>
            </div>

            <div className="md:col-span-3">
              <label
                htmlFor="car-range-input"
                className="block kh-label-caps text-[#849495] mb-2"
              >
                Full Range (km)
              </label>
              <input
                id="car-range-input"
                type="number"
                min={150}
                max={1200}
                value={rangeKmFull}
                onChange={(e) =>
                  setRangeKmFull(Math.max(150, Math.min(1200, Number(e.target.value) || 450)))
                }
                className="w-full min-h-[48px] px-4 rounded-xl bg-[#0B0E14] border border-white/[0.14] font-mono tabular-nums text-sm text-[#E1E2EB] focus:outline-none focus:border-[#00F2FE]"
              />
            </div>
          </div>

          {/* 4D Body Silhouette & Paint Finish */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            <div className="md:col-span-7">
              <span className="block kh-label-caps text-[#849495] mb-2">
                4D Chassis Geometry
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {BODY_TYPES.map((bt) => {
                  const active = bodyType === bt.id;
                  return (
                    <button
                      key={bt.id}
                      type="button"
                      onClick={() => setBodyType(bt.id)}
                      className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#191C22] border-[#10E7A9]/70 text-[#E1E2EB]'
                          : 'bg-[#0B0E14] border-white/[0.08] text-[#849495] hover:text-[#E1E2EB]'
                      }`}
                    >
                      <div className="font-display text-xs font-semibold">{bt.label}</div>
                      <div className="text-[11px] text-[#849495] mt-0.5">{bt.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="md:col-span-5">
              <span className="block kh-label-caps text-[#849495] mb-2">
                4D Exterior Finish
              </span>
              <div className="flex flex-wrap items-center gap-3 p-3 rounded-xl bg-[#0B0E14] border border-white/[0.08]">
                {PAINT_SWATCHES.map((swatch) => {
                  const active = colorHex.toLowerCase() === swatch.hex.toLowerCase();
                  return (
                    <button
                      key={swatch.hex}
                      type="button"
                      title={swatch.label}
                      aria-label={swatch.label}
                      onClick={() => setColorHex(swatch.hex)}
                      className={`w-9 h-9 rounded-full border-2 transition-transform cursor-pointer ${
                        active
                          ? 'border-[#00F2FE] scale-110'
                          : 'border-white/25 hover:border-white/60'
                      }`}
                      style={{ backgroundColor: swatch.hex }}
                    />
                  );
                })}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-[#849495]">
              <Sparkles className="w-4 h-4 text-[#10E7A9]" />
              <span>
                Next: Inspect your car&apos;s 4D model, scan air quality & airflow, and pair via Bluetooth.
              </span>
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2.5 min-h-[48px] px-7 rounded-full bg-[#00F2FE] text-[#0B0E14] text-sm font-semibold hover:opacity-90 transition-opacity cursor-pointer"
              style={{ boxShadow: '0 0 22px rgba(0, 242, 254, 0.3)' }}
            >
              <span>Generate 4D Model & Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
