import React from 'react';

interface KineticSliderProps {
  label: string;
  valueDisplay: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (next: number) => void;
  accentColor?: string;
}

export const KineticSlider: React.FC<KineticSliderProps> = ({
  label,
  valueDisplay,
  value,
  min,
  max,
  step = 0.5,
  onChange,
  accentColor = 'var(--kh-accent)',
}) => {
  const pct = Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));

  return (
    <div className="w-full py-1.5">
      <div className="flex items-baseline justify-between mb-2">
        <span className="kh-label-caps text-[#849495]">{label}</span>
        <span className="font-mono tabular-nums text-[15px] font-semibold text-[#E1E2EB]">
          {valueDisplay}
        </span>
      </div>

      <div className="relative min-h-[48px] flex items-center">
        {/* Pill-capped track */}
        <div className="relative w-full h-3 rounded-full bg-[#161B26] border border-white/[0.08] overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-100"
            style={{
              width: `${pct}%`,
              background: `linear-gradient(90deg, rgba(var(--kh-accent-rgb), 0.35) 0%, ${accentColor} 100%)`,
            }}
          />
        </div>

        {/* Extruded pill thumb with center notch */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-6 rounded-full bg-[#E1E2EB] border border-white/40 flex items-center justify-center shadow-md transition-all duration-75"
          style={{
            left: `calc(${pct}% * 0.92 + 4%)`,
            boxShadow: `0 0 12px rgba(var(--kh-accent-rgb), 0.35)`,
          }}
        >
          <span className="w-[2px] h-3 rounded-full bg-[#0B0E14]" />
        </div>

        <input
          type="range"
          aria-label={label}
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </div>
    </div>
  );
};
