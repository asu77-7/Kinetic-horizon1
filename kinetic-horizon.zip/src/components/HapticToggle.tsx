import React from 'react';

interface HapticToggleProps {
  label: string;
  description?: string;
  checked: boolean;
  onChange: (next: boolean) => void;
  accent?: 'accent' | 'green' | 'cyan';
}

export const HapticToggle: React.FC<HapticToggleProps> = ({
  label,
  description,
  checked,
  onChange,
  accent = 'accent',
}) => {
  const activeColor =
    accent === 'green'
      ? '#10E7A9'
      : accent === 'cyan'
        ? '#00F2FE'
        : 'var(--kh-accent)';

  const activeShadow =
    accent === 'green'
      ? '0 0 14px rgba(16, 231, 169, 0.55)'
      : accent === 'cyan'
        ? '0 0 14px rgba(0, 242, 254, 0.55)'
        : '0 0 14px rgba(var(--kh-accent-rgb), 0.55)';

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="w-full min-h-[52px] flex items-center justify-between gap-4 px-4 py-2.5 rounded-2xl bg-[#161B26]/80 border border-white/[0.08] hover:border-white/[0.16] transition-colors duration-150 text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE]"
    >
      <div className="min-w-0">
        <div className="text-[14px] font-medium text-[#E1E2EB] truncate">
          {label}
        </div>
        {description && (
          <div className="text-[12px] text-[#849495] truncate">
            {description}
          </div>
        )}
      </div>

      <span
        aria-hidden="true"
        className="relative inline-flex items-center w-12 h-7 rounded-full bg-[#0B0E14] border border-white/[0.12] shrink-0 p-1 transition-colors duration-150"
      >
        <span
          className="w-5 h-5 rounded-full transition-transform duration-150 ease-[cubic-bezier(0.16,1,0.3,1)]"
          style={{
            transform: checked ? 'translateX(20px)' : 'translateX(0px)',
            backgroundColor: checked ? activeColor : '#3B4457',
            boxShadow: checked ? activeShadow : 'none',
          }}
        />
      </span>
    </button>
  );
};
