import React from 'react';
import { Lock, Unlock, Car, BluetoothConnected, Bluetooth } from 'lucide-react';
import { BluetoothLinkState, ScreenId, VehicleProfile } from '../types/vehicle';

interface TopBarProps {
  vehicle: VehicleProfile;
  bluetooth: BluetoothLinkState;
  onChangeVehicle: () => void;
  activeScreen: ScreenId;
  onSelectScreen: (screen: ScreenId) => void;
  locked: boolean;
  onToggleLock: () => void;
}

const NAV_ITEMS: { id: ScreenId; label: string }[] = [
  { id: 'spatial', label: '4D & Air Quality' },
  { id: 'navigation', label: 'Google Maps Routes' },
  { id: 'cockpit', label: 'Cockpit' },
  { id: 'energy', label: 'Energy' },
  { id: 'vehicle', label: 'Vehicle' },
  { id: 'companion', label: 'Companion' },
];

export const TopBar: React.FC<TopBarProps> = ({
  vehicle,
  bluetooth,
  onChangeVehicle,
  activeScreen,
  onSelectScreen,
  locked,
  onToggleLock,
}) => {
  return (
    <header className="sticky top-0 z-40 kh-glass border-b border-white/[0.08]">
      <div className="max-w-[1440px] mx-auto px-4 md:px-8 lg:px-12 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <button
          type="button"
          onClick={() => onSelectScreen('spatial')}
          className="font-display text-lg md:text-xl font-bold tracking-tight text-[#E1E2EB] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] rounded-md px-1"
        >
          Kinetic Horizon
        </button>

        {/* Zone 2: Clean single-line text nav links */}
        <nav
          aria-label="Primary cockpit screens"
          className="flex items-center gap-4 md:gap-6 overflow-x-auto no-scrollbar"
        >
          {NAV_ITEMS.map((item) => {
            const active = activeScreen === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectScreen(item.id)}
                className={`relative py-2 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] rounded-md px-1 ${
                  active
                    ? 'text-[#E0FDFF]'
                    : 'text-[#849495] hover:text-[#E1E2EB]'
                }`}
              >
                {item.label}
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute left-1 right-1 bottom-0.5 h-[2px] rounded-full transition-colors duration-200"
                    style={{
                      backgroundColor: 'var(--kh-accent)',
                      boxShadow: '0 0 10px rgba(var(--kh-accent-rgb), 0.7)',
                    }}
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Selected Car Switcher + BT Indicator + Lock */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onChangeVehicle}
            title="Select a different car model"
            className="hidden sm:inline-flex items-center gap-2 min-h-[38px] px-3.5 rounded-full bg-[#131722] border border-white/[0.14] text-xs font-medium text-[#E1E2EB] hover:border-[#00F2FE]/60 transition-colors max-w-[200px] cursor-pointer"
          >
            <Car className="w-3.5 h-3.5 text-[#00F2FE] shrink-0" />
            <span className="truncate">{vehicle.name}</span>
          </button>

          <span
            title={
              bluetooth.status === 'connected'
                ? `Bluetooth paired: ${bluetooth.deviceName}`
                : 'Bluetooth not paired'
            }
            className={`hidden md:inline-flex items-center gap-1.5 min-h-[38px] px-3 rounded-full border text-[11px] font-mono ${
              bluetooth.status === 'connected'
                ? 'bg-[#10E7A9]/15 border-[#10E7A9]/50 text-[#10E7A9]'
                : 'bg-[#131722] border-white/[0.1] text-[#849495]'
            }`}
          >
            {bluetooth.status === 'connected' ? (
              <BluetoothConnected className="w-3.5 h-3.5" />
            ) : (
              <Bluetooth className="w-3.5 h-3.5" />
            )}
            <span>{bluetooth.status === 'connected' ? 'BT Paired' : 'BT Off'}</span>
          </span>

          <button
            type="button"
            onClick={onToggleLock}
            className={`inline-flex items-center justify-center gap-2 min-h-[38px] px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00F2FE] ${
              locked
                ? 'bg-transparent border border-white/20 text-[#E1E2EB] hover:border-white/70 hover:text-white'
                : 'text-[#0B0E14] font-semibold'
            }`}
            style={
              !locked
                ? {
                    backgroundColor: 'var(--kh-accent)',
                    boxShadow: '0 0 16px rgba(var(--kh-accent-rgb), 0.35)',
                  }
                : undefined
            }
          >
            {locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{locked ? 'Unlock' : 'Lock'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
