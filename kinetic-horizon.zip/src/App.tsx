import { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { CarSelectorOnboarding } from './components/CarSelectorOnboarding';
import { CockpitScreen } from './components/CockpitScreen';
import { CompanionScreen } from './components/CompanionScreen';
import { DriveModeDock } from './components/DriveModeDock';
import { EnergyScreen } from './components/EnergyScreen';
import { NavigationScreen } from './components/NavigationScreen';
import { Spatial4DScreen } from './components/Spatial4DScreen';
import { TopBar } from './components/TopBar';
import { VehicleStudioScreen } from './components/VehicleStudioScreen';
import {
  DRIVE_MODE_SPECS,
  INITIAL_TIRES,
  VEHICLE_PRESETS,
} from './data/vehicleData';
import {
  AeroWingMode,
  AirQualityReport,
  BluetoothLinkState,
  ClimateState,
  DriveMode,
  Gear,
  RegenLevel,
  ScreenId,
  SuspensionHeight,
  VehicleProfile,
} from './types/vehicle';

export default function App() {
  // Step 1: Ask first which car the user is driving before entering the 4D & route workflow
  const [vehicle, setVehicle] = useState<VehicleProfile>(VEHICLE_PRESETS[0]);
  const [hasSelectedVehicle, setHasSelectedVehicle] = useState<boolean>(false);

  const [activeScreen, setActiveScreen] = useState<ScreenId>('spatial');
  const [driveMode, setDriveMode] = useState<DriveMode>('comfort');
  const [gear, setGear] = useState<Gear>('D');

  const [speedKmh, setSpeedKmh] = useState<number>(114);
  const [powerKw, setPowerKw] = useState<number>(42);
  const [cruiseEnabled, setCruiseEnabled] = useState<boolean>(true);
  const [cruiseTargetKmh, setCruiseTargetKmh] = useState<number>(120);

  const [batteryPct, setBatteryPct] = useState<number>(82);
  const [chargeLimitPct, setChargeLimitPct] = useState<number>(80);
  const [isCharging, setIsCharging] = useState<boolean>(false);
  const [chargingRateKw, setChargingRateKw] = useState<number>(248);
  const [batteryTempC, setBatteryTempC] = useState<number>(28.4);
  const [preconditioning, setPreconditioning] = useState<boolean>(false);
  const [scheduledDeparture, setScheduledDeparture] = useState<boolean>(true);
  const [regenLevel, setRegenLevel] = useState<RegenLevel>('standard');

  const [selectedRouteId, setSelectedRouteId] = useState<string>('lhr-isb');

  const [locked, setLocked] = useState<boolean>(false);
  const [sentryActive, setSentryActive] = useState<boolean>(true);
  const [frunkOpen, setFrunkOpen] = useState<boolean>(false);
  const [trunkOpen, setTrunkOpen] = useState<boolean>(false);
  const [chargePortOpen, setChargePortOpen] = useState<boolean>(false);
  const [suspension, setSuspension] = useState<SuspensionHeight>('standard');
  const [aeroWing, setAeroWing] = useState<AeroWingMode>('auto');
  const [ambientIntensity, setAmbientIntensity] = useState<number>(75);

  const [climate, setClimate] = useState<ClimateState>({
    driverTempC: 21.5,
    passengerTempC: 22.0,
    fanLevel: 3,
    seatHeatDriver: 1,
    seatHeatPassenger: 0,
    hepaFilter: true,
    autoDefrost: false,
    preConditionCabin: false,
  });

  const [airReport, setAirReport] = useState<AirQualityReport>({
    status: 'idle',
    lastCheckedAt: null,
    sourceLabel: 'Cabin HEPA Sensor Ready',
    ambientAqi: null,
    ambientCategory: 'Awaiting Check',
    dominantPollutant: 'PM2.5',
    cabinPm25: 4.5,
    cabinCo2Ppm: 441,
    vocIndex: 14,
    filterEfficiencyPct: 99.4,
    healthRecommendation:
      'Run the air quality & airflow check to measure ambient air and optimize cabin HEPA recirculation.',
    intakeCfm: 229,
    cabinAirflowVelocityMs: 1.65,
    airflowBalancePct: 97,
    recirculationRecommended: true,
  });

  const [bluetooth, setBluetooth] = useState<BluetoothLinkState>({
    status: 'disconnected',
    deviceName: null,
    transport: null,
    signalDbm: null,
    pairedAt: null,
    errorMessage: null,
  });

  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState<boolean>(false);

  useEffect(() => {
    const onQuotaExceeded = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  const modeSpec = DRIVE_MODE_SPECS[driveMode];
  const rangeKm = Math.round((batteryPct / 100) * vehicle.rangeKmFull * modeSpec.rangeMultiplier);

  // Subtle live cockpit physics loop (speed/power settling + charging increment)
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (isCharging) {
        setSpeedKmh(0);
        setPowerKw(0);
        setBatteryPct((prev) => {
          if (prev >= chargeLimitPct) return prev;
          return Math.min(chargeLimitPct, Number((prev + 0.15).toFixed(2)));
        });
        setChargingRateKw((prev) => {
          const base = batteryPct > 75 ? 128 : batteryPct > 50 ? 224 : 312;
          return Math.round(base + (prev % 3 === 0 ? 2 : -1));
        });
        return;
      }

      if (gear === 'P' || gear === 'N') {
        setSpeedKmh((s) => Math.max(0, s - 6));
        setPowerKw(0);
        return;
      }

      if (cruiseEnabled && gear === 'D') {
        setSpeedKmh((curr) => {
          const diff = cruiseTargetKmh - curr;
          if (Math.abs(diff) < 0.8) return cruiseTargetKmh;
          return Number((curr + diff * 0.25).toFixed(1));
        });
        setPowerKw((curr) => {
          const targetPower = Math.round((cruiseTargetKmh / 120) * 34);
          return Math.round(curr + (targetPower - curr) * 0.35);
        });
      } else {
        setPowerKw((curr) => {
          if (Math.abs(curr) < 2) return 0;
          return Math.round(curr * 0.72);
        });
      }
    }, 350);

    return () => window.clearInterval(timer);
  }, [isCharging, chargeLimitPct, gear, cruiseEnabled, cruiseTargetKmh, batteryPct]);

  const handleConfirmVehicle = (selected: VehicleProfile) => {
    setVehicle(selected);
    setHasSelectedVehicle(true);
    setActiveScreen('spatial');
  };

  const handleChangeGear = (next: Gear) => {
    setGear(next);
    if (next === 'P') {
      setCruiseEnabled(false);
      setSpeedKmh(0);
      setPowerKw(0);
    } else if (next === 'D' && isCharging) {
      setIsCharging(false);
      setChargePortOpen(false);
    }
  };

  const handleThrottlePulse = () => {
    if (isCharging) {
      setIsCharging(false);
      setChargePortOpen(false);
    }
    if (gear === 'P' || gear === 'N') {
      setGear('D');
    }
    setCruiseEnabled(false);
    setSpeedKmh((s) => Math.min(250, Math.round(s + 18)));
    setPowerKw(Math.round(modeSpec.maxPowerKw * 0.68));
  };

  const handleRegenBrakePulse = () => {
    setCruiseEnabled(false);
    setSpeedKmh((s) => Math.max(0, Math.round(s - 22)));
    const regenCap = regenLevel === 'one-pedal' ? -116 : regenLevel === 'standard' ? -84 : -48;
    setPowerKw(speedKmh > 6 ? regenCap : 0);
  };

  const handleAdjustCruise = (delta: number) => {
    setCruiseTargetKmh((t) => Math.max(30, Math.min(210, t + delta)));
    if (!cruiseEnabled && gear === 'D') {
      setCruiseEnabled(true);
    }
  };

  const handleSimulateCharging = () => {
    if (!isCharging) {
      setGear('P');
      setCruiseEnabled(false);
      setChargePortOpen(true);
      setIsCharging(true);
      setBatteryTempC(29.2);
    } else {
      setIsCharging(false);
      setChargePortOpen(false);
    }
  };

  const handleSimulateLowBattery = () => {
    setIsCharging(false);
    setBatteryPct(8);
  };

  const handleResetNominal = () => {
    setIsCharging(false);
    setChargePortOpen(false);
    setBatteryPct(82);
    setBatteryTempC(28.4);
  };

  const handleUpdateClimate = (patch: Partial<ClimateState>) => {
    setClimate((prev) => ({ ...prev, ...patch }));
  };

  return (
    <div
      data-drive-mode={driveMode}
      className="min-h-screen bg-[#0B0E14] text-[#E1E2EB] flex flex-col"
    >
      {/* Case A Tier 1: Global Google Maps Platform Free Tier / Quota Banner */}
      {gmpQuotaExceeded && (
        <div
          role="alert"
          className="sticky top-0 z-50 bg-[#F59E0B] text-[#0B0E14] px-4 py-2.5 text-xs md:text-sm font-medium flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-2.5 max-w-[1440px] mx-auto w-full">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>
              Google Maps Platform free-tier quota or key authorization limit reached. Live map tiles, route busyness, or ambient air quality lookups may pause until billing or quota is renewed in Google Cloud Console.
            </span>
          </div>
          <button
            type="button"
            aria-label="Dismiss Google Maps quota notice"
            onClick={() => setGmpQuotaExceeded(false)}
            className="p-1 rounded-md hover:bg-black/10 shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <TopBar
        vehicle={vehicle}
        bluetooth={bluetooth}
        onChangeVehicle={() => setHasSelectedVehicle(false)}
        activeScreen={activeScreen}
        onSelectScreen={(scr) => {
          setHasSelectedVehicle(true);
          setActiveScreen(scr);
        }}
        locked={locked}
        onToggleLock={() => setLocked((prev) => !prev)}
      />

      <main className="flex-1 w-full max-w-[1440px] mx-auto px-4 md:px-8 lg:px-12 py-6 md:py-8">
        {!hasSelectedVehicle ? (
          <CarSelectorOnboarding
            currentVehicle={vehicle}
            onConfirmVehicle={handleConfirmVehicle}
          />
        ) : (
          <>
            {/* Guided 3-Step Workflow Strip + Drive Mode & Reserve Telemetry */}
            <div className="mb-6 pb-5 border-b border-white/[0.06] flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setHasSelectedVehicle(false)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#131722] border border-[#10E7A9]/45 text-xs font-medium text-[#10E7A9] hover:border-[#10E7A9] cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>1. Car: {vehicle.name}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveScreen('spatial')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border text-xs font-medium cursor-pointer transition-colors ${
                    activeScreen === 'spatial'
                      ? 'bg-[#00F2FE] text-[#0B0E14] border-transparent font-semibold'
                      : 'bg-[#131722] border-white/[0.12] text-[#E1E2EB] hover:border-[#00F2FE]/50'
                  }`}
                >
                  <span>2. 4D Model, Air Quality & Bluetooth</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveScreen('navigation')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border text-xs font-medium cursor-pointer transition-colors ${
                    activeScreen === 'navigation'
                      ? 'bg-[#00F2FE] text-[#0B0E14] border-transparent font-semibold'
                      : 'bg-[#131722] border-white/[0.12] text-[#E1E2EB] hover:border-[#00F2FE]/50'
                  }`}
                >
                  <span>3. Google Maps Routes & Traffic</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <DriveModeDock mode={driveMode} onChange={setDriveMode} />
                <span
                  className="font-mono tabular-nums text-xs font-medium"
                  style={{
                    color:
                      batteryPct < 10
                        ? '#F59E0B'
                        : isCharging
                          ? '#00F2FE'
                          : '#10E7A9',
                  }}
                >
                  {batteryPct.toFixed(0)}% · {rangeKm} km
                </span>
              </div>
            </div>

            {activeScreen === 'cockpit' && (
              <CockpitScreen
                vehicle={vehicle}
                bluetooth={bluetooth}
                airReport={airReport}
                driveMode={driveMode}
                gear={gear}
                onChangeGear={handleChangeGear}
                speedKmh={speedKmh}
                powerKw={powerKw}
                cruiseEnabled={cruiseEnabled}
                cruiseTargetKmh={cruiseTargetKmh}
                onToggleCruise={() => {
                  if (gear !== 'D') setGear('D');
                  setCruiseEnabled((prev) => !prev);
                }}
                onAdjustCruise={handleAdjustCruise}
                onThrottlePulse={handleThrottlePulse}
                onRegenBrakePulse={handleRegenBrakePulse}
                batteryPct={batteryPct}
                rangeKm={rangeKm}
                isCharging={isCharging}
                chargingRateKw={chargingRateKw}
                batteryTempC={batteryTempC}
                onSimulateCharging={handleSimulateCharging}
                onSimulateLowBattery={handleSimulateLowBattery}
                onResetNominal={handleResetNominal}
                climate={climate}
                onUpdateClimate={handleUpdateClimate}
                tires={INITIAL_TIRES}
                selectedRouteId={selectedRouteId}
                onOpenNavigation={() => setActiveScreen('navigation')}
                onNavigateScreen={setActiveScreen}
              />
            )}

            {activeScreen === 'spatial' && (
              <Spatial4DScreen
                vehicle={vehicle}
                driveMode={driveMode}
                speedKmh={speedKmh}
                powerKw={powerKw}
                suspension={suspension}
                aeroWing={aeroWing}
                frunkOpen={frunkOpen}
                trunkOpen={trunkOpen}
                climate={climate}
                airReport={airReport}
                bluetooth={bluetooth}
                onUpdateClimate={handleUpdateClimate}
                onUpdateAirReport={setAirReport}
                onUpdateBluetooth={setBluetooth}
                onChangeVehicle={() => setHasSelectedVehicle(false)}
                onNavigateScreen={setActiveScreen}
                onChangeDriveMode={setDriveMode}
              />
            )}

            {activeScreen === 'navigation' && (
              <NavigationScreen
                vehicle={vehicle}
                batteryPct={batteryPct}
                airReport={airReport}
                bluetooth={bluetooth}
                selectedRouteId={selectedRouteId}
                onSelectRoute={setSelectedRouteId}
                preconditioning={preconditioning}
                onTogglePreconditioning={setPreconditioning}
              />
            )}

            {activeScreen === 'energy' && (
              <EnergyScreen
                batteryPct={batteryPct}
                chargeLimitPct={chargeLimitPct}
                onChangeChargeLimit={setChargeLimitPct}
                regenLevel={regenLevel}
                onChangeRegenLevel={setRegenLevel}
                preconditioning={preconditioning}
                onTogglePreconditioning={setPreconditioning}
                scheduledDeparture={scheduledDeparture}
                onToggleScheduledDeparture={setScheduledDeparture}
              />
            )}

            {activeScreen === 'vehicle' && (
              <VehicleStudioScreen
                vehicle={vehicle}
                bluetooth={bluetooth}
                locked={locked}
                onToggleLock={() => setLocked((p) => !p)}
                sentryActive={sentryActive}
                onToggleSentry={setSentryActive}
                frunkOpen={frunkOpen}
                onToggleFrunk={() => setFrunkOpen((p) => !p)}
                trunkOpen={trunkOpen}
                onToggleTrunk={() => setTrunkOpen((p) => !p)}
                chargePortOpen={chargePortOpen}
                onToggleChargePort={() => setChargePortOpen((p) => !p)}
                suspension={suspension}
                onChangeSuspension={setSuspension}
                aeroWing={aeroWing}
                onChangeAeroWing={setAeroWing}
                ambientIntensity={ambientIntensity}
                onChangeAmbientIntensity={setAmbientIntensity}
                onOpenSpatial4D={() => setActiveScreen('spatial')}
              />
            )}

            {activeScreen === 'companion' && (
              <CompanionScreen
                vehicle={vehicle}
                bluetooth={bluetooth}
                batteryPct={batteryPct}
                rangeKm={rangeKm}
                isCharging={isCharging}
                locked={locked}
                onToggleLock={() => setLocked((p) => !p)}
                frunkOpen={frunkOpen}
                onToggleFrunk={() => setFrunkOpen((p) => !p)}
                trunkOpen={trunkOpen}
                onToggleTrunk={() => setTrunkOpen((p) => !p)}
                chargePortOpen={chargePortOpen}
                onToggleChargePort={() => setChargePortOpen((p) => !p)}
                sentryActive={sentryActive}
                onToggleSentry={setSentryActive}
                climate={climate}
                onUpdateClimate={handleUpdateClimate}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
