import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  AeroWingMode,
  DriveMode,
  SuspensionHeight,
  VehicleBodyType,
} from '../types/vehicle';

export type CameraPreset = 'hero' | 'side' | 'top' | 'drivetrain';

export interface SpatialSceneParams {
  vehicleBodyType: VehicleBodyType;
  vehicleColorHex: string;
  driveMode: DriveMode;
  accentHex: string;
  speedKmh: number;
  powerKw: number;
  suspension: SuspensionHeight;
  aeroWing: AeroWingMode;
  frunkOpen: boolean;
  trunkOpen: boolean;
  explodeFactor: number; // 0..1
  xrayMode: boolean;
  showAeroFlow: boolean;
  showCabinAirflow: boolean;
  airflowLevel: number; // 1..5
  showLidar4D: boolean;
  timeOffsetSec: number; // -10..10 for 4D temporal scrubbing
  isTimePlaying: boolean;
  cameraPreset: CameraPreset;
}

const CAMERA_PRESETS: Record<
  CameraPreset,
  { pos: [number, number, number]; target: [number, number, number] }
> = {
  hero: { pos: [4.6, 2.05, 4.4], target: [0, 0.58, 0] },
  side: { pos: [0.0, 1.15, 5.8], target: [0, 0.58, 0] },
  top: { pos: [0.05, 6.2, 0.65], target: [0, 0.45, 0] },
  drivetrain: { pos: [3.6, 2.4, -3.5], target: [0, 0.45, 0] },
};

// Pre-allocated math helpers outside render loop (zero GC)
const _targetPos = new THREE.Vector3();
const _targetLook = new THREE.Vector3();
const _dummy = new THREE.Object3D();
const _color = new THREE.Color();

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createTurntableTexture(): THREE.CanvasTexture {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const cx = size / 2;
  const cy = size / 2;

  ctx.fillStyle = '#0B0E14';
  ctx.fillRect(0, 0, size, size);

  const radii = [140, 220, 310, 410, 480];
  radii.forEach((r, idx) => {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.strokeStyle =
      idx === 3 ? 'rgba(0, 242, 254, 0.22)' : 'rgba(255, 255, 255, 0.06)';
    ctx.lineWidth = idx === 3 ? 2 : 1;
    ctx.stroke();
  });

  for (let i = 0; i < 72; i++) {
    const angle = (i / 72) * Math.PI * 2;
    const inner = i % 6 === 0 ? 458 : 468;
    const outer = 480;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
    ctx.lineTo(cx + Math.cos(angle) * outer, cy + Math.sin(angle) * outer);
    ctx.strokeStyle =
      i % 6 === 0 ? 'rgba(0, 242, 254, 0.35)' : 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = i % 6 === 0 ? 2 : 1;
    ctx.stroke();
  }

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(cx - 480, cy);
  ctx.lineTo(cx + 480, cy);
  ctx.moveTo(cx, cy - 480);
  ctx.lineTo(cx, cy + 480);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 128, 16, 128, 128, 124);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.78)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.42)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

interface BodyDimensions {
  wheelBaseHalf: number;
  wheelRadius: number;
  trackHalf: number;
  rideBaseOffset: number;
  peakRoofHeight: number;
  noseX: number;
  tailX: number;
}

const BODY_SPECS: Record<VehicleBodyType, BodyDimensions> = {
  coupe: {
    wheelBaseHalf: 1.42,
    wheelRadius: 0.35,
    trackHalf: 0.92,
    rideBaseOffset: 0,
    peakRoofHeight: 1.24,
    noseX: -2.18,
    tailX: 2.18,
  },
  sedan: {
    wheelBaseHalf: 1.4,
    wheelRadius: 0.34,
    trackHalf: 0.9,
    rideBaseOffset: 0.02,
    peakRoofHeight: 1.32,
    noseX: -2.15,
    tailX: 2.16,
  },
  suv: {
    wheelBaseHalf: 1.38,
    wheelRadius: 0.4,
    trackHalf: 0.96,
    rideBaseOffset: 0.14,
    peakRoofHeight: 1.62,
    noseX: -2.1,
    tailX: 2.08,
  },
  hatchback: {
    wheelBaseHalf: 1.24,
    wheelRadius: 0.33,
    trackHalf: 0.88,
    rideBaseOffset: 0.03,
    peakRoofHeight: 1.38,
    noseX: -1.9,
    tailX: 1.72,
  },
};

export class KineticVehicleScene {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private isSoftwareGl: boolean;
  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;

  // Vehicle hierarchy
  private vehicleRoot = new THREE.Group();
  private chassisGroup = new THREE.Group();
  private bodyShellGroup = new THREE.Group();
  private frunkPivot = new THREE.Group();
  private wingPivot = new THREE.Group();
  private drivetrainGroup = new THREE.Group();
  private wheels: THREE.Group[] = [];

  // Materials updated dynamically
  private bodyMat!: THREE.MeshPhysicalMaterial;
  private carbonMat!: THREE.MeshStandardMaterial;
  private canopyMat!: THREE.MeshPhysicalMaterial;
  private accentEmissiveMat!: THREE.MeshStandardMaterial;
  private tailLightMat!: THREE.MeshStandardMaterial;
  private drlMat!: THREE.MeshStandardMaterial;
  private batteryGlowMat!: THREE.MeshStandardMaterial;
  private frontMotorMat!: THREE.MeshStandardMaterial;
  private rearMotorMat!: THREE.MeshStandardMaterial;

  // 4D Systems: Exterior Aero streamlines + Interior Cabin Airflow + LiDAR Horizon field
  private aeroGroup = new THREE.Group();
  private aeroParticles!: THREE.InstancedMesh;
  private aeroProgress: Float32Array;
  private aeroLanes: { z: number; heightOffset: number; speedScale: number }[] = [];

  private cabinAirGroup = new THREE.Group();
  private cabinAirParticles!: THREE.InstancedMesh;
  private cabinAirProgress: Float32Array;
  private cabinAirLanes: { z: number; yShift: number; speedScale: number }[] = [];

  private lidarGroup = new THREE.Group();
  private lidarRings: THREE.Mesh[] = [];
  private lidarGrid!: THREE.InstancedMesh;
  private lidarCoords: { x: number; z: number; dist: number }[] = [];

  private params: SpatialSceneParams;
  private currentExplode = 0;
  private currentRideY = 0;
  private currentFrunkAngle = 0;
  private currentWingAngle = 0;
  private currentPitch = 0;
  private wheelAngle = 0;
  private cameraTransitionActive = false;

  private staticDisposables: { dispose: () => void }[] = [];
  private vehicleDisposables: { dispose: () => void }[] = [];
  private resizeObserver: ResizeObserver;
  private onContextLostCb?: () => void;

  constructor(
    container: HTMLElement,
    initialParams: SpatialSceneParams,
    onContextLost?: () => void
  ) {
    this.container = container;
    this.params = { ...initialParams };
    this.onContextLostCb = onContextLost;
    this.isSoftwareGl = detectSoftwareGl();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = container.clientWidth || 960;
    const height = container.clientHeight || 580;
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.renderer.domElement.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      this.onContextLostCb?.();
    });

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b0e14);
    this.scene.fog = new THREE.FogExp2(0x0b0e14, 0.042);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = envTex;
    this.staticDisposables.push(envTex);
    pmrem.dispose();

    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 80);
    const preset = CAMERA_PRESETS[this.params.cameraPreset];
    this.camera.position.set(...preset.pos);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.06;
    this.controls.minDistance = 2.6;
    this.controls.maxDistance = 11.5;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.04;
    this.controls.target.set(...preset.target);
    this.controls.addEventListener('start', () => {
      this.cameraTransitionActive = false;
    });

    this.setupLighting();
    this.buildTurntable();
    this.initSharedMaterials();
    this.buildVehicleForBodyType(this.params.vehicleBodyType);

    this.aeroProgress = new Float32Array(160);
    this.cabinAirProgress = new Float32Array(72);
    this.build4DAeroFlow();
    this.build4DCabinAirflow();
    this.build4DLidarField();

    this.scene.add(this.vehicleRoot);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    this.startLoop();
  }

  private trackStatic<T extends { dispose: () => void }>(item: T): T {
    this.staticDisposables.push(item);
    return item;
  }

  private trackVehicle<T extends { dispose: () => void }>(item: T): T {
    this.vehicleDisposables.push(item);
    return item;
  }

  private setupLighting(): void {
    const hemi = new THREE.HemisphereLight(0x9bcbff, 0x0b0e14, 0.78);
    this.scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff5ea, 2.25);
    keyLight.position.set(5.5, 7.5, 5.0);
    if (!this.isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.near = 1;
      keyLight.shadow.camera.far = 22;
      keyLight.shadow.camera.left = -4.5;
      keyLight.shadow.camera.right = 4.5;
      keyLight.shadow.camera.top = 4.5;
      keyLight.shadow.camera.bottom = -4.5;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x00f2fe, 1.35);
    rimLight.position.set(-5.5, 3.2, -4.5);
    this.scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight(0x4facfe, 0.68);
    fillLight.position.set(-4.0, 2.0, 5.0);
    this.scene.add(fillLight);
  }

  private buildTurntable(): void {
    const tex = this.trackStatic(createTurntableTexture());
    tex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();

    const floorGeo = this.trackStatic(new THREE.CircleGeometry(7.5, 72));
    const floorMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        map: tex,
        roughness: 0.72,
        metalness: 0.25,
      })
    );
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    this.scene.add(floor);

    const shadowTex = this.trackStatic(createContactShadowTexture());
    const shadowGeo = this.trackStatic(new THREE.PlaneGeometry(5.2, 2.8));
    const shadowMat = this.trackStatic(
      new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.68,
      })
    );
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.015;
    this.scene.add(shadowPlane);
  }

  private initSharedMaterials(): void {
    this.bodyMat = this.trackStatic(
      new THREE.MeshPhysicalMaterial({
        color: this.params.vehicleColorHex || '#1B212E',
        metalness: 0.85,
        roughness: 0.24,
        clearcoat: 1.0,
        clearcoatRoughness: 0.08,
      })
    );

    this.carbonMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: 0x11151d,
        metalness: 0.35,
        roughness: 0.62,
      })
    );

    this.canopyMat = this.trackStatic(
      new THREE.MeshPhysicalMaterial({
        color: 0x070a10,
        metalness: 0.15,
        roughness: 0.06,
        clearcoat: 1.0,
        transparent: true,
        opacity: 0.86,
      })
    );

    this.accentEmissiveMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: this.params.accentHex,
        emissive: this.params.accentHex,
        emissiveIntensity: 2.2,
        roughness: 0.2,
        metalness: 0.1,
      })
    );

    this.tailLightMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: 0xff4b3e,
        emissive: 0xff3b2f,
        emissiveIntensity: 2.0,
        roughness: 0.2,
      })
    );

    this.drlMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: 0xe0fdff,
        emissive: 0x9ef9ff,
        emissiveIntensity: 2.4,
        roughness: 0.15,
      })
    );

    this.batteryGlowMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: 0x0b3b3e,
        emissive: 0x00f2fe,
        emissiveIntensity: 0.85,
        roughness: 0.3,
        metalness: 0.6,
      })
    );

    this.frontMotorMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: 0x3b4457,
        emissive: 0x00f2fe,
        emissiveIntensity: 0.9,
        metalness: 0.85,
        roughness: 0.25,
      })
    );

    this.rearMotorMat = this.trackStatic(
      new THREE.MeshStandardMaterial({
        color: 0x3b4457,
        emissive: 0x10e7a9,
        emissiveIntensity: 1.1,
        metalness: 0.85,
        roughness: 0.25,
      })
    );
  }

  private clearVehicleGroups(): void {
    this.bodyShellGroup.clear();
    this.frunkPivot.clear();
    this.wingPivot.clear();
    this.drivetrainGroup.clear();
    this.chassisGroup.clear();

    for (const wg of this.wheels) {
      this.vehicleRoot.remove(wg);
    }
    this.wheels = [];
    this.vehicleRoot.remove(this.chassisGroup);

    for (const d of this.vehicleDisposables) {
      d.dispose();
    }
    this.vehicleDisposables = [];
  }

  private buildVehicleForBodyType(bodyType: VehicleBodyType): void {
    this.clearVehicleGroups();

    const spec = BODY_SPECS[bodyType];
    const lift = spec.rideBaseOffset;

    // 1. Sculpted Lower Hull Profile per Car Type
    const hullShape = new THREE.Shape();
    if (bodyType === 'suv') {
      hullShape.moveTo(-2.08, 0.38);
      hullShape.lineTo(-2.1, 0.72);
      hullShape.quadraticCurveTo(-1.92, 0.95, -1.15, 1.0);
      hullShape.lineTo(1.88, 1.04);
      hullShape.quadraticCurveTo(2.08, 0.96, 2.08, 0.72);
      hullShape.lineTo(2.02, 0.38);
      hullShape.closePath();
    } else if (bodyType === 'sedan') {
      hullShape.moveTo(-2.14, 0.25);
      hullShape.lineTo(-2.16, 0.52);
      hullShape.quadraticCurveTo(-1.95, 0.74, -1.18, 0.8);
      hullShape.lineTo(1.38, 0.84);
      hullShape.quadraticCurveTo(2.05, 0.82, 2.16, 0.64);
      hullShape.lineTo(2.12, 0.27);
      hullShape.closePath();
    } else if (bodyType === 'hatchback') {
      hullShape.moveTo(-1.88, 0.25);
      hullShape.lineTo(-1.9, 0.54);
      hullShape.quadraticCurveTo(-1.72, 0.76, -1.04, 0.82);
      hullShape.lineTo(1.48, 0.86);
      hullShape.quadraticCurveTo(1.74, 0.8, 1.72, 0.55);
      hullShape.lineTo(1.68, 0.27);
      hullShape.closePath();
    } else {
      // coupe
      hullShape.moveTo(-2.15, 0.24);
      hullShape.lineTo(-2.18, 0.48);
      hullShape.quadraticCurveTo(-2.05, 0.7, -1.3, 0.77);
      hullShape.lineTo(1.25, 0.82);
      hullShape.quadraticCurveTo(2.05, 0.78, 2.18, 0.62);
      hullShape.lineTo(2.14, 0.26);
      hullShape.closePath();
    }

    const hullWidth = bodyType === 'suv' ? 1.8 : bodyType === 'hatchback' ? 1.62 : 1.72;
    const hullGeo = this.trackVehicle(
      new THREE.ExtrudeGeometry(hullShape, {
        depth: hullWidth,
        bevelEnabled: true,
        bevelThickness: 0.11,
        bevelSize: 0.08,
        bevelSegments: 4,
      })
    );
    hullGeo.translate(0, 0, -hullWidth / 2);
    const hullMesh = new THREE.Mesh(hullGeo, this.bodyMat);
    hullMesh.castShadow = true;
    hullMesh.receiveShadow = true;
    this.bodyShellGroup.add(hullMesh);

    // 2. Carbon Floor Pan
    const floorLen = bodyType === 'hatchback' ? 3.56 : 4.25;
    const floorPanGeo = this.trackVehicle(
      new THREE.BoxGeometry(floorLen, 0.08, hullWidth + 0.14)
    );
    const floorPan = new THREE.Mesh(floorPanGeo, this.carbonMat);
    floorPan.position.set(bodyType === 'hatchback' ? -0.08 : 0, 0.24 + lift * 0.85, 0);
    floorPan.castShadow = true;
    this.chassisGroup.add(floorPan);

    // 3. Upper Glasshouse / Cabin Canopy per Car Type
    const canopyShape = new THREE.Shape();
    if (bodyType === 'suv') {
      canopyShape.moveTo(-1.02, 0.98);
      canopyShape.lineTo(-0.34, 1.56);
      canopyShape.lineTo(1.38, 1.54);
      canopyShape.lineTo(1.9, 1.02);
      canopyShape.closePath();
    } else if (bodyType === 'sedan') {
      canopyShape.moveTo(-1.02, 0.78);
      canopyShape.quadraticCurveTo(-0.35, 1.32, 0.35, 1.31);
      canopyShape.lineTo(1.05, 1.24);
      canopyShape.lineTo(1.48, 0.83);
      canopyShape.closePath();
    } else if (bodyType === 'hatchback') {
      canopyShape.moveTo(-0.92, 0.8);
      canopyShape.lineTo(-0.24, 1.38);
      canopyShape.lineTo(1.16, 1.34);
      canopyShape.lineTo(1.58, 0.82);
      canopyShape.closePath();
    } else {
      canopyShape.moveTo(-1.05, 0.74);
      canopyShape.quadraticCurveTo(-0.35, 1.24, 0.45, 1.21);
      canopyShape.quadraticCurveTo(1.35, 1.12, 1.82, 0.79);
      canopyShape.closePath();
    }

    const canopyWidth = hullWidth - 0.32;
    const canopyGeo = this.trackVehicle(
      new THREE.ExtrudeGeometry(canopyShape, {
        depth: canopyWidth,
        bevelEnabled: true,
        bevelThickness: 0.08,
        bevelSize: 0.06,
        bevelSegments: 3,
      })
    );
    canopyGeo.translate(0, 0, -canopyWidth / 2);
    const canopyMesh = new THREE.Mesh(canopyGeo, this.canopyMat);
    canopyMesh.castShadow = true;
    this.bodyShellGroup.add(canopyMesh);

    // Optional SUV Roof Rails
    if (bodyType === 'suv') {
      [-0.56, 0.56].forEach((zRail) => {
        const railGeo = this.trackVehicle(new THREE.BoxGeometry(1.62, 0.045, 0.05));
        const rail = new THREE.Mesh(railGeo, this.carbonMat);
        rail.position.set(0.52, 1.62, zRail);
        this.bodyShellGroup.add(rail);
      });
    }

    // 4. Articulated Frunk / Engine Hood
    this.frunkPivot.position.set(bodyType === 'hatchback' ? -0.96 : -1.12, bodyType === 'suv' ? 1.0 : 0.79, 0);
    const frunkGeo = this.trackVehicle(
      new THREE.BoxGeometry(bodyType === 'hatchback' ? 0.72 : 0.88, 0.05, canopyWidth - 0.04)
    );
    const frunkMesh = new THREE.Mesh(frunkGeo, this.bodyMat);
    frunkMesh.position.set(-0.42, -0.02, 0);
    frunkMesh.rotation.z = 0.09;
    this.frunkPivot.add(frunkMesh);
    this.bodyShellGroup.add(this.frunkPivot);

    // 5. Rear Aero Wing / Roof Spoiler
    const wingX = bodyType === 'hatchback' ? 1.44 : bodyType === 'suv' ? 1.82 : 2.02;
    const wingY = bodyType === 'suv' ? 1.54 : bodyType === 'hatchback' ? 1.36 : 0.87;
    this.wingPivot.position.set(wingX, wingY, 0);
    const wingBladeGeo = this.trackVehicle(new THREE.BoxGeometry(0.28, 0.035, hullWidth - 0.1));
    const wingBlade = new THREE.Mesh(wingBladeGeo, this.carbonMat);
    wingBlade.castShadow = true;
    this.wingPivot.add(wingBlade);

    const wingEdgeGeo = this.trackVehicle(new THREE.BoxGeometry(0.03, 0.04, hullWidth - 0.09));
    const wingEdge = new THREE.Mesh(wingEdgeGeo, this.accentEmissiveMat);
    wingEdge.position.set(0.13, 0, 0);
    this.wingPivot.add(wingEdge);
    this.bodyShellGroup.add(this.wingPivot);

    // 6. Luminous Light Blades
    const frontBladeGeo = this.trackVehicle(new THREE.BoxGeometry(0.05, 0.045, hullWidth - 0.06));
    const frontBlade = new THREE.Mesh(frontBladeGeo, this.drlMat);
    frontBlade.position.set(spec.noseX - 0.02, bodyType === 'suv' ? 0.76 : 0.56, 0);
    this.bodyShellGroup.add(frontBlade);

    const rearBladeGeo = this.trackVehicle(new THREE.BoxGeometry(0.05, 0.045, hullWidth - 0.04));
    const rearBlade = new THREE.Mesh(rearBladeGeo, this.tailLightMat);
    rearBlade.position.set(spec.tailX + 0.02, bodyType === 'suv' ? 0.84 : 0.65, 0);
    this.bodyShellGroup.add(rearBlade);

    [-(hullWidth / 2 + 0.1), hullWidth / 2 + 0.1].forEach((zSide) => {
      const stripGeo = this.trackVehicle(
        new THREE.BoxGeometry(bodyType === 'hatchback' ? 2.1 : 2.55, 0.022, 0.022)
      );
      const strip = new THREE.Mesh(stripGeo, this.accentEmissiveMat);
      strip.position.set(0.0, 0.28 + lift * 0.85, zSide);
      this.bodyShellGroup.add(strip);
    });

    // 7. Internal Battery Pack & Twin Motors
    const cellCount = bodyType === 'hatchback' ? 8 : 10;
    for (let i = 0; i < cellCount; i++) {
      const cellGeo = this.trackVehicle(new THREE.BoxGeometry(0.21, 0.14, hullWidth - 0.36));
      const cell = new THREE.Mesh(cellGeo, this.batteryGlowMat);
      cell.position.set(-((cellCount - 1) * 0.23) / 2 + i * 0.23, 0.35 + lift * 0.85, 0);
      this.drivetrainGroup.add(cell);
    }

    const motorGeo = this.trackVehicle(new THREE.CylinderGeometry(0.17, 0.17, 0.78, 20));
    motorGeo.rotateX(Math.PI / 2);

    const frontMotor = new THREE.Mesh(motorGeo, this.frontMotorMat);
    frontMotor.position.set(-spec.wheelBaseHalf, spec.wheelRadius + 0.02, 0);
    this.drivetrainGroup.add(frontMotor);

    const rearMotor = new THREE.Mesh(motorGeo, this.rearMotorMat);
    rearMotor.position.set(spec.wheelBaseHalf, spec.wheelRadius + 0.02, 0);
    this.drivetrainGroup.add(rearMotor);

    // 8. Four Wheels flush on y = 0
    const wheelPositions: [number, number, number][] = [
      [-spec.wheelBaseHalf, spec.wheelRadius, spec.trackHalf],
      [-spec.wheelBaseHalf, spec.wheelRadius, -spec.trackHalf],
      [spec.wheelBaseHalf, spec.wheelRadius, spec.trackHalf],
      [spec.wheelBaseHalf, spec.wheelRadius, -spec.trackHalf],
    ];

    const tireMat = this.trackVehicle(
      new THREE.MeshStandardMaterial({
        color: 0x101217,
        roughness: 0.86,
        metalness: 0.05,
      })
    );
    const rimMat = this.trackVehicle(
      new THREE.MeshStandardMaterial({
        color: 0x849495,
        metalness: 0.92,
        roughness: 0.18,
      })
    );

    const r = spec.wheelRadius;
    const tireGeo = this.trackVehicle(new THREE.CylinderGeometry(r, r, 0.24, 32));
    tireGeo.rotateX(Math.PI / 2);

    const rimGeo = this.trackVehicle(new THREE.CylinderGeometry(r * 0.68, r * 0.68, 0.25, 24));
    rimGeo.rotateX(Math.PI / 2);

    const spokeGeo = this.trackVehicle(new THREE.BoxGeometry(r * 1.18, 0.038, 0.26));
    const capGeo = this.trackVehicle(new THREE.CylinderGeometry(0.055, 0.055, 0.27, 16));
    capGeo.rotateX(Math.PI / 2);

    wheelPositions.forEach(([wx, wy, wz]) => {
      const wg = new THREE.Group();
      wg.position.set(wx, wy, wz);

      const tire = new THREE.Mesh(tireGeo, tireMat);
      tire.castShadow = true;
      wg.add(tire);

      const rim = new THREE.Mesh(rimGeo, rimMat);
      wg.add(rim);

      for (let s = 0; s < 3; s++) {
        const spoke = new THREE.Mesh(spokeGeo, this.carbonMat);
        spoke.rotation.z = (s * Math.PI) / 3;
        wg.add(spoke);
      }

      const cap = new THREE.Mesh(capGeo, this.accentEmissiveMat);
      wg.add(cap);

      this.wheels.push(wg);
      this.vehicleRoot.add(wg);
    });

    this.chassisGroup.add(this.drivetrainGroup);
    this.chassisGroup.add(this.bodyShellGroup);
    this.vehicleRoot.add(this.chassisGroup);
  }

  private build4DAeroFlow(): void {
    const particleGeo = this.trackStatic(new THREE.BoxGeometry(0.24, 0.016, 0.016));
    const particleMat = this.trackStatic(
      new THREE.MeshBasicMaterial({
        color: 0x00f2fe,
        transparent: true,
        opacity: 0.78,
      })
    );
    this.aeroParticles = new THREE.InstancedMesh(particleGeo, particleMat, 160);
    this.aeroParticles.frustumCulled = false;

    const lanes = [-0.85, -0.52, -0.2, 0.2, 0.52, 0.85];
    for (let i = 0; i < 160; i++) {
      this.aeroProgress[i] = Math.random();
      const laneZ = lanes[i % lanes.length] + (Math.random() - 0.5) * 0.08;
      this.aeroLanes.push({
        z: laneZ,
        heightOffset: 0.06 + (i % 4) * 0.09,
        speedScale: 0.85 + Math.random() * 0.35,
      });
    }

    this.aeroGroup.add(this.aeroParticles);
    this.scene.add(this.aeroGroup);
  }

  private build4DCabinAirflow(): void {
    // 72 interior HVAC / HEPA airflow particles moving from front grille -> cabin -> rear extractor
    const airGeo = this.trackStatic(new THREE.BoxGeometry(0.16, 0.022, 0.022));
    const airMat = this.trackStatic(
      new THREE.MeshBasicMaterial({
        color: 0x10e7a9,
        transparent: true,
        opacity: 0.85,
      })
    );
    this.cabinAirParticles = new THREE.InstancedMesh(airGeo, airMat, 72);
    this.cabinAirParticles.frustumCulled = false;

    const zLanes = [-0.46, -0.22, 0, 0.22, 0.46];
    for (let i = 0; i < 72; i++) {
      this.cabinAirProgress[i] = Math.random();
      this.cabinAirLanes.push({
        z: zLanes[i % zLanes.length] + (Math.random() - 0.5) * 0.06,
        yShift: ((i % 3) - 1) * 0.09,
        speedScale: 0.85 + Math.random() * 0.3,
      });
    }

    this.cabinAirGroup.add(this.cabinAirParticles);
    this.scene.add(this.cabinAirGroup);
  }

  private build4DLidarField(): void {
    for (let i = 0; i < 4; i++) {
      const ringGeo = this.trackStatic(
        new THREE.RingGeometry(0.95, 1.0, 48, 1, Math.PI * 0.65, Math.PI * 0.7)
      );
      ringGeo.rotateX(-Math.PI / 2);
      const ringMat = this.trackStatic(
        new THREE.MeshBasicMaterial({
          color: 0x00f2fe,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.45,
          depthWrite: false,
        })
      );
      const mesh = new THREE.Mesh(ringGeo, ringMat);
      mesh.position.set(-1.6, 0.03, 0);
      mesh.userData.phase = i * 0.25;
      this.lidarRings.push(mesh);
      this.lidarGroup.add(mesh);
    }

    const dotGeo = this.trackStatic(new THREE.BoxGeometry(0.05, 0.02, 0.05));
    const dotMat = this.trackStatic(
      new THREE.MeshBasicMaterial({
        color: 0x10e7a9,
        transparent: true,
        opacity: 0.65,
      })
    );

    for (let gx = -5; gx <= 5; gx++) {
      for (let gz = -4; gz <= 4; gz++) {
        const x = gx * 0.65;
        const z = gz * 0.65;
        const dist = Math.hypot(x, z);
        if (dist > 1.75 && dist < 4.6) {
          this.lidarCoords.push({ x, z, dist });
        }
      }
    }

    this.lidarGrid = new THREE.InstancedMesh(
      dotGeo,
      dotMat,
      this.lidarCoords.length
    );
    this.lidarGrid.frustumCulled = false;
    this.lidarGroup.add(this.lidarGrid);
    this.scene.add(this.lidarGroup);
  }

  public updateParams(next: Partial<SpatialSceneParams>): void {
    const prevPreset = this.params.cameraPreset;
    const prevBodyType = this.params.vehicleBodyType;
    Object.assign(this.params, next);

    if (next.vehicleBodyType && next.vehicleBodyType !== prevBodyType) {
      this.buildVehicleForBodyType(next.vehicleBodyType);
    }

    if (next.cameraPreset && next.cameraPreset !== prevPreset) {
      this.cameraTransitionActive = true;
    }

    if (next.vehicleColorHex) {
      this.bodyMat.color.set(next.vehicleColorHex);
    }

    _color.set(this.params.accentHex);
    this.accentEmissiveMat.color.copy(_color);
    this.accentEmissiveMat.emissive.copy(_color);
    (this.aeroParticles.material as THREE.MeshBasicMaterial).color.copy(_color);

    const makeBodyTransparent = this.params.xrayMode || this.params.showCabinAirflow;
    this.bodyMat.transparent = makeBodyTransparent;
    this.bodyMat.opacity = this.params.xrayMode
      ? 0.22
      : this.params.showCabinAirflow
        ? 0.56
        : 1.0;
    this.bodyMat.depthWrite = !makeBodyTransparent;
    this.canopyMat.opacity = this.params.xrayMode ? 0.18 : 0.68;

    this.aeroGroup.visible = this.params.showAeroFlow;
    this.cabinAirGroup.visible = this.params.showCabinAirflow;
    this.lidarGroup.visible = this.params.showLidar4D;
  }

  private startLoop(): void {
    const tick = () => {
      if (this.disposed) return;
      const delta = Math.min(this.clock.getDelta(), 0.08);
      const elapsed = this.clock.getElapsedTime();

      this.stepSimulation(delta, elapsed);
      this.controls.update();
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };
    this.frameId = requestAnimationFrame(tick);
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private stepSimulation(delta: number, elapsed: number): void {
    const t4d = this.params.timeOffsetSec;
    const bodySpec = BODY_SPECS[this.params.vehicleBodyType];

    const temporalSpeed =
      Math.abs(t4d) > 0.05
        ? Math.max(0, this.params.speedKmh + Math.sin(t4d * 0.45) * 48)
        : this.params.speedKmh;

    const accelSlope =
      Math.abs(t4d) > 0.05
        ? Math.cos(t4d * 0.45) * 0.028
        : THREE.MathUtils.clamp(this.params.powerKw / 480, -0.025, 0.025);

    if (this.cameraTransitionActive) {
      const preset = CAMERA_PRESETS[this.params.cameraPreset];
      _targetPos.set(...preset.pos);
      _targetLook.set(...preset.target);
      this.camera.position.lerp(_targetPos, 1 - Math.exp(-5 * delta));
      this.controls.target.lerp(_targetLook, 1 - Math.exp(-5 * delta));
      if (this.camera.position.distanceTo(_targetPos) < 0.04) {
        this.cameraTransitionActive = false;
      }
    }

    this.currentExplode = THREE.MathUtils.damp(
      this.currentExplode,
      this.params.explodeFactor,
      6,
      delta
    );
    this.bodyShellGroup.position.y = this.currentExplode * 0.92;
    this.drivetrainGroup.position.y = this.currentExplode * 0.14;

    const targetRideY =
      this.params.suspension === 'low'
        ? -0.05
        : this.params.suspension === 'raised'
          ? 0.07
          : 0;
    this.currentRideY = THREE.MathUtils.damp(
      this.currentRideY,
      targetRideY,
      6,
      delta
    );
    this.currentPitch = THREE.MathUtils.damp(
      this.currentPitch,
      accelSlope,
      6,
      delta
    );
    this.chassisGroup.position.y = this.currentRideY;
    this.chassisGroup.rotation.z = -this.currentPitch;

    this.currentFrunkAngle = THREE.MathUtils.damp(
      this.currentFrunkAngle,
      this.params.frunkOpen ? -0.45 : 0,
      7,
      delta
    );
    this.frunkPivot.rotation.z = this.currentFrunkAngle;

    const targetWing =
      this.params.aeroWing === 'downforce'
        ? 0.34
        : this.params.aeroWing === 'auto'
          ? THREE.MathUtils.clamp(temporalSpeed / 400, 0.05, 0.28)
          : 0.02;
    this.currentWingAngle = THREE.MathUtils.damp(
      this.currentWingAngle,
      targetWing,
      6,
      delta
    );
    this.wingPivot.rotation.z = this.currentWingAngle;

    const angularSpeed = (temporalSpeed / 3.6) / bodySpec.wheelRadius;
    this.wheelAngle += angularSpeed * delta * 0.28;
    for (const wg of this.wheels) {
      wg.rotation.z = this.wheelAngle;
    }

    const regenActive = this.params.powerKw < 0 || accelSlope < -0.005;
    this.rearMotorMat.emissive.setHex(regenActive ? 0x10e7a9 : 0x00f2fe);
    this.rearMotorMat.emissiveIntensity =
      0.8 + Math.abs(Math.sin(elapsed * 2.5)) * 0.6;

    // Exterior 4D Aerodynamic Wind-Tunnel Streamlines adapted to selected vehicle height
    if (this.params.showAeroFlow) {
      const flowSpeed = Math.max(0.35, temporalSpeed / 95);
      const roofDelta = bodySpec.peakRoofHeight - 0.45;
      for (let i = 0; i < 160; i++) {
        this.aeroProgress[i] =
          (this.aeroProgress[i] + delta * flowSpeed * this.aeroLanes[i].speedScale * 0.55) %
          1;
        const u = this.aeroProgress[i];
        const x = -3.4 + u * 6.8;

        let yContour = 0.44 + bodySpec.rideBaseOffset;
        if (x > bodySpec.noseX && x < bodySpec.tailX) {
          const span = bodySpec.tailX - bodySpec.noseX;
          const norm = (x - bodySpec.noseX) / span;
          yContour = 0.48 + Math.sin(norm * Math.PI) * roofDelta;
        }
        const lane = this.aeroLanes[i];
        const y = yContour + lane.heightOffset + this.currentExplode * 0.25;

        _dummy.position.set(x, y, lane.z);
        const slope =
          x > bodySpec.noseX && x < bodySpec.tailX
            ? Math.cos(((x - bodySpec.noseX) / (bodySpec.tailX - bodySpec.noseX)) * Math.PI) *
              0.35
            : 0;
        _dummy.rotation.set(0, 0, slope);
        const stretch = 0.7 + flowSpeed * 0.7;
        _dummy.scale.set(stretch, 1, 1);
        _dummy.updateMatrix();
        this.aeroParticles.setMatrixAt(i, _dummy.matrix);
      }
      this.aeroParticles.instanceMatrix.needsUpdate = true;
    }

    // Interior 4D Cabin & HVAC Air Quality Flow
    if (this.params.showCabinAirflow) {
      const ventRate = 0.35 + this.params.airflowLevel * 0.22;
      const cabinHeight = bodySpec.peakRoofHeight - 0.36;
      for (let i = 0; i < 72; i++) {
        this.cabinAirProgress[i] =
          (this.cabinAirProgress[i] + delta * ventRate * this.cabinAirLanes[i].speedScale) %
          1;
        const u = this.cabinAirProgress[i];
        const x = -2.1 + u * 3.85;
        // Rises gently from front HEPA intake (-1.8) into cabin (-0.7..0.9) and exits rear
        const rise =
          u < 0.32
            ? THREE.MathUtils.lerp(0.58 + bodySpec.rideBaseOffset, cabinHeight, u / 0.32)
            : cabinHeight - Math.sin((u - 0.32) * Math.PI * 0.9) * 0.08;
        const lane = this.cabinAirLanes[i];

        _dummy.position.set(x, rise + lane.yShift, lane.z);
        _dummy.rotation.set(0, 0, u < 0.32 ? 0.32 : -0.06);
        _dummy.scale.set(0.8 + this.params.airflowLevel * 0.16, 1, 1);
        _dummy.updateMatrix();
        this.cabinAirParticles.setMatrixAt(i, _dummy.matrix);
      }
      this.cabinAirParticles.instanceMatrix.needsUpdate = true;
    }

    // 4D LiDAR Wave Rings + Horizon Matrix
    if (this.params.showLidar4D) {
      for (const ring of this.lidarRings) {
        const phase = (elapsed * 0.48 + ring.userData.phase) % 1;
        const scale = 0.6 + phase * 4.4;
        ring.scale.set(scale, 1, scale);
        (ring.material as THREE.MeshBasicMaterial).opacity = (1 - phase) * 0.55;
      }

      const sweepRadius = ((elapsed * 2.2) % 4.6) + 1.4;
      for (let i = 0; i < this.lidarCoords.length; i++) {
        const pt = this.lidarCoords[i];
        const waveDelta = Math.abs(pt.dist - sweepRadius);
        const lift = waveDelta < 0.55 ? (1 - waveDelta / 0.55) * 0.14 : 0;
        _dummy.position.set(pt.x, 0.03 + lift, pt.z);
        const s = 0.75 + lift * 4.5;
        _dummy.scale.set(s, 1 + lift * 6, s);
        _dummy.rotation.set(0, 0, 0);
        _dummy.updateMatrix();
        this.lidarGrid.setMatrixAt(i, _dummy.matrix);
      }
      this.lidarGrid.instanceMatrix.needsUpdate = true;
    }
  }

  private handleResize(): void {
    if (this.disposed) return;
    const width = this.container.clientWidth || 960;
    const height = this.container.clientHeight || 580;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    this.controls.dispose();
    for (const d of this.vehicleDisposables) {
      d.dispose();
    }
    for (const d of this.staticDisposables) {
      d.dispose();
    }
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
