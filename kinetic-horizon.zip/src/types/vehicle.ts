export type ScreenId =
  | 'cockpit'
  | 'spatial'
  | 'navigation'
  | 'energy'
  | 'vehicle'
  | 'companion';

export type DriveMode = 'range' | 'comfort' | 'sport' | 'track';

export type Gear = 'P' | 'R' | 'N' | 'D';

export type RegenLevel = 'low' | 'standard' | 'one-pedal';

export type SuspensionHeight = 'low' | 'standard' | 'raised';

export type AeroWingMode = 'auto' | 'eco' | 'downforce';

export type VehicleBodyType = 'sedan' | 'suv' | 'hatchback' | 'coupe';

export type PowertrainType = 'EV' | 'Hybrid' | 'Petrol';

export interface VehicleProfile {
  id: string;
  name: string;
  brand: string;
  bodyType: VehicleBodyType;
  powertrain: PowertrainType;
  rangeKmFull: number;
  dragCd: number;
  batteryOrTankLabel: string;
  colorHex: string;
  lengthLabel: string;
  wheelbaseLabel: string;
  summary: string;
}

export interface AirQualityReport {
  status: 'idle' | 'scanning' | 'complete' | 'error';
  lastCheckedAt: string | null;
  sourceLabel: string;
  ambientAqi: number | null;
  ambientCategory: string;
  dominantPollutant: string;
  cabinPm25: number;
  cabinCo2Ppm: number;
  vocIndex: number;
  filterEfficiencyPct: number;
  healthRecommendation: string;
  intakeCfm: number;
  cabinAirflowVelocityMs: number;
  airflowBalancePct: number;
  recirculationRecommended: boolean;
}

export interface BluetoothLinkState {
  status: 'disconnected' | 'scanning' | 'connected' | 'error';
  deviceName: string | null;
  transport: 'web-bluetooth' | 'obd-bridge' | null;
  signalDbm: number | null;
  pairedAt: string | null;
  errorMessage: string | null;
}

export interface TireTelemetry {
  id: 'FL' | 'FR' | 'RL' | 'RR';
  label: string;
  bar: number;
  psi: number;
  tempC: number;
}

export interface ClimateState {
  driverTempC: number;
  passengerTempC: number;
  fanLevel: number;
  seatHeatDriver: number;
  seatHeatPassenger: number;
  hepaFilter: boolean;
  autoDefrost: boolean;
  preConditionCabin: boolean;
}

export interface ChargerStation {
  id: string;
  name: string;
  corridorKm: number;
  maxKw: number;
  availableStalls: number;
  totalStalls: number;
  pricePerKwh: string;
  detourMin: number;
  chargeDurationMin: number;
  addedSocPct: number;
}

export interface RouteTimelinePlan {
  id: string;
  label: string;
  highway: string;
  distanceKm: number;
  driveDurationMin: number;
  recommendedRestMin: number;
  departureTime: string;
  arrivalSummary: string;
  projectedConsumptionKwh100: number;
  regenRecoveryKwh: number;
  elevationGainM: number;
  summary: string;
}

export interface RestTerminal {
  id: string;
  name: string;
  highwayMarker: string;
  category: 'Service Plaza' | 'Overnight Lodge' | 'Scenic Rest' | 'Heritage Stop';
  restDurationMin: number;
  hasFastChargerKw?: number;
  addedSocPct: number;
  facilities: string[];
  stayNote: string;
  coords: { lat: number; lng: number };
}

export interface RouteOption {
  id: string;
  name: string;
  origin: string;
  destination: string;
  originCoords: { lat: number; lng: number };
  destinationCoords: { lat: number; lng: number };
  corridorDescription: string;
  nextManeuver: string;
  nextManeuverDistM: number;
  elevationProfile: number[];
  plans: RouteTimelinePlan[];
  terminals: RestTerminal[];
  chargers: ChargerStation[];
}

export interface TripRecord {
  id: string;
  date: string;
  route: string;
  category: 'highway' | 'alpine' | 'urban';
  distanceKm: number;
  durationMin: number;
  avgSpeedKmh: number;
  consumptionKwh100: number;
  regenKwh: number;
}

export interface HardwareNode {
  id: string;
  subsystem: string;
  spec: string;
  tempC: number;
  voltageOrLoad: string;
  status: 'Nominal' | 'Active' | 'Standby';
}
