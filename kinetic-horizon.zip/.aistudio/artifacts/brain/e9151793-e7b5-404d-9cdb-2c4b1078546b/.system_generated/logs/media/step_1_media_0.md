---
name: Kinetic Horizon
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#191c22'
  surface-container: '#1d2026'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2eb'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e1e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#9bcbff'
  on-secondary: '#003256'
  secondary-container: '#3196e6'
  on-secondary-container: '#002c4b'
  tertiary: '#dfffed'
  on-tertiary: '#003826'
  tertiary-container: '#37f7b8'
  on-tertiary-container: '#006d4e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#d0e4ff'
  secondary-fixed-dim: '#9bcbff'
  on-secondary-fixed: '#001d34'
  on-secondary-fixed-variant: '#004a7a'
  tertiary-fixed: '#44ffbf'
  tertiary-fixed-dim: '#00e1a4'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#005139'
  background: '#10131a'
  on-background: '#e1e2eb'
  surface-variant: '#32353c'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-data-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  label-data-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.12em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1rem
  margin-cockpit: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-performance automotive intelligence, progressive luxury, and reductive Scandinavian-German minimalism. It caters to design-literate drivers, tech pioneers, and luxury EV owners who demand immediate clarity at speed and quiet refinement at rest. 

The aesthetic merges high-contrast technical minimalism with atmospheric digital glass. Heavy structural negative space, razor-sharp typographic scale, and pinpoint luminous indicators replace decorative noise. Interfaces must evoke the calculated poise of an advanced electric cockpit: calm, authoritative, aerodynamically lean, and laser-precise.

## Colors

The palette is engineered around an immersive deep-space baseline punctuated by coherent photon emissions. 

- **Primary (`#00F2FE` - Luminous Cyan):** Reserved for live telemetry, active drive modes, battery charge states, and prime interactive focus. It carries an inherent glow, reading instantly under both direct cabin sunlight and night-driving conditions.
- **Secondary (`#4FACFE` - Stratosphere Blue):** Supports navigation flows, secondary interactive states, and informational sub-indicators.
- **Tertiary (`#10E7A9` - Kinetic Green):** Dedicated strictly to regenerative braking metrics, optimal consumption milestones, and ready-to-drive validation states.
- **Neutral (`#0B0E14` - Deep Slate Obsidian):** Acts as the foundational void. Mid-neutrals are desaturated cold irons (`#161B26`, `#222938`, `#3B4457`) that build structural housing and instrument cluster bezels without creating visual glare.

## Typography

Typographic hierarchy enforces split-second glanceability and analytical sophistication. 

- **Display & Headlines (`Space Grotesk`):** Deliver sharp, technical character across vehicle model titles, current velocity, and high-level cabin controls. Letterforms feature geometric apertures and tight tracking for high mechanical presence.
- **Body (`Hanken Grotesk`):** Ensures friction-free readability across setting descriptions, navigational notes, and trip summaries.
- **Data & Telemetry (`JetBrains Mono`):** Applied to real-time kW draw, battery percentage, tire pressure readings, and speed units. The tabular monospaced architecture prevents layout jitter when values fluctuate dynamically.
- Always render `label-caps` in uppercase for spec badges, mode flags, and hardware sensor toggles.

## Layout & Spacing

The layout utilizes a structured 12-column fluid grid on central console touchscreens and desktop config views, condensing to an 8-column layout on auxiliary instrument clusters/tablets and a single 4-column column on mobile pairing apps.

- **Automotive Touch Zones:** Interactive targets near driver reach must observe generous internal breathing room to prevent mis-touches during vehicle motion. Minimum hit target size across in-cabin touch elements is 48px, with preferred sizing of 56px.
- **Margin Hierarchy:** Cockpit central displays deploy `margin-cockpit` (48px) to push interactive components inward from physical bezel borders, mitigating peripheral glare and bezel reach clipping. Mobile Companion layouts transition to `margin-mobile` (16px) with stacked informational tiles.

## Elevation & Depth

Visual depth is achieved through layered structural dark tones, precision ambient cyan illumination, and low-contrast perimeter barriers rather than heavy drop shadows:

- **Surface Tiers:**
  - *Base Surface (Canvas):* Solid deep neutral (`#0B0E14`).
  - *Tier 1 (Panels & Dashboard Cards):* Tinted dark slate (`#131722`) framed with a 1px ghost border (`rgba(255, 255, 255, 0.08)`).
  - *Tier 2 (Floating Overlays, Modal HUDs):* Translucent obsidian glass (`rgba(16, 21, 31, 0.85)`) backed by a 24px hardware-accelerated backdrop blur (`backdrop-filter: blur(24px)`).
- **Photonic Glow:** Active nodes, selected drive modes, and critical warnings project a constrained, high-falloff ambient bloom: `box-shadow: 0 0 20px rgba(0, 242, 254, 0.25)`. Diffuse shadows remain strictly tinted to the primary or tertiary wavelength; muddy black drop shadows are prohibited.

## Shapes

The design system incorporates aerodynamic pill-shaped geometry (`roundedness: 3`) contrasted against taut architectural container frames. 

- Primary touch triggers, mode selectors, status tags, and spec pills implement full continuous capsule curvature (`rounded-full` / `3rem`).
- Information cards, instrument gauge clusters, and spatial canvas blocks feature a more restrained curvature (`1rem` to `1.5rem`), preventing wasted perimeter area while retaining soft, non-abrasive edges.
- Sliders, volume rails, and battery charge bars employ pill-capped tracks to reflect the sleek mechanical form factor of physical cockpit controls.

## Components

### Buttons & Interactive Triggers
- **Primary Kinetic Trigger:** Capsule-pill geometry. Solid primary cyan fill (`#00F2FE`) with near-black text (`#0B0E14`). Hover/Active state introduces a 12px outer glow (`rgba(0, 242, 254, 0.4)`).
- **Secondary Ghost Switch:** Transparent interior bordered with 1px `rgba(255, 255, 255, 0.16)`. Lightens to `rgba(255, 255, 255, 0.9)` on hover, with text rendered in white.
- **Haptic Tactile Toggle:** Deep-set pill container (`#161B26`) housing a sliding luminous switch thumb that locks into position with high mechanical snap-in feel and primary color glow upon activation.

### Spec Badges & Telemetry Chips
- Rendered using `label-caps` in `JetBrains Mono`.
- Built as ultra-compact pill tags featuring a 1px border.
- Active states feature a 6px pulsing live-status dot (e.g., active autonomous cruise, thermal pre-conditioning).

### Input Fields & Sliders
- **HVAC & Kinetic Sliders:** Fluid horizontal or vertical pill tracks with high-contrast active fill strips. The slider thumb is an extruded pill cap bearing a tactile center notch.
- **Text Inputs:** Understated dark field tiles (`#131722`) with an unobtrusive 1px border. Focus state invokes an instant switch to a 1px primary cyan contour with zero blur halo, retaining razor clarity.

### Cards & Telemetry Tiles
- Encased within 1px cold-iron borders (`rgba(255, 255, 255, 0.08)`).
- Top corners carry metadata indicators (e.g., sensor frequency, drive profile) typeset in `label-caps`. 
- High-priority cards (e.g., Critical Battery Range Warning) swap their border tone to dynamic warning amber or tertiary kinetic green.

### Domain-Specific Components
- **Battery & Flux Bar:** Segmented or fluid luminous charge state bars with dynamic color transitions: tertiary kinetic green (`>20%`), primary cyan (charging), and warning pulse (`<10%`).
- **Drive Mode Selector:** Horizontal segmented pill dock switching cleanly between *Range*, *Comfort*, *Sport*, and *Track*, shifting the interface's accent photon temperature in real time.